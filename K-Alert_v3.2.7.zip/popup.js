"use strict";const UPBIT_STORAGE_KEY="upbit_alarms_v2";const BITHUMB_STORAGE_KEY="bithumb_alarms_v1";const SETTINGS_KEY="upbit_alarm_settings_v1"
;const HISTORY_KEY_LEGACY=window.KTA_KEYS.HISTORY_KEY_LEGACY;const HISTORY_KEYS=window.KTA_KEYS.HISTORY_KEYS;const HISTORY_MAX=50;let historyExchange="upbit";let historyCache={upbit:[],bithumb:[]}
;function trendPriceAt(e,t){let n=e.a1,r=e.a2;if(!n||!r)return null;if(r.t<n.t){const e=n;n=r;r=e}const i=n.t,a=n.p,c=r.t,s=r.p;if(![i,c,a,s,t].every(Number.isFinite))return null;if(c===i)return null
;const o=(t-i)/(c-i);const l=e.extend||"right";if(l==="none"&&(o<0||o>1))return null;if(l==="right"&&o<0)return null;if(e.scale==="log"){if(a<=0||s<=0)return null;return a*Math.pow(s/a,o)}
return a+(s-a)*o}function fmtDateShort(e){if(!Number.isFinite(e))return"";return new Date(e*1e3).toLocaleDateString("ko-KR",{month:"numeric",day:"numeric"})}function fmtDateFull(e){
if(!Number.isFinite(e))return"";return new Date(e*1e3).toLocaleString("ko-KR",{year:"numeric",month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"})}const TF_KOR={"1S":"1초봉",1:"1분봉",3:"3분봉",
5:"5분봉",10:"10분봉",15:"15분봉",30:"30분봉",60:"1시간봉",240:"4시간봉","1D":"일봉","1W":"주봉","1M":"월봉"};function tfToKor(e){return TF_KOR[e]||(e?e+"봉":"")}function reactivateLabel(e){switch(e.reactivate){
case"instant":return"즉시";case"30min":return"30분 후";case"1hour":return"1시간 후";case"custom":return`${e.reactivateMinutes||60}분 후`;default:return"즉시"}}function trendDirLabel(e){let t=e.a1,n=e.a2
;if(!t||!n)return"";if(n.t<t.t){const e=t;t=n;n=e}let r;if(e.scale==="log"){if(t.p<=0||n.p<=0)return"";r=Math.log(n.p/t.p)}else{r=n.p-t.p}const i=t.p!==0?Math.abs(r/t.p):0;if(i<5e-4)return"수평추세"
;return r>0?"상승추세":"하락추세"}function trendSummary(e){const t=[tfToKor(e.tf),trendDirLabel(e)].filter(Boolean);return t.join(" ")||"추세선"}function trendSummaryDetail(e){const t={right:"오른쪽 연장",
both:"양쪽 연장",none:"선분만"}[e.extend]||"";const n=[fmtDateFull(e.a1.t),"→",fmtDateFull(e.a2.t)];if(t)n.push("· "+t);if(e.scale==="log")n.push("· 로그축");const r=Math.floor(Date.now()/1e3)
;const i=trendPriceAt(e,r);if(i!=null)n.push("· 현재 "+Math.round(i).toLocaleString()+"원");return n.join(" ")}const DEFAULT_SETTINGS={sound:"fanfare",volume:70,reactivate:"custom",reactivateMinutes:1,
linkTarget:"current",theme:"light",quickAddBtn:true,ntfyEnabled:false,ntfyTopic:"",ntfyCooldown:30,trendSameAsPrice:true,trendSound:"ding3",trendLastExtend:"right",trendLastScale:"linear",
trendLastRepeat:"perBar",priceLastRepeat:"interval",priceLastRepeatTf:"15"};const PRICE_REPEAT_MODES=["perBar","once","interval"]
;const PRICE_REPEAT_TFS=["1","3","5","10","15","30","60","240","1D","1W","1M"];function priceRepeatOf(e){return PRICE_REPEAT_MODES.includes(e.repeat)?e.repeat:"interval"}function priceRepeatTfOf(e,t){
if(PRICE_REPEAT_TFS.includes(e.repeatTf))return e.repeatTf;if(t&&PRICE_REPEAT_TFS.includes(t.priceLastRepeatTf))return t.priceLastRepeatTf;return"15"}let currentExchange="upbit";let upbitAlarms=[]
;let bithumbAlarms=[];let upbitMarkets=[];let bithumbMarkets=[];let upbitPrices={};let bithumbPrices={};let settings={...DEFAULT_SETTINGS};let manageMode=false;let acIdx=-1;let collapsedGroups={
upbit:new Set,bithumb:new Set};let editingId=null;let currentPageSym=null;function isActive(e){return!e.fired&&!e.disabled}function getAlarms(){
return currentExchange==="upbit"?upbitAlarms:bithumbAlarms}function setAlarms(e){if(currentExchange==="upbit")upbitAlarms=e;else bithumbAlarms=e}function getMarkets(){
return currentExchange==="upbit"?upbitMarkets:bithumbMarkets}function getPrices(){return currentExchange==="upbit"?upbitPrices:bithumbPrices}function getStorageKey(){
return currentExchange==="upbit"?UPBIT_STORAGE_KEY:BITHUMB_STORAGE_KEY}function getCollapsed(){return collapsedGroups[currentExchange]}function getGroupKey(e){
return currentExchange==="upbit"?e.code:e.sym}function getCoinUrl(e){
return currentExchange==="upbit"?`https://upbit.com/exchange?code=CRIX.UPBIT.${e.code}`:`https://www.bithumb.com/react/trade/order/${e.sym}-KRW`}function openCoinUrl(e,t){const n=t||{};if(!e)return
;if(settings.linkTarget!=="current"){chrome.tabs.create({url:e});return}chrome.tabs.query({active:true,currentWindow:true},t=>{const r=t[0];if(!r||!r.id){chrome.tabs.create({url:e});return}
const i=/^https:\/\/(www\.)?upbit\.com\//.test(r.url||"");const a=/^https:\/\/www\.bithumb\.com\//.test(r.url||"");const c=n.exchange==="upbit"&&i||n.exchange==="bithumb"&&a;if(n.sym&&c){try{
chrome.tabs.sendMessage(r.id,{action:"ktaGoCoin",sym:n.sym},t=>{if(chrome.runtime.lastError||!t)chrome.tabs.update(r.id,{url:e})});return}catch(e){}}chrome.tabs.update(r.id,{url:e})})}
function escapeHtml(e){return String(e==null?"":e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function applyTheme(e){
document.body.classList.toggle("light",e==="light");const t=document.getElementById("btn-theme");if(t)t.innerHTML=`<svg class="ico"><use href="#${e==="light"?"i-moon":"i-sun"}"/></svg>`}
function loadAllAlarms(){return new Promise(e=>{chrome.storage.local.get([UPBIT_STORAGE_KEY,BITHUMB_STORAGE_KEY],t=>{upbitAlarms=t[UPBIT_STORAGE_KEY]||[];bithumbAlarms=t[BITHUMB_STORAGE_KEY]||[];e()})
})}function saveAlarms(){chrome.storage.local.set({[getStorageKey()]:getAlarms()})}function loadSettings(){return new Promise(e=>{chrome.storage.local.get(SETTINGS_KEY,t=>{settings={
...DEFAULT_SETTINGS,...t[SETTINGS_KEY]||{}};e()})})}function saveSettings(e){chrome.storage.local.set({[SETTINGS_KEY]:e})}async function fetchUpbitPrices(){
const e=[...new Set(upbitAlarms.map(e=>e.code))];if(!e.length)return;try{const t=await fetch(`https://api.upbit.com/v1/ticker?markets=${e.join(",")}`);const n=await t.json();n.forEach(e=>{
upbitPrices[e.market]=e.trade_price})}catch{}}async function fetchUpbitMarkets(){try{const e=await fetch("https://api.upbit.com/v1/market/all?isDetails=false");const t=await e.json()
;upbitMarkets=t.filter(e=>e.market.startsWith("KRW-")).map(e=>({code:e.market,sym:e.market.replace("KRW-",""),kor:e.korean_name,eng:e.english_name}))}catch{}}async function loadBithumbData(){try{
const[e,t]=await Promise.all([fetch("https://api.bithumb.com/public/ticker/ALL_KRW"),fetch("https://api.bithumb.com/v1/market/all").catch(()=>null)]);const n=await e.json();if(n.status!=="0000")return
;const r={};upbitMarkets.forEach(e=>{r[e.sym]=e.kor});if(t&&t.ok){const e=await t.json();e.filter(e=>e.market.startsWith("KRW-")).forEach(e=>{const t=e.market.replace("KRW-","")
;if(!r[t])r[t]=e.korean_name})}bithumbMarkets=[];Object.entries(n.data).forEach(([e,t])=>{if(e==="date")return;bithumbMarkets.push({sym:e,kor:r[e]||""});bithumbPrices[e]=parseFloat(t.closing_price)})
;bithumbMarkets.sort((e,t)=>e.sym.localeCompare(t.sym))}catch{}}async function fetchPrices(){if(!upbitMarkets.length)await fetchUpbitMarkets();await Promise.all([fetchUpbitPrices(),loadBithumbData()])
}async function prefetchCoinPrice(e){if(currentExchange==="upbit"){const t=`KRW-${e}`;if(upbitPrices[t])return;try{const e=await fetch(`https://api.upbit.com/v1/ticker?markets=${t}`)
;const n=await e.json();if(n[0])upbitPrices[t]=n[0].trade_price}catch{}}else{if(bithumbPrices[e])return;try{const t=await fetch(`https://api.bithumb.com/public/ticker/${e}_KRW`);const n=await t.json()
;if(n.status==="0000")bithumbPrices[e]=parseFloat(n.data.closing_price)}catch{}}}function previewSound(e){if(e==="none")return
;fetch(chrome.runtime.getURL(`sounds/${e}.wav`)).then(e=>e.blob()).then(e=>{const t=URL.createObjectURL(e);const n=new Audio(t);n.volume=(settings.volume??70)/100;n.play().catch(()=>{})
;n.addEventListener("ended",()=>URL.revokeObjectURL(t))}).catch(()=>{})}function render(){const e=getAlarms();const t=getPrices();const n=getCollapsed();const r=document.getElementById("alarm-list")
;const i=document.getElementById("empty-state");const a=document.getElementById("manage-footer");document.querySelectorAll(".exch-tab").forEach(e=>{
e.classList.toggle("active",e.dataset.exch===currentExchange)});if(!e.length){r.innerHTML="";i.style.display="block";a.style.display="none";return}i.style.display="none"
;a.style.display=manageMode?"flex":"none";const c=new Map;e.forEach(e=>{const t=getGroupKey(e);if(!c.has(t))c.set(t,[]);c.get(t).push(e)});const s=[...c.entries()];if(currentPageSym){
s.sort(([e],[t])=>{const n=(currentExchange==="upbit"?e.replace("KRW-",""):e).toUpperCase()===currentPageSym;const r=(currentExchange==="upbit"?t.replace("KRW-",""):t).toUpperCase()===currentPageSym
;return n===r?0:n?-1:1})}r.innerHTML=s.map(([e,r])=>{const i=currentExchange==="upbit"?e.replace("KRW-",""):e;const a=currentPageSym&&i.toUpperCase()===currentPageSym;const c=r[0].kor||"";const s=t[e]
;const o=n.has(e);const l=r.map(e=>{const t=e.type==="trend";const n=e.dir==="above"?"↑ 이상":"↓ 이하";const r=isActive(e);if(manageMode){
return`<div class="alarm-item">\n          <input type="checkbox" class="chk-box alarm-chk" data-id="${e.id}"/>\n          ${t?"":`<span class="alarm-dir" data-dir="${e.dir}">${n}</span>`}\n          <span class="alarm-price">${t?trendSummary(e):Number(e.price).toLocaleString()+"원"}</span>\n        </div>`
}if(t){if(editingId===e.id){
return`<div class="alarm-item editing" data-id="${e.id}">\n            <div class="alarm-main">\n              <span class="alarm-price trend-label">${trendSummary(e)}</span>\n              <div class="alarm-actions">\n                <button class="btn-trend-repick" data-id="${e.id}">좌표 다시 찍기</button>\n                <button class="trend-edit-save" data-id="${e.id}">저장</button>\n                <button class="btn-edit-cancel">취소</button>\n              </div>\n            </div>\n            <div class="alarm-main">\n              <select class="edit-dir trend-edit-extend" data-id="${e.id}">\n                <option value="right" ${e.extend==="right"?"selected":""}>오른쪽 연장</option>\n                <option value="both" ${e.extend==="both"?"selected":""}>양쪽 연장</option>\n                <option value="none" ${e.extend==="none"?"selected":""}>선분만</option>\n              </select>\n              <select class="edit-dir trend-edit-scale" data-id="${e.id}">\n                <option value="linear" ${e.scale!=="log"?"selected":""}>일반축</option>\n                <option value="log" ${e.scale==="log"?"selected":""}>로그축</option>\n              </select>\n            </div>\n            <div class="alarm-main">\n              <select class="edit-dir trend-edit-repeat" data-id="${e.id}">\n                <option value="perBar" ${!e.repeat||e.repeat==="perBar"?"selected":""}>봉마다 반복</option>\n                <option value="once" ${e.repeat==="once"?"selected":""}>한 번만 울림</option>\n                <option value="interval" ${e.repeat==="interval"?"selected":""}>재활성화 설정(${reactivateLabel(settings)})</option>\n              </select>\n            </div>\n            <input type="text" class="edit-memo trend-edit-memo" data-id="${e.id}" placeholder="비고 (선택) · 엔터로 저장" value="${escapeHtml(e.memo)}"/>\n          </div>`
}
return`<div class="alarm-item alarm-item-trend" data-id="${e.id}">\n          <span class="alarm-price trend-label" title="${trendSummaryDetail(e)}">${trendSummary(e)}</span>\n          <span class="alarm-memo-text">${escapeHtml(e.memo)}</span>\n          <div class="alarm-actions">\n            <label class="toggle" title="${r?"비활성화":"다시 활성화"}">\n              <input type="checkbox" class="toggle-chk" data-id="${e.id}" ${r?"checked":""}/>\n              <span class="toggle-slider"></span>\n            </label>\n            <button class="btn-del" data-id="${e.id}"><svg class="ico" style="pointer-events:none"><use href="#i-x"/></svg></button>\n          </div>\n        </div>`
}if(editingId===e.id){
const t=`\n          <div class="alarm-main repeat-repick-row">\n            <select class="edit-repeat price-edit-repeat" data-id="${e.id}"\n                    title="봉마다 반복은 저장된 봉 길이 기준이에요. 차트 위에서 알람선을 더블클릭하면 지금 보고 있는 봉 길이로 바꿀 수 있어요.">\n              <option value="perBar" ${priceRepeatOf(e)==="perBar"?"selected":""}>봉마다 반복(${tfToKor(priceRepeatTfOf(e,settings))})</option>\n              <option value="once" ${priceRepeatOf(e)==="once"?"selected":""}>한 번만 울림</option>\n              <option value="interval" ${priceRepeatOf(e)==="interval"?"selected":""}>재활성화 설정(${reactivateLabel(settings)})</option>\n            </select>\n            <button class="btn-price-repick" data-id="${e.id}">좌표 다시 찍기</button>\n          </div>`
;return`<div class="alarm-item editing">\n          <div class="alarm-main">\n            <select class="edit-dir" data-id="${e.id}">\n              <option value="above" ${e.dir==="above"?"selected":""}>↑ 이상</option>\n              <option value="below" ${e.dir==="below"?"selected":""}>↓ 이하</option>\n            </select>\n            <input type="number" class="edit-price" data-id="${e.id}" value="${e.price}"/>\n            <div class="alarm-actions">\n              <button class="btn-edit-save" data-id="${e.id}">저장</button>\n              <button class="btn-edit-cancel">취소</button>\n            </div>\n          </div>${t}\n          <input type="text" class="edit-memo" placeholder="비고 (선택)" value="${escapeHtml(e.memo)}"/>\n        </div>`
}
return`<div class="alarm-item">\n        <span class="alarm-dir editable" data-dir="${e.dir}" data-id="${e.id}">${n}</span>\n        <span class="alarm-price editable" data-id="${e.id}">${Number(e.price).toLocaleString()}원</span>\n        <span class="alarm-memo-text">${escapeHtml(e.memo)}</span>\n        <div class="alarm-actions">\n          <label class="toggle" title="${r?"비활성화":"다시 활성화"}">\n            <input type="checkbox" class="toggle-chk" data-id="${e.id}" ${r?"checked":""}/>\n            <span class="toggle-slider"></span>\n          </label>\n          <button class="btn-del" data-id="${e.id}"><svg class="ico" style="pointer-events:none"><use href="#i-x"/></svg></button>\n        </div>\n      </div>`
}).join("");const d=manageMode?`<input type="checkbox" class="chk-box group-chk" data-key="${e}"/>`:""
;return`<div class="group${a?" group-current":""}" data-key="${e}">\n      <div class="group-hdr">\n        ${d}\n        ${a?'<span class="badge-current"><svg class="ico"><use href="#i-pin"/></svg></span>':""}\n        <span class="group-sym coin-link" data-key="${e}">${i}</span>\n        ${c?`<span class="group-kor">${escapeHtml(c)}</span>`:""}\n        <span class="group-cur">${s?"현재: "+Number(s).toLocaleString()+"원":""}</span>\n        <span class="group-chevron">${o?"›":"⌄"}</span>\n      </div>\n      <div class="group-body${o?" collapsed":""}">${l}</div>\n    </div>`
}).join("");r.querySelectorAll(".coin-link").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation();const n=e.dataset.key;const r=getAlarms().find(e=>getGroupKey(e)===n)
;const i=r?getCoinUrl(r):"";if(!i)return;openCoinUrl(i,{exchange:currentExchange,sym:r&&r.sym})})});r.querySelectorAll(".group-hdr").forEach(e=>{e.addEventListener("click",t=>{
if(t.target.closest(".chk-box")||t.target.closest(".coin-link"))return;const n=e.closest(".group").dataset.key;const r=getCollapsed();if(r.has(n))r.delete(n);else r.add(n);render()})})
;if(!manageMode){r.querySelectorAll(".toggle-chk").forEach(e=>{e.addEventListener("change",t=>{t.stopPropagation();const n=getAlarms().find(t=>t.id===+e.dataset.id);if(!n)return;if(e.checked){
n.fired=false;n.disabled=false}else{n.disabled=true}saveAlarms();render()})});r.querySelectorAll(".btn-del").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation()
;setAlarms(getAlarms().filter(t=>t.id!==+e.dataset.id));saveAlarms();render()})});r.querySelectorAll(".editable").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation();editingId=+e.dataset.id
;render();const n=r.querySelector(".edit-price");if(n){n.focus();n.select()}})});r.querySelectorAll(".btn-edit-save").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation()
;const n=+e.dataset.id;const i=getAlarms().find(e=>e.id===n);if(i){const e=r.querySelector(`.edit-dir[data-id="${n}"]`);const t=r.querySelector(`.edit-price[data-id="${n}"]`)
;const a=r.querySelector(".edit-memo");const c=r.querySelector(`.price-edit-repeat[data-id="${n}"]`);const s=parseFloat(t?.value);if(!isNaN(s)&&s>0){const t=i.price!==s;i.dir=e?.value||i.dir;i.price=s
;i.fired=false;if(t)i.lastFiredBarT=null}i.memo=a?.value.trim()||"";if(c&&PRICE_REPEAT_MODES.includes(c.value)){i.repeat=c.value;if(c.value==="perBar")i.repeatTf=priceRepeatTfOf(i,settings)
;settings.priceLastRepeat=i.repeat;saveSettings(settings)}}editingId=null;saveAlarms();render()})});r.querySelectorAll(".btn-edit-cancel").forEach(e=>{e.addEventListener("click",e=>{
e.stopPropagation();editingId=null;render()})});r.querySelectorAll(".alarm-item-trend").forEach(e=>{e.addEventListener("click",t=>{if(t.target.closest(".toggle")||t.target.closest(".btn-del"))return
;t.stopPropagation();editingId=+e.dataset.id;render();const n=r.querySelector(".trend-edit-memo");if(n){n.focus();n.select()}})});function o(e){const t=getAlarms().find(t=>t.id===e);if(!t)return
;const n=r.querySelector(`.trend-edit-memo[data-id="${e}"]`);const i=r.querySelector(`.trend-edit-extend[data-id="${e}"]`);const a=r.querySelector(`.trend-edit-scale[data-id="${e}"]`)
;const c=r.querySelector(`.trend-edit-repeat[data-id="${e}"]`);if(n)t.memo=n.value.trim();if(i)t.extend=i.value;if(a)t.scale=a.value;if(c)t.repeat=c.value;if(i||a){settings.trendLastExtend=t.extend
;settings.trendLastScale=t.scale}if(c)settings.trendLastRepeat=t.repeat;if(i||a||c)saveSettings(settings);editingId=null;saveAlarms();render()}r.querySelectorAll(".trend-edit-save").forEach(e=>{
e.addEventListener("click",t=>{t.stopPropagation();o(+e.dataset.id)})});r.querySelectorAll(".trend-edit-memo").forEach(e=>{e.addEventListener("keydown",t=>{t.stopPropagation();if(t.key==="Enter"){
o(+e.dataset.id)}else if(t.key==="Escape"){editingId=null;render()}})});r.querySelectorAll(".btn-trend-repick").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation();const n=+e.dataset.id
;chrome.tabs.query({active:true,currentWindow:true},e=>{if(e[0])chrome.tabs.sendMessage(e[0].id,{action:"startTrendPick",editId:n},()=>window.close());else window.close()})})})
;r.querySelectorAll(".btn-price-repick").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation();const n=+e.dataset.id;chrome.tabs.query({active:true,currentWindow:true},e=>{
if(e[0])chrome.tabs.sendMessage(e[0].id,{action:"startPriceAlarmPick",editId:n},()=>window.close());else window.close()})})});r.querySelectorAll(".edit-price").forEach(e=>{
e.addEventListener("input",()=>{const t=parseFloat(e.value);if(!t||t<=0)return;const n=+e.dataset.id;const i=getAlarms().find(e=>e.id===n);if(!i)return
;const a=currentExchange==="upbit"?`KRW-${i.sym}`:i.sym;const c=getPrices()[a];if(!c)return;const s=r.querySelector(`.edit-dir[data-id="${n}"]`);if(s)s.value=t>=c?"above":"below"})})}else{
r.querySelectorAll(".group-chk").forEach(e=>{e.addEventListener("change",t=>{t.stopPropagation();r.querySelectorAll(".alarm-chk").forEach(t=>{const n=getAlarms().find(e=>e.id===+t.dataset.id)
;if(n&&getGroupKey(n)===e.dataset.key)t.checked=e.checked});syncSelectAll()})});r.querySelectorAll(".alarm-chk").forEach(e=>e.addEventListener("change",syncSelectAll))}}function syncSelectAll(){
const e=document.querySelectorAll(".alarm-chk");const t=document.querySelectorAll(".alarm-chk:checked");const n=document.getElementById("chk-all");if(n)n.checked=e.length>0&&e.length===t.length}
const CHOSUNG=["ㄱ","ㄲ","ㄴ","ㄷ","ㄸ","ㄹ","ㅁ","ㅂ","ㅃ","ㅅ","ㅆ","ㅇ","ㅈ","ㅉ","ㅊ","ㅋ","ㅌ","ㅍ","ㅎ"];function getChosung(e){const t=e.charCodeAt(0)-44032;return t>=0&&t<=11171?CHOSUNG[Math.floor(t/588)]:e}
function toChosung(e){return[...e].map(getChosung).join("")}function isAllChosung(e){return/^[ㄱ-ㅎ]+$/.test(e)}function isKoreanInput(e){return/^[ㄱ-ㅎㅏ-ㅣ가-힣]+$/.test(e)}const ENG_TO_KOR={q:"ㅂ",w:"ㅈ",
e:"ㄷ",r:"ㄱ",t:"ㅅ",y:"ㅛ",u:"ㅕ",i:"ㅑ",o:"ㅐ",p:"ㅔ",a:"ㅁ",s:"ㄴ",d:"ㅇ",f:"ㄹ",g:"ㅎ",h:"ㅗ",j:"ㅓ",k:"ㅏ",l:"ㅣ",z:"ㅋ",x:"ㅌ",c:"ㅊ",v:"ㅍ",b:"ㅠ",n:"ㅜ",m:"ㅡ"}
;const CHO=["ㄱ","ㄲ","ㄴ","ㄷ","ㄸ","ㄹ","ㅁ","ㅂ","ㅃ","ㅅ","ㅆ","ㅇ","ㅈ","ㅉ","ㅊ","ㅋ","ㅌ","ㅍ","ㅎ"];const JUNG=["ㅏ","ㅐ","ㅑ","ㅒ","ㅓ","ㅔ","ㅕ","ㅖ","ㅗ","ㅘ","ㅙ","ㅚ","ㅛ","ㅜ","ㅝ","ㅞ","ㅟ","ㅠ","ㅡ","ㅢ","ㅣ"]
;const JONG=["","ㄱ","ㄲ","ㄳ","ㄴ","ㄵ","ㄶ","ㄷ","ㄹ","ㄺ","ㄻ","ㄼ","ㄽ","ㄾ","ㄿ","ㅀ","ㅁ","ㅂ","ㅄ","ㅅ","ㅆ","ㅇ","ㅈ","ㅊ","ㅋ","ㅌ","ㅍ","ㅎ"];const JONG_TO_CHO={ㄱ:0,ㄲ:1,ㄴ:2,ㄷ:3,ㄹ:5,ㅁ:6,ㅂ:7,ㅅ:9,ㅆ:10,ㅇ:11,ㅈ:12,ㅊ:14,
ㅋ:15,ㅌ:16,ㅍ:17,ㅎ:18};function composeJamo(e){let t="";let n=-1,r=-1,i=-1;const a=()=>{if(n<0)return;if(r<0){t+=CHO[n];n=-1;return}t+=String.fromCharCode(44032+(n*21+r)*28+i+1);n=-1;r=-1;i=-1}
;for(const c of e){const e=CHO.indexOf(c),s=JUNG.indexOf(c),o=JONG.indexOf(c);if(s>=0){if(n>=0&&r<0){r=s}else if(n>=0&&r>=0&&i>=0){const e=i;i=-1;a();n=JONG_TO_CHO[JONG[e+1]]??-1;r=s}else{a();t+=c}
}else if(e>=0){if(n>=0&&r>=0&&i<0){const t=JONG.indexOf(c,1);if(t>0){i=t-1}else a();if(i<0){n=e}}else{a();n=e}}else{a();t+=c}}a();return t}function engToKorStr(e){
const t=e.toLowerCase().split("").map(e=>ENG_TO_KOR[e]||e).join("");return composeJamo(t)}function showAC(e){const t=document.getElementById("ac-list");const n=getMarkets();if(!e||!n.length){
t.style.display="none";acIdx=-1;return}const r=e.toUpperCase();const i=isAllChosung(e)?e:null;const a=isKoreanInput(e);const c=!a&&/^[a-zA-Z]+$/.test(e);const s=c?engToKorStr(e):null
;const o=n.filter(t=>{if(a)return t.kor&&t.kor.includes(e)||i&&t.kor&&toChosung(t.kor).includes(i);if(t.sym.includes(r))return true;if(s&&t.kor&&t.kor.includes(s))return true;return false})
;o.sort((e,t)=>{const n=e.sym===r,i=t.sym===r;if(n!==i)return n?-1:1;const a=e.sym.startsWith(r),c=t.sym.startsWith(r);if(a!==c)return a?-1:1;return e.sym.localeCompare(t.sym)});const l=o.slice(0,20)
;if(!l.length){t.style.display="none";acIdx=-1;return}acIdx=-1
;t.innerHTML=l.map(e=>`<div class="ac-item" data-sym="${e.sym}">\n      <span class="ac-sym">${escapeHtml(e.sym)}</span>${e.kor?`<span class="ac-kor">${escapeHtml(e.kor)}</span>`:""}\n    </div>`).join("")
;t.querySelectorAll(".ac-item").forEach(e=>{e.addEventListener("mousedown",t=>{t.preventDefault();selectAC(e.dataset.sym)})});t.style.display="block"}function hideAC(){
const e=document.getElementById("ac-list");if(e)e.style.display="none";acIdx=-1}function selectAC(e){document.getElementById("coin-input").value=e;hideAC()
;document.getElementById("price-input").focus();prefetchCoinPrice(e)}function moveAC(e){const t=document.getElementById("ac-list");if(!t||t.style.display==="none")return
;const n=t.querySelectorAll(".ac-item");if(!n.length)return;if(acIdx>=0)n[acIdx].classList.remove("active");acIdx=Math.max(0,Math.min(acIdx+e,n.length-1));n[acIdx].classList.add("active")
;n[acIdx].scrollIntoView({block:"nearest"})}function showView(e){["view-main","view-add","view-settings","view-history"].forEach(t=>{document.getElementById(t).style.display=t===e?"flex":"none"})}
function isTrendAvailable(){return true}function updateTrendAvailability(){const e=document.getElementById("type-trend-label");const t=e?.querySelector("input");if(!e||!t)return
;const n=isTrendAvailable();t.disabled=!n;e.style.opacity=n?"":".45";e.style.cursor=n?"":"not-allowed";e.title=n?"":"지금은 추세선 알람을 만들 수 없어요";if(!n&&t.checked)setAddType("price")}function setAddType(e){
const t=document.getElementById("type-price-label")?.querySelector("input");const n=document.getElementById("type-trend-label")?.querySelector("input");if(t)t.checked=e==="price"
;if(n)n.checked=e==="trend";const r=document.getElementById("price-fields");const i=document.getElementById("trend-fields");if(r)r.style.display=e==="price"?"":"none"
;if(i)i.style.display=e==="trend"?"":"none";const a=e==="trend";["coin-field","dir-field","memo-field"].forEach(e=>{const t=document.getElementById(e);if(t)t.style.display=a?"none":""})}
function resetTrendForm(){const e=document.getElementById("draw-status");if(e){e.textContent="버튼을 누르면 팝업이 닫히고 차트에서 두 지점을 클릭하는 걸로 바로 넘어가요. 비고는 그때 입력해요.";e.classList.remove("filled")}}
function migrateHistory(e){const t={upbit:e[HISTORY_KEYS.upbit],bithumb:e[HISTORY_KEYS.bithumb]};const n=t.upbit===undefined;const r=t.bithumb===undefined;if(!n&&!r)return{hist:t,write:null}
;const i=e[HISTORY_KEY_LEGACY]||[];const a={};if(n){t.upbit=i.filter(e=>e.exchange!=="bithumb").slice(0,HISTORY_MAX);a[HISTORY_KEYS.upbit]=t.upbit}if(r){
t.bithumb=i.filter(e=>e.exchange==="bithumb").slice(0,HISTORY_MAX);a[HISTORY_KEYS.bithumb]=t.bithumb}return{hist:t,write:a}}function loadHistory(){
chrome.storage.local.get([HISTORY_KEYS.upbit,HISTORY_KEYS.bithumb,HISTORY_KEY_LEGACY],e=>{const{hist:t,write:n}=migrateHistory(e);historyCache={upbit:t.upbit||[],bithumb:t.bithumb||[]}
;if(n)chrome.storage.local.set(n);const r=historyCache[historyExchange]||[];if(r.some(e=>e.unread)){r.forEach(e=>{e.unread=false});chrome.storage.local.set({[HISTORY_KEYS[historyExchange]]:r})}
renderHistoryView()})}function renderHistoryView(){document.querySelectorAll("#history-exch-bar .exch-tab").forEach(e=>{e.classList.toggle("active",e.dataset.histExch===historyExchange)})
;const e=document.getElementById("clear-history-label");if(e)e.textContent=historyExchange==="upbit"?"업비트 기록 삭제":"빗썸 기록 삭제";renderHistory(historyCache[historyExchange]||[])}function renderHistory(e){
const t=document.getElementById("history-list");const n=document.getElementById("history-empty");if(!e.length){t.innerHTML="";n.style.display="block";return}n.style.display="none";const r=Date.now()
;t.innerHTML=e.map((e,t)=>{const n=e.dir==="above"?"이상 도달":"이하 도달";const i=r-e.firedAt;let a
;if(i<6e4)a="방금";else if(i<36e5)a=`${Math.floor(i/6e4)}분 전`;else if(i<864e5)a=new Date(e.firedAt).toLocaleTimeString("ko-KR",{hour:"2-digit",minute:"2-digit"
});else a=new Date(e.firedAt).toLocaleDateString("ko-KR",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"})
;return`<div class="history-item${e.unread?" unread":""}" data-idx="${t}" style="cursor:pointer;">\n      <div class="history-top">\n        <span class="history-exchange ${e.exchange}">${e.exchange==="upbit"?"업비트":"빗썸"}</span>\n        <span class="history-label">${escapeHtml(e.label)}</span>\n        <span class="history-time">${a}</span>\n      </div>\n      <div class="history-detail">${Number(e.price).toLocaleString()}원 ${n} · 현재가 ${Number(e.currentPrice).toLocaleString()}원</div>\n      ${e.memo?`<div class="history-memo">${escapeHtml(e.memo)}</div>`:""}\n    </div>`
}).join("");t.querySelectorAll(".history-item[data-idx]").forEach(t=>{t.addEventListener("click",()=>{const n=e[parseInt(t.dataset.idx)]
;const r=n.exchange==="bithumb"?`https://www.bithumb.com/react/trade/order/${n.sym}-KRW`:`https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${n.sym}`;openCoinUrl(r,{
exchange:n.exchange==="bithumb"?"bithumb":"upbit",sym:n.sym})})})}const NAV_STATS_KEY="kta_nav_stats_v1";const NAV_REASON_KOR={spa:"화면 유지하고 이동",same:"이미 그 코인이라 그대로",
"reload-not-found":"새로고침 (목록에서 못 찾음)","reload-click-timeout":"새로고침 (눌렀는데 안 넘어감)","reload-not-trade-page":"새로고침 (거래 화면이 아니었음)","reload-no-list":"새로고침 (코인 목록을 못 찾음)",
"reload-click-error":"새로고침 (누르기 실패)","reload-scroll-error":"새로고침 (목록 훑기 실패)","reload-bad-args":"새로고침 (코인 이름이 이상함)"};function renderNavStats(){const e=document.getElementById("nav-stats");if(!e)return
;chrome.storage.local.get(NAV_STATS_KEY,t=>{const n=t[NAV_STATS_KEY];if(!n){e.textContent="아직 알람에서 코인으로 이동한 적이 없어요";return}const r=[];["upbit","bithumb"].forEach(e=>{const t=n[e]||{}
;const i=Object.keys(t);if(!i.length)return;const a=i.reduce((e,n)=>e+t[n],0);r.push(`${e==="upbit"?"업비트":"빗썸"} — 모두 ${a}번`);i.sort((e,n)=>t[n]-t[e]).forEach(e=>{
r.push(`   ${NAV_REASON_KOR[e]||e} ${t[e]}번`)})});e.textContent=r.length?r.join("\n"):"아직 알람에서 코인으로 이동한 적이 없어요"})}function loadSettingsUI(){document.getElementById("sound-select").value=settings.sound
;const e=settings.volume??70;document.getElementById("vol-slider").value=e;document.getElementById("vol-pct").textContent=e+"%";const t=document.getElementById("chk-trend-same-sound");if(t){
t.checked=settings.trendSameAsPrice!==false;document.getElementById("trend-sound-row").style.display=t.checked?"none":""
;document.getElementById("trend-sound-select").value=settings.trendSound||"ding3"}const n=settings.reactivate;document.querySelectorAll("input[name=reactivate]").forEach(e=>{e.checked=e.value===n})
;document.getElementById("custom-minutes").value=settings.reactivateMinutes||60;renderNavStats();document.querySelectorAll("input[name=linkTarget]").forEach(e=>{
e.checked=e.value===(settings.linkTarget||"current")});const r=document.getElementById("chk-quick-add");if(r)r.checked=settings.quickAddBtn!==false;const i=document.getElementById("chk-ntfy");if(i){
i.checked=settings.ntfyEnabled||false;document.getElementById("ntfy-config").style.display=i.checked?"flex":"none";document.getElementById("ntfy-topic").value=settings.ntfyTopic||""
;document.querySelectorAll("input[name=ntfyCooldown]").forEach(e=>{e.checked=e.value===String(settings.ntfyCooldown??30)})}}function switchExchange(e){if(currentExchange===e)return;currentExchange=e
;manageMode=false;editingId=null;document.getElementById("btn-manage").textContent="관리";document.getElementById("btn-new").style.display="";document.getElementById("btn-theme").style.display=""
;document.getElementById("btn-history").style.display="";document.getElementById("btn-settings").style.display="";updateTrendAvailability();render()}
document.addEventListener("DOMContentLoaded",async()=>{await Promise.all([loadAllAlarms(),loadSettings()]);applyTheme(settings.theme||"dark");const e=document.getElementById("update-banner")
;let t=false;function n(n){if(!e)return;if(!n){e.style.display="none";return}e.style.display="block";if(!t){t=true;e.addEventListener("click",()=>{chrome.storage.local.get("pendingUpdate",e=>{
chrome.tabs.create({url:e.pendingUpdate&&e.pendingUpdate.page||"https://alert.krisb-infra.com/"})})})}}chrome.storage.local.get("pendingUpdate",e=>n(e.pendingUpdate));try{chrome.runtime.sendMessage({
action:"checkForUpdate"},()=>{void chrome.runtime.lastError;chrome.storage.local.get("pendingUpdate",e=>n(e.pendingUpdate))})}catch(e){}
document.querySelector(".popup-logo").addEventListener("click",()=>{chrome.tabs.create({url:"https://alert.krisb-infra.com/manual.html"})});chrome.tabs.query({active:true,currentWindow:true},e=>{
const t=e[0]?.url||"";if(t.includes("bithumb.com"))currentExchange="bithumb";else currentExchange="upbit";const n=t.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i)
;const r=t.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i);currentPageSym=(n?.[1]||r?.[1]||"").toUpperCase()||null;updateTrendAvailability();render()});function r(e){setAddType("price");resetTrendForm()
;showView("view-add");setTimeout(()=>{const t=document.getElementById("coin-input");t.value=e;t.dispatchEvent(new Event("input"));setTimeout(()=>{
const t=document.querySelector(`.ac-item[data-sym="${e.toUpperCase()}"]`);const n=t||document.querySelector(".ac-item");if(n)n.dispatchEvent(new MouseEvent("mousedown",{bubbles:true}))},150)},100)}
chrome.storage.local.get("quickAddSym",e=>{if(e.quickAddSym){chrome.storage.local.remove("quickAddSym");r(e.quickAddSym)}});chrome.storage.onChanged.addListener((e,t)=>{
if(t==="local"&&e.quickAddSym?.newValue){chrome.storage.local.remove("quickAddSym");r(e.quickAddSym.newValue)}});fetchUpbitMarkets();fetchPrices().then(render)
;document.querySelectorAll(".exch-tab").forEach(e=>{e.addEventListener("click",()=>switchExchange(e.dataset.exch))});document.getElementById("btn-theme").addEventListener("click",()=>{
settings.theme=settings.theme==="light"?"dark":"light";applyTheme(settings.theme);saveSettings(settings)});document.getElementById("btn-manage").addEventListener("click",()=>{manageMode=!manageMode
;document.getElementById("btn-manage").textContent=manageMode?"완료":"관리";document.getElementById("btn-new").style.display=manageMode?"none":""
;document.getElementById("btn-theme").style.display=manageMode?"none":"";document.getElementById("btn-history").style.display=manageMode?"none":""
;document.getElementById("btn-settings").style.display=manageMode?"none":"";render()});document.getElementById("btn-new").addEventListener("click",()=>{const e=currentExchange==="upbit"?"업비트":"빗썸"
;document.getElementById("add-title").textContent=`알람 추가 — ${e}`;const t=currentExchange==="upbit"?"BTC, 비트코인...":"BTC, ETH...";document.getElementById("coin-input").placeholder=t;setAddType("price")
;resetTrendForm();updateTrendAvailability();showView("view-add");setTimeout(()=>document.getElementById("coin-input").focus(),50)});document.getElementById("btn-back").addEventListener("click",()=>{
showView("view-main");render()});document.querySelectorAll("input[name=atype]").forEach(e=>{e.addEventListener("change",()=>{if(e.checked)setAddType(e.value)})})
;document.getElementById("btn-draw").addEventListener("click",()=>{chrome.tabs.query({active:true,currentWindow:true},e=>{if(e[0])chrome.tabs.sendMessage(e[0].id,{action:"startTrendPick"
},()=>window.close());else window.close()})});document.getElementById("btn-price-draw").addEventListener("click",()=>{chrome.tabs.query({active:true,currentWindow:true},e=>{
if(e[0])chrome.tabs.sendMessage(e[0].id,{action:"startPriceAlarmPick"},()=>window.close());else window.close()})});document.getElementById("btn-settings").addEventListener("click",()=>{
loadSettingsUI();showView("view-settings")});document.getElementById("btn-reset-nav-stats")?.addEventListener("click",()=>{chrome.storage.local.remove(NAV_STATS_KEY,()=>renderNavStats())})
;document.getElementById("btn-settings-back").addEventListener("click",()=>showView("view-main"));document.getElementById("btn-history").addEventListener("click",()=>{
historyExchange=currentExchange==="bithumb"?"bithumb":"upbit";loadHistory();showView("view-history")});document.getElementById("btn-history-back").addEventListener("click",()=>showView("view-main"))
;document.getElementById("btn-clear-history").addEventListener("click",()=>{const e=HISTORY_KEYS[historyExchange];chrome.storage.local.set({[e]:[]},()=>{historyCache[historyExchange]=[]
;renderHistoryView()})});document.querySelectorAll("#history-exch-bar .exch-tab").forEach(e=>{e.addEventListener("click",()=>{const t=e.dataset.histExch;if(!t||t===historyExchange)return
;historyExchange=t;loadHistory()})});document.getElementById("btn-preview").addEventListener("click",()=>{previewSound(document.getElementById("sound-select").value)})
;document.getElementById("btn-preview-trend")?.addEventListener("click",()=>{previewSound(document.getElementById("trend-sound-select").value)})
;document.getElementById("chk-trend-same-sound")?.addEventListener("change",function(){document.getElementById("trend-sound-row").style.display=this.checked?"none":""})
;document.getElementById("vol-slider").addEventListener("input",function(){document.getElementById("vol-pct").textContent=this.value+"%";settings.volume=parseInt(this.value);saveSettings(settings)})
;document.getElementById("btn-save-settings").addEventListener("click",()=>{const e={sound:document.getElementById("sound-select").value,
volume:parseInt(document.getElementById("vol-slider").value)??70,reactivate:document.querySelector("input[name=reactivate]:checked")?.value||"instant",
reactivateMinutes:parseInt(document.getElementById("custom-minutes").value)||60,linkTarget:document.querySelector("input[name=linkTarget]:checked")?.value||"current",theme:settings.theme||"light",
quickAddBtn:document.getElementById("chk-quick-add")?.checked??true,ntfyEnabled:document.getElementById("chk-ntfy")?.checked||false,ntfyTopic:document.getElementById("ntfy-topic")?.value.trim()||"",
ntfyCooldown:parseInt(document.querySelector("input[name=ntfyCooldown]:checked")?.value)||30,trendSameAsPrice:document.getElementById("chk-trend-same-sound")?.checked??true,
trendSound:document.getElementById("trend-sound-select")?.value||"ding3"};settings={...settings,...e};saveSettings(settings);showView("view-main")})
;document.getElementById("chk-ntfy")?.addEventListener("change",function(){document.getElementById("ntfy-config").style.display=this.checked?"flex":"none"})
;document.getElementById("btn-ntfy-test")?.addEventListener("click",()=>{const e=document.getElementById("ntfy-topic").value.trim();if(!e){alert("토픽명을 먼저 입력하세요.");return}chrome.runtime.sendMessage({
action:"ntfyTest",topic:e},e=>{if(e&&e.ok)alert(`테스트 푸시 전송 완료! (${e.status})`);else alert(`전송 실패: ${e?.error||"알 수 없는 오류"}`)})});document.getElementById("btn-export").addEventListener("click",()=>{
const e=getAlarms();const t=new Blob([JSON.stringify(e,null,2)],{type:"application/json"});const n=URL.createObjectURL(t);const r=document.createElement("a");r.href=n
;r.download=`${currentExchange}_alarms_${(new Date).toISOString().slice(0,10)}.json`;r.click();URL.revokeObjectURL(n)});document.getElementById("btn-import").addEventListener("click",()=>{
document.getElementById("import-file").click()});document.getElementById("import-file").addEventListener("change",function(){const e=this.files[0];if(!e)return;const t=new FileReader;t.onload=e=>{try{
const t=JSON.parse(e.target.result);if(!Array.isArray(t)){alert("올바른 알람 JSON 파일이 아니에요");return}const n=t.some(e=>typeof e.code==="string"&&e.code.startsWith("KRW-"))
;const r=n?upbitAlarms:bithumbAlarms;const i=n?UPBIT_STORAGE_KEY:BITHUMB_STORAGE_KEY;const a=[...r];t.forEach(e=>{const t=a.findIndex(t=>t.id===e.id);if(t>=0)Object.assign(a[t],e);else a.push(e)})
;if(n)upbitAlarms=a;else bithumbAlarms=a;chrome.storage.local.set({[i]:a});const c=n?"업비트":"빗썸";showView("view-main");render();alert(`${c} 알람 ${t.length}개 가져오기 완료`)}catch{alert("파일 파싱 오류")}}
;t.readAsText(e);this.value=""});document.getElementById("chk-all").addEventListener("change",function(){document.querySelectorAll(".alarm-chk").forEach(e=>e.checked=this.checked)})
;document.getElementById("btn-delete-sel").addEventListener("click",()=>{const e=new Set([...document.querySelectorAll(".alarm-chk:checked")].map(e=>+e.dataset.id));if(!e.size)return
;setAlarms(getAlarms().filter(t=>!e.has(t.id)));saveAlarms();if(!getAlarms().length){manageMode=false;document.getElementById("btn-manage").textContent="관리"
;document.getElementById("btn-new").style.display="";document.getElementById("btn-theme").style.display="";document.getElementById("btn-history").style.display=""
;document.getElementById("btn-settings").style.display=""}render()});const i=document.getElementById("coin-input");const a=document.getElementById("price-input")
;const c=document.getElementById("dir-select");const s=document.getElementById("memo-input");i.addEventListener("input",()=>showAC(i.value.trim()))
;i.addEventListener("blur",()=>setTimeout(hideAC,150));i.addEventListener("keydown",e=>{const t=document.getElementById("ac-list");const n=t&&t.style.display!=="none";if(e.key==="ArrowDown"){
e.preventDefault();if(n)moveAC(1)}else if(e.key==="ArrowUp"){e.preventDefault();if(n)moveAC(-1)}else if(e.key==="Enter"){if(n&&acIdx>=0){e.preventDefault();const n=t.querySelector(".ac-item.active")
;if(n)selectAC(n.dataset.sym)}else document.getElementById("btn-confirm").click()}else if(e.key==="Escape")hideAC()});a.addEventListener("keydown",e=>{
if(e.key==="Enter")document.getElementById("btn-confirm").click()});a.addEventListener("input",async()=>{const e=parseFloat(a.value);if(!e||e<=0)return
;const t=i.value.trim().toUpperCase().replace(/^KRW-/,"");if(!t)return;const n=currentExchange==="upbit"?`KRW-${t}`:t;let r=getPrices()[n];if(!r){await prefetchCoinPrice(t);r=getPrices()[n]}
if(!r)return;c.value=e>=r?"above":"below"});document.getElementById("btn-confirm").addEventListener("click",()=>{const e=i.value.trim();const t=c.value;const n=s.value.trim()
;const r=document.querySelector("input[name=atype]:checked")?.value||"price";if(r==="trend")return;if(!e){alert("코인을 입력해줘 (예: BTC)");return}const o=e.toUpperCase().replace(/^KRW-/,"")
;const l=parseFloat(a.value);if(!l||l<=0){alert("목표 가격을 입력해줘");return}if(currentExchange==="upbit"){const e=upbitMarkets.find(e=>e.sym===o);const r=e?e.kor:"";const i=e?`${o}(${r})`:o
;const a=PRICE_REPEAT_MODES.includes(settings.priceLastRepeat)?settings.priceLastRepeat:"interval";const c=PRICE_REPEAT_TFS.includes(settings.priceLastRepeatTf)?settings.priceLastRepeatTf:"15"
;upbitAlarms.push({id:Date.now(),code:"KRW-"+o,sym:o,kor:r,label:i,price:l,dir:t,memo:n,repeat:a,repeatTf:c,fired:false,disabled:false})}else{
const e=PRICE_REPEAT_MODES.includes(settings.priceLastRepeat)?settings.priceLastRepeat:"interval";const r=PRICE_REPEAT_TFS.includes(settings.priceLastRepeatTf)?settings.priceLastRepeatTf:"15"
;bithumbAlarms.push({id:Date.now(),code:"KRW-"+o,sym:o,kor:"",label:o,price:l,dir:t,memo:n,repeat:e,repeatTf:r,fired:false,disabled:false})}saveAlarms();i.value="";a.value="";c.value="above"
;s.value="";hideAC();showView("view-main");render();if(Notification.permission==="default")Notification.requestPermission()});chrome.storage.onChanged.addListener(e=>{let t=false
;if(e[UPBIT_STORAGE_KEY]){upbitAlarms=e[UPBIT_STORAGE_KEY].newValue||[];t=true}if(e[BITHUMB_STORAGE_KEY]){bithumbAlarms=e[BITHUMB_STORAGE_KEY].newValue||[];t=true}if(t)fetchPrices().then(render)})})
;(function e(){function t(){const e=document.getElementById("chk-report");const t=document.getElementById("report-last");const n=document.getElementById("btn-report-now");if(!e||!n)return
;function r(e){if(!t)return;if(!e||!e.ts){t.textContent="마지막 신고: 없음";return}const n=new Date(e.ts)
;const r=`${n.getMonth()+1}/${n.getDate()} ${String(n.getHours()).padStart(2,"0")}:${String(n.getMinutes()).padStart(2,"0")}`
;t.textContent=`마지막 신고: ${r} ${e.ok?"전송됨":"전송 실패"}${e.id?" ("+e.id+")":""}${e.code?" · "+e.code:""}`}try{chrome.storage.local.get(["kt_report_enabled","kt_report_last_v1"],t=>{
e.checked=t.kt_report_enabled===true;r(t.kt_report_last_v1)});e.addEventListener("change",()=>chrome.storage.local.set({kt_report_enabled:e.checked===true}))
;chrome.storage.onChanged.addListener((e,t)=>{if(t==="local"&&e.kt_report_last_v1)r(e.kt_report_last_v1.newValue)});n.addEventListener("click",()=>{const e=n.innerHTML;const t=t=>{n.textContent=t
;setTimeout(()=>{n.innerHTML=e},2e3)};chrome.tabs.query({active:true,currentWindow:true},e=>{const n=e&&e[0];if(!n||!n.id){t("탭 없음");return}chrome.tabs.sendMessage(n.id,{action:"ktaReportNow"},()=>{
if(chrome.runtime.lastError){t("거래소 탭에서 눌러주세요");return}t("보냈어요 ✓")})})})}catch(e){}}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",t);else t()})();(function e(){
const t=document.getElementById("hdr-ver");if(!t)return;try{t.textContent="v"+chrome.runtime.getManifest().version}catch(e){t.textContent="v?"}})();
(function(){"use strict";if(window.__ktaGen)return;if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}window.addEventListener("error",function(e){
if(e.message&&e.message.includes("Extension context invalidated"))e.preventDefault()});const e="bithumb_alarms_v1";const t="upbit_alarm_settings_v1";const n="kta_alarm_history_bithumb_v1";const o=50
;const r=2e3;let i=[];let a={sound:"fanfare",volume:70,reactivate:"custom",reactivateMinutes:1};function c(){try{return!!chrome.runtime.id}catch{return false}}function s(e){return!e.fired&&!e.disabled
}if(window.__ktaBtReporter){try{window.__ktaBtReporter.stop()}catch(e){}window.__ktaBtReporter=null}const l=function(){try{
if(!window.__ktReport||!window.__ktProbes||!window.__ktProbes.bithumb)return null;const e=window.__ktReport.createReporter({product:"kalert",exchange:"bithumb",
version:chrome.runtime.getManifest().version,probes:window.__ktProbes.bithumb.probes,skeletonRoots:window.__ktProbes.bithumb.skeletonRoots,isPageReady:()=>location.pathname.includes("/trade/"),
getMarket:()=>{const e=location.pathname.match(/\/order\/([A-Z0-9]+-[A-Z]+)/i);return e?e[1]:""},transport:e=>{try{chrome.runtime.sendMessage({action:"ktaReport",payload:e},()=>{
void chrome.runtime.lastError})}catch(e){}}});window.__ktaBtReporter=e;return e}catch(e){return null}}();function d(e,t){try{if(l)l.fail(e,t||{})}catch(e){}}try{
chrome.runtime.onMessage.addListener((e,t,n)=>{if(e&&e.action==="ktaPing"){n&&n({ok:true,script:"bithumb_content.js"});return}if(e&&e.action==="ktaReportNow"){if(l){try{l.manualReport()}catch(e){}}
n&&n({ok:!!l})}})}catch(e){}function u(){chrome.storage.local.get(t,e=>{a={sound:"fanfare",reactivate:"custom",reactivateMinutes:1,...e[t]||{}}})}function m(){chrome.storage.local.get(e,t=>{i=t[e]||[]
;if(i.some(s))_()})}function f(t){chrome.storage.local.get(e,n=>{const o=n[e]||[];const r=o.find(e=>e.id===t);if(r){r.disabled=true;r.fired=false}chrome.storage.local.set({[e]:o})})}function b(t){
chrome.storage.local.get(e,n=>{const o=n[e]||[];const r=o.find(e=>e.id===t);if(r){r.disabled=false}chrome.storage.local.set({[e]:o})})}function h(){switch(a.reactivate){case"30min":return 30*60*1e3
;case"1hour":return 60*60*1e3;case"custom":return Math.max(1,a.reactivateMinutes||60)*60*1e3;default:return 0}}function p(){if(a.sound==="none")return
;fetch(chrome.runtime.getURL(`sounds/${a.sound}.wav`)).then(e=>e.blob()).then(e=>{const t=URL.createObjectURL(e);const n=new Audio(t);n.volume=(a.volume??70)/100;n.play().catch(()=>{})
;n.addEventListener("ended",()=>URL.revokeObjectURL(t))}).catch(()=>{})}function w(){if(!c()){if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}return}
const e=[...new Set(i.filter(s).map(e=>e.sym))];if(!e.length){if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}return}try{chrome.runtime.sendMessage({
action:"fetchBithumbPrices"},t=>{try{if(chrome.runtime.lastError||!t||!t.ok)return;e.forEach(e=>{if(t.prices[e]!==undefined)g(e,t.prices[e])})}catch{}})}catch{if(window.__btPollTimer){
clearInterval(window.__btPollTimer);window.__btPollTimer=null}}}function _(){if(window.__btPollTimer)clearInterval(window.__btPollTimer);w();window.__btPollTimer=setInterval(w,r)}function g(e,t){
i.forEach(n=>{if(!s(n)||n.sym!==e)return;const o=n.dir==="above"&&t>=n.price||n.dir==="below"&&t<=n.price;if(o){n.disabled=true;n.fired=false;f(n.id);k(n,t)}})}function v(e,t,n){
const o=document.createElement("div")
;o.style.cssText=`\n      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);\n      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));\n      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;\n      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;\n      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);\n      transition:transform .35s cubic-bezier(.2,1,.4,1);\n      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;\n      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;\n    `
;const r=document.createElement("div");r.textContent=e;o.appendChild(r);if(t){const e=document.createElement("div");e.textContent=t
;e.style.cssText="margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;";o.appendChild(e)}document.body.appendChild(o);requestAnimationFrame(()=>{
o.style.transform="translateX(-50%) translateY(0)"});const i=()=>{o.style.transform="translateX(-50%) translateY(-80px)";setTimeout(()=>o.remove(),400)};o.addEventListener("click",()=>{
if(n)window.location.href=n;i()});setTimeout(i,7e3)}function x(e,t){chrome.storage.local.get(n,r=>{const i=r[n]||[];i.unshift({id:Date.now(),exchange:"bithumb",label:e.label,sym:e.sym,price:e.price,
dir:e.dir,currentPrice:t,memo:e.memo||"",firedAt:Date.now(),unread:true});if(i.length>o)i.length=o;chrome.storage.local.set({[n]:i})})}function k(e,t){x(e,t);if(c())chrome.runtime.sendMessage({
action:"sendPush",alarm:e,currentPrice:t,exchange:"bithumb"},()=>{});const n=e.dir==="above"?"이상":"이하"
;const o=`${e.label} ${Number(e.price).toLocaleString()}원 ${n} 도달!\n현재가: ${Number(t).toLocaleString()}원`;const r=`https://www.bithumb.com/react/trade/order/${e.sym}-KRW`;v(`🔔 ${o}`,e.memo||"",r)
;if(Notification.permission==="granted"){new Notification("🔔 빗썸 가격 알람",{body:o})}p();const i=h();setTimeout(()=>b(e.id),i)}chrome.storage.onChanged.addListener(n=>{if(n[e]){i=n[e].newValue||[]
;if(i.some(s))_();else if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}}if(n[t]){a={sound:"fanfare",reactivate:"custom",reactivateMinutes:1,...n[t].newValue||{}}
}});if(Notification.permission==="default")Notification.requestPermission();u();m();function y(){
const e=location.pathname.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i)||location.pathname.match(/\/react\/trade\/order\/([A-Z0-9]+)-KRW/i);return e?e[1].toUpperCase():null}function P(e){
if(document.getElementById("kta-quick-add-btn"))return;const t=document.createElement("button");t.id="kta-quick-add-btn";t.textContent="+";t.title=`${e} 알람 추가`;Object.assign(t.style,{position:"fixed",
bottom:"80px",right:"20px",width:"46px",height:"46px",borderRadius:"50%",background:"linear-gradient(160deg,#fb923c,#ea580c)",color:"#fff",fontSize:"21px",fontWeight:"bold",border:"none",
cursor:"pointer",zIndex:"999999",boxShadow:"0 10px 24px -6px #ea580c, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(251,146,60,.16)",display:"flex",alignItems:"center",justifyContent:"center",
fontFamily:"'Pretendard',system-ui,sans-serif",transition:".18s"});t.addEventListener("click",()=>{if(!c())return;chrome.runtime.sendMessage({action:"quickAdd",sym:e})});document.body.appendChild(t)}
function R(){chrome.storage.local.get("upbit_alarm_settings_v1",e=>{const t=e["upbit_alarm_settings_v1"]||{};if(t.quickAddBtn===false)return;const n=y()
;if(n)P(n);else if(location.pathname.includes("/trade/"))d("sym_parse_failed",{step:"getBithumbSym"})})}R();let T=location.href;setInterval(()=>{if(location.href!==T){T=location.href
;document.getElementById("kta-quick-add-btn")?.remove();R()}},500);window.addEventListener("popstate",()=>{document.getElementById("kta-quick-add-btn")?.remove();R()})})();
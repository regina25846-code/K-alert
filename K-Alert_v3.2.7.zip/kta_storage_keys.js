"use strict";(function(t){const _={HISTORY_KEY_LEGACY:"kta_alarm_history_v1",HISTORY_KEYS:{upbit:"kta_alarm_history_upbit_v1",bithumb:"kta_alarm_history_bithumb_v1"}}
;_.HISTORY_KEYS_ALL=[_.HISTORY_KEYS.upbit,_.HISTORY_KEYS.bithumb,_.HISTORY_KEY_LEGACY];if(typeof module==="object"&&module.exports)module.exports=_;t.KTA_KEYS=_
})(typeof window!=="undefined"?window:globalThis);
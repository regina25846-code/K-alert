"use strict";(function(t,e){const n=e();if(typeof module==="object"&&module.exports)module.exports=n;else if(t&&!t.__ktReport)t.__ktReport=n})(typeof window!=="undefined"?window:globalThis,function(){
const t=1;const e=[{name:"email",re:/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g},{name:"jwt",re:/eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}(?:\.[A-Za-z0-9_-]{8,})?/g},{name:"phone",
re:/(?<!\d)0\d{1,2}[-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)/g},{name:"account",re:/(?<!\d)\d{2,6}-\d{2,6}-\d{2,8}(?:-\d{2,8})?(?!\d)/g},{name:"currency",re:/(?<![\d,])\d{1,3}(?:,\d{3})+(?:\.\d+)?/g},{
name:"longdigits",re:/(?<!\d)\d{8,}(?!\d)/g},{name:"hex32",re:/(?<![A-Za-z0-9])[A-Fa-f0-9]{32,}(?![A-Za-z0-9])/g},{name:"token40",
re:/(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{40,}={0,2}(?![A-Za-z0-9+/_-])/g,textOnly:true}];const n="[redacted]";function r(t){let r=String(t==null?"":t);let o=0;for(const t of e){r=r.replace(t.re,()=>{
o++;return n})}return{text:r,replaced:o}}function o(t){let r=String(t==null?"":t);let o=0;for(const t of e){if(t.textOnly)continue;r=r.replace(t.re,()=>{o++;return n})}return{text:r,replaced:o}}
const s=["id","class","data-testid","role","aria-selected","type","disabled"];const i={id:"i",class:"c","data-testid":"d",role:"r","aria-selected":"s",type:"y",disabled:"z"}
;const c=["매수","매도","지정가","시장가","예약","지정","시장","10%","25%","50%","75%","100%","최대","매수 확인","매도 확인","주문 확인","확인","취소","주문취소","일괄취소","주문 취소","아니오","미체결","체결","미체결 주문","체결 주문","거래내역","원화","보유","관심","연장","로그인"]
;const a=new Set(c);const l={maxDepth:12,maxNodes:1500,maxBytes:65536};function u(t){return String(t==null?"":t).replace(/\s+/g," ").trim()}function d(t){const e={};if(!t)return e;for(const n of s){
if(t[n]!=null)e[n]=String(t[n])}return e}function f(t){if(t&&typeof t.tag==="string"){return{tag:t.tag.toLowerCase(),attrs:d(t.attrs),text:t.text||"",children:Array.isArray(t.children)?t.children:[]}}
const e={};for(const n of s){let r=null;try{r=typeof t.getAttribute==="function"?t.getAttribute(n):null}catch(t){r=null}if(r!=null)e[n]=String(r)}const n=[];let r="";const o=t&&t.childNodes||[]
;for(let t=0;t<o.length;t++){const e=o[t];if(!e)continue;if(e.nodeType===3)r+=e.nodeValue||"";else if(e.nodeType===1)n.push(e)}return{tag:String(t&&t.tagName||"").toLowerCase(),attrs:e,text:r,
children:n}}function g(t,e){const n=Object.assign({},l,e||{});const r=[];let o=0;let c=false;(function t(e,l){if(c)return;if(o>=n.maxNodes){c=true;return}let d;try{d=f(e)}catch(t){return}o++;const g={
t:d.tag,d:l};for(const t of s){if(d.attrs[t]!=null)g[i[t]]=d.attrs[t].slice(0,200)}const h=u(d.text);if(h)g.x=a.has(h)?h:"#t"+h.length;r.push(g);if(l>=n.maxDepth){
if(d.children.length)g.m=d.children.length;return}for(const e of d.children)t(e,l+1)})(t,0);let d=JSON.stringify(r);while(d.length>n.maxBytes&&r.length>1){r.length=Math.max(1,Math.floor(r.length*.8))
;c=true;d=JSON.stringify(r)}return{nodes:r,truncated:c}}function h(t,e){const n=[];for(const r of t||[]){const t={k:r.key,n:-1};try{const n=e.querySelectorAll(r.css);if(r.mode==="label"){
const e=u(r.label);let o=0;for(let t=0;t<n.length;t++){if(u(n[t].textContent)===e)o++}t.n=o}else{t.n=n.length;if(r.mode==="classSig"&&n.length){let e=null;try{e=n[0].getAttribute("class")}catch(t){
e=null}t.c=String(e||"").slice(0,200)}}}catch(e){t.n=-1;t.e=1}n.push(t)}return n}function p(t){let e=2166136261,n=16777619;for(let r=0;r<t.length;r++){const o=t.charCodeAt(r);e^=o
;e=Math.imul(e,16777619)>>>0;n^=o;n=Math.imul(n,2166136261)>>>0}return e.toString(16).padStart(8,"0")+n.toString(16).padStart(8,"0")}function y(t){const e=p(t).slice(0,12).split("")
;for(const t of[0,6]){if(e[t]>="0"&&e[t]<="9")e[t]="abcdef"[Number(e[t])%6]}return e.join("")}function m(t,e){const n=new Set((t||[]).filter(t=>t.volatile).map(t=>t.key));const r=[];for(const o of e){
if(n.has(o.k))continue;const e=(t||[]).find(t=>t.key===o.k)||{};const s=e.mode==="count"?o.n:o.n>0?1:o.n;r.push([o.k,s,o.c||""])}return p(JSON.stringify(r))}const S={threshold:3,thresholdLow:5,
windowMs:10*60*1e3,cooldownMs:6*60*60*1e3,dailyCap:10,driftConfirm:2,driftIntervalMs:5*60*1e3,historyKeep:60*60*1e3};function b(t){return new Date(t).toISOString().slice(0,10)}function x(t,e,n,r,o){
return[t,e,n,r||"",o].join("|").replace(/[^A-Za-z0-9_|.:-]/g,"_").slice(0,200)}function k(t,e,n,r){const o=Object.assign({},S,r&&r.policy||{});const s=r&&r.severity||"high";const i={
events:Object.assign({},e&&e.events||{}),lastSent:Object.assign({},e&&e.lastSent||{}),daily:Object.assign({day:b(n),n:0},e&&e.daily||{})};if(i.daily.day!==b(n))i.daily={day:b(n),n:0}
;for(const t of Object.keys(i.events)){i.events[t]=i.events[t].filter(t=>n-t<o.historyKeep);if(!i.events[t].length)delete i.events[t]}const c=(i.events[t]||[]).concat([n]);i.events[t]=c
;const a=c.filter(t=>n-t<=o.windowMs).length;const l=s==="low"?o.thresholdLow:o.threshold;if(r&&r.countOnly)return{report:false,reason:"count_only",count:a,history:i};if(a<l)return{report:false,
reason:"below_threshold",count:a,history:i};const u=i.lastSent[t]||0;if(u&&n-u<o.cooldownMs)return{report:false,reason:"cooldown",count:a,history:i};if(i.daily.n>=o.dailyCap)return{report:false,
reason:"daily_cap",count:a,history:i};i.lastSent[t]=n;i.daily.n+=1;return{report:true,reason:"threshold",count:a,history:i}}function w(t,e,n){const r=Object.assign({},S,n&&n.policy||{})
;const o=Object.assign({baseline:null,pendingSig:null,pendingCount:0},t||{});if(!o.baseline)return{report:false,state:{baseline:e,pendingSig:null,pendingCount:0}};if(e===o.baseline)return{
report:false,state:{baseline:o.baseline,pendingSig:null,pendingCount:0}};if(o.pendingSig===e){const t=o.pendingCount+1;if(t>=r.driftConfirm)return{report:true,state:{baseline:e,pendingSig:null,
pendingCount:0}};return{report:false,state:{baseline:o.baseline,pendingSig:e,pendingCount:t}}}return{report:false,state:{baseline:o.baseline,pendingSig:e,pendingCount:1}}}
const v=[/Extension context invalidated/i,/ctx_invalid/i,/rate_limited/i,/(?<!\d)429(?!\d)/];function _(t,e){if(e===false)return true;const n=String(t==null?"":t);return v.some(t=>t.test(n))}
function O(t){const e=[];const n=String(t||"").split("\n");for(const t of n){const n=t.match(/chrome-extension:\/\/[a-z]+\/([A-Za-z0-9_./-]+):(\d+)/);if(n)e.push(n[1]+":"+n[2]);if(e.length>=5)break}
return e}function A(t){const e=String(t||"").match(/Chrome\/(\d+)/);return e?parseInt(e[1],10):0}function C(e){const n=e||{};const s=n.error?{message:r(String(n.error.message||"").slice(0,200)).text,
extFrames:Array.isArray(n.error.extFrames)?n.error.extFrames.slice(0,5):[]}:undefined;const i={schema:1,client:t,kind:n.kind||"error",product:n.product,version:String(n.version||""),
exchange:n.exchange||"unknown",code:String(n.code||"").replace(/[^a-z0-9_]/g,"_").slice(0,64),severity:n.severity||"high",count:n.count||1,windowSec:Math.round(S.windowMs/1e3),
command:String(n.command||"").slice(0,40),step:String(n.step||"").slice(0,60),path:r(String(n.path||"").split("?")[0].split("#")[0].slice(0,120)).text,
market:String(n.market||"").replace(/[^A-Z0-9-]/gi,"").slice(0,20),chromeMajor:n.chromeMajor||0,installId:String(n.installId||"").slice(0,12),ts:n.ts||(new Date).toISOString(),
fingerprint:n.fingerprint||"",error:s,probes:n.probes||[],skeleton:n.skeleton||[],recent:n.recent||{},truncated:!!n.truncated};let c=JSON.stringify(i);const a=o(c);let l;try{l=JSON.parse(a.text)
}catch(t){l=Object.assign({},i,{skeleton:[],probes:[],error:undefined})}l.scrub={replaced:a.replaced};return l}function M(t){const e=t||{};const n=e.doc||(typeof document!=="undefined"?document:null)
;const r=e.win||(typeof window!=="undefined"?window:null);const o=e.storage||(typeof chrome!=="undefined"&&chrome.storage&&chrome.storage.local?chrome.storage.local:null);const s="kt_report_enabled"
;const i="kt_report_hist_v1";const c="kt_report_drift_v1";const a="kt_report_install_v1";const u=Object.assign({},S,e.policy||{});let d=false;let f=null;let p=null;let b="";let v=null;let M=false
;let j=false;const I=[];function z(t){return new Promise(e=>{try{o.get(t,t=>e(t||{}))}catch(t){e({})}})}function N(t){try{o.set(t,()=>{try{void chrome.runtime.lastError}catch(t){}})}catch(t){}}
function L(){if(!o){j=true;return Promise.resolve()}return z([s,i,c,a]).then(t=>{d=t[s]===true;f=t[i]||null;p=t[c]&&t[c][e.exchange]||null;b=t[a]||"";if(!b){let t="";try{
t=typeof crypto!=="undefined"&&crypto.randomUUID?crypto.randomUUID():""}catch(t){}if(!t)t=Date.now().toString(36)+Math.random().toString(36).slice(2,10);b=y(t);N({[a]:b})}else if(/\d{8}/.test(b)){
b=y(b);N({[a]:b})}j=true;while(I.length){const t=I.shift();try{t()}catch(t){}}if(d)B()})}try{if(o&&typeof chrome!=="undefined"&&chrome.storage&&chrome.storage.onChanged){
chrome.storage.onChanged.addListener((t,e)=>{if(e!=="local"||!t[s])return;d=t[s].newValue===true;if(d)B();else V()})}}catch(t){}function T(){try{return e.isPageReady?!!e.isPageReady():true}catch(t){
return false}}function Z(){const t=e.skeletonRoots||[];const r=[];let o=false;let s=l.maxNodes;for(const e of t){let t=null;try{t=n.querySelector(e)}catch(e){t=null}if(!t){r.push({root:e,found:false})
;continue}const i=g(t,{maxNodes:Math.max(50,s)});s-=i.nodes.length;o=o||i.truncated;r.push({root:e,found:true,nodes:i.nodes});if(s<=0){o=true;break}}return{skeleton:r,truncated:o}}function D(t){
const e={};const n=f&&f.events||{};for(const r of Object.keys(n)){const o=n[r].filter(e=>t-e<=u.windowMs).length;if(o)e[r.split("|")[2]||r]=o}return e}function R(){try{return r.location.pathname
}catch(t){return""}}function E(){try{return e.getMarket?String(e.getMarket()||""):""}catch(t){return""}}function P(t,r,o,s){const i=Date.now();let c={skeleton:[],truncated:false};try{c=Z()}catch(t){}
let a=[];try{a=h(e.probes||[],n)}catch(t){}const l=C({kind:t,product:e.product,version:e.version,exchange:e.exchange,code:r,severity:o&&o.severity||"high",count:s,command:o&&o.command,step:o&&o.step,
path:R(),market:E(),chromeMajor:A(typeof navigator!=="undefined"?navigator.userAgent:""),installId:b,ts:new Date(i).toISOString(),fingerprint:x(e.product,e.exchange,r,o&&o.key,e.version),
error:o&&(o.message||o.stack)?{message:o.message,extFrames:O(o.stack)}:undefined,probes:a,skeleton:c.skeleton,recent:D(i),truncated:c.truncated});try{e.transport&&e.transport(l)}catch(t){}return l}
function F(t,n){if(M)return;if(!j){I.push(()=>F(t,n));return}if(!d)return;if(!T())return;const r=n||{}
;if((r.message||r.stack)&&_(r.message||r.stack,typeof navigator!=="undefined"?navigator.onLine:true))return;const o=Date.now();const s=x(e.product,e.exchange,t,r.key,e.version);const c=k(s,f,o,{
severity:r.severity,countOnly:!!r.countOnly,policy:u});f=c.history;N({[i]:f});if(c.report)P("error",t,r,c.count)}function J(){const t=()=>{try{P("manual","manual_report",{severity:"low",step:"popup"
},1)}catch(t){}};if(!j)I.push(t);else t()}function U(){if(M||!d||!T())return;const t=e.probes||[];if(!t.length)return;let r;try{r=h(t,n)}catch(t){return}const o=m(t,r);const s=w(p,o,{policy:u})
;p=s.state;z([c]).then(t=>{const n=Object.assign({},t[c]||{});n[e.exchange]=p;N({[c]:n})});if(s.report)P("drift","dom_drift",{severity:"low",step:"driftCheck",key:o},1)}function B(){if(v||M||!r)return
;if(!(e.probes||[]).length)return;v=r.setInterval(U,u.driftIntervalMs);r.setTimeout(U,5e3)}function V(){if(v&&r){r.clearInterval(v);v=null}}function q(){M=true;V()}L();return{fail:F,manualReport:J,
driftCheck:U,start:B,stop:q,isEnabled:()=>d}}return{CLIENT_VERSION:t,SCRUB_PATTERNS:e,ALLOWED_ATTRS:s,LABEL_WHITELIST:c,LIMITS:l,POLICY:S,scrubText:r,scrubJsonString:o,readNode:f,serializeTree:g,
runProbes:h,probeSignature:m,hashString:p,fingerprintOf:x,shouldReport:k,driftDecide:w,isExcludedError:_,extFramesFrom:O,chromeMajorOf:A,buildPayload:C,createReporter:M}});
(function(){"use strict";const e=window.__ktaGen=(window.__ktaGen||0)+1;function t(){return window.__ktaGen===e}if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}
if(window.__ktaTrendTimer){clearInterval(window.__ktaTrendTimer);window.__ktaTrendTimer=null}window.addEventListener("error",function(e){
if(e.message&&e.message.includes("Extension context invalidated"))e.preventDefault()});const n=/(^|\.)bithumb\.com$/i.test(location.hostname);const r=n?{id:"bithumb",name:"빗썸",
storageKey:"bithumb_alarms_v1",historyKey:window.KTA_KEYS.HISTORY_KEYS.bithumb,chartHostId:"coin-chart",probeKey:"bithumb",getSym:()=>{
const e=location.pathname.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i);return e?e[1].toUpperCase():null},trendBlockedTfs:["360","720"],isTradePage:()=>location.pathname.includes("/trade/"),
symExpected:()=>location.pathname.includes("/trade/order/"),coinUrl:e=>`https://www.bithumb.com/react/trade/order/${e}-KRW`,fabMain:"linear-gradient(160deg,#fb923c,#ea580c)",
fabShadow:"0 10px 24px -6px #ea580c, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(251,146,60,.16)"}:{id:"upbit",name:"업비트",storageKey:"upbit_alarms_v2",
historyKey:window.KTA_KEYS.HISTORY_KEYS.upbit,chartHostId:"tv_chart_container",probeKey:"upbit",getSym:()=>{const e=location.search.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i)
;return e?e[1].toUpperCase():null},trendBlockedTfs:[],isTradePage:()=>location.pathname==="/exchange",symExpected:()=>location.pathname==="/exchange"&&location.search.length>1,
coinUrl:e=>`https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${e}`,fabMain:"linear-gradient(160deg,#60a5fa,#2563eb)",
fabShadow:"0 10px 24px -6px #2563eb, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(96,165,250,.16)"};function i(e){if(!e)return"";const t=typeof e.code==="string"?e.code:""
;if(t.indexOf("KRW-")===0)return t;if(e.sym)return"KRW-"+String(e.sym).toUpperCase();if(t)return"KRW-"+t.toUpperCase();return""}const a=r.storageKey;const o="upbit_alarm_settings_v1"
;const c="kta_chart_settings_v1";const s=r.historyKey;const l=50;const d=1500;const u="interval";const f="15";const p=["perBar","once","interval"]
;const m=["1","3","5","10","15","30","60","240","1D","1W","1M"];function h(e){return p.includes(e.repeat)?e.repeat:u}function w(e){return m.includes(e.repeatTf)?e.repeatTf:f}let g=Promise.resolve()
;function b(e){g=g.then(()=>new Promise(t=>{let n=false;const r=()=>{if(!n){n=true;t()}};setTimeout(r,5e3);try{chrome.storage.local.get(a,t=>{try{const n=t[a]||[];const i=e(n);if(i===false){r();return
}chrome.storage.local.set({[a]:Array.isArray(i)?i:n},r)}catch(e){r()}})}catch(e){r()}}));return g}function k(e,t){let n=e.a1,r=e.a2;if(!n||!r)return null;if(r.t<n.t){const e=n;n=r;r=e}
const i=n.t,a=n.p,o=r.t,c=r.p;if(![i,o,a,c,t].every(Number.isFinite))return null;if(o===i)return null;const s=(t-i)/(o-i);const l=e.extend||"right";if(l==="none"&&(s<0||s>1))return null
;if(l==="right"&&s<0)return null;if(e.scale==="log"){if(a<=0||c<=0)return null;return a*Math.pow(c/a,s)}return a+(c-a)*s}function v(e){const t={"1S":1,1:60,3:180,5:300,10:600,15:900,30:1800,60:3600,
240:14400,"1D":86400,"1W":604800,"1M":2592e3};return t[e]||60}function _(e){return Math.min(3e5,Math.max(3e4,v(e)*1e3/4))}const y=new Map;function T(e,t){const n=v(e);const r=y.get(e)||0
;return Math.floor((t-r)/n)*n+r}function x(e,t,n){return new Promise((i,a)=>{if(!q()){a(new Error("ctx_invalid"));return}try{chrome.runtime.sendMessage({action:"fetchCandles",market:e,tf:t,count:n,
exchange:r.id,maxAgeMs:_(t)},e=>{if(chrome.runtime.lastError||!e||!e.ok){const n=e&&e.error||"fetch_failed";if(!(e&&e.rateLimited))z("candle_fetch_failing",{step:"fetchCandles",key:t,severity:"low",
message:n});a(new Error(n));return}i(e.candles)})}catch(e){a(e)}})}function E(e,t){const n=Math.floor(new Date(t.candle_date_time_utc+"Z").getTime()/1e3);const r=v(e.tf)
;if(Number.isFinite(n)&&r>0)y.set(e.tf,(n%r+r)%r);const i=k(e,n);const a=k(e,n+r);if(i==null&&a==null)return{touched:false,barTimeSec:n};const o=i==null?a:a==null?i:Math.min(i,a)
;const c=i==null?a:a==null?i:Math.max(i,a);const s=t.low_price<=c&&t.high_price>=o;return{touched:s,lineLo:o,lineHi:c,barTimeSec:n}}const L=new Map;function P(e,t,n){const r=k(e,n);if(r==null)return
;const i=t-r;const a=L.get(e.id);L.set(e.id,i);if(a===undefined)return;const o=a<=0&&i>=0||a>=0&&i<=0;if(!o)return;const c=T(e.tf,n);N(e,t,r,c)}const S=new Map;let R=null;function C(){
if(R)clearInterval(R);if(window.__ktaTrendTimer)clearInterval(window.__ktaTrendTimer);R=null;window.__ktaTrendTimer=null}async function B(e,t){try{const n=v(e.tf);const r=t?Math.ceil(t/1e3/n):1
;const a=Math.min(50,Math.max(3,r+2));const o=await x(i(e),e.tf,a);if(!o||!o.length)return;const c=[...o].sort((e,t)=>new Date(e.candle_date_time_utc)-new Date(t.candle_date_time_utc))
;const s=W.find(t=>t.id===e.id);if(!s||!H(s))return;if(s.armPending&&Date.now()-s.armPending<15e3)return;const l=s.lastFiredBarT;let d=null;for(const e of c){const{touched:t,barTimeSec:n}=E(s,e)
;if(!t||n===s.armedBarTime)continue;if(l!=null&&n<=l)continue;d={c:e,barTimeSec:n}}if(!d)return;const u=Math.floor(Date.now()/1e3);const f=k(s,u)
;N(s,d.c.trade_price,f!=null?f:d.c.trade_price,d.barTimeSec)}catch(e){}}function M(){if(!t()){C();return}if(!q()){C();return}const e=Date.now();const n=W.filter(e=>e.type==="trend"&&H(e))
;if(!n.length){C();return}n.forEach(t=>{const n=S.get(t.id)||{lastCheckAt:0};if(e-n.lastCheckAt<_(t.tf))return;const r=n.lastCheckAt?e-n.lastCheckAt:0;n.lastCheckAt=e;S.set(t.id,n);B(t,r)})}
function I(){if(!t())return;if(R&&window.__ktaTrendTimer===R)return;C();M();R=setInterval(M,5e3);window.__ktaTrendTimer=R}const K=window.__ktaFireLock=window.__ktaFireLock||{};const A=3e3
;function D(e,t){const n=Date.now();const r=K[e];if(r&&(t<=r.bar||n-r.at<A))return false;K[e]={bar:t,at:n};return true}function F(e){delete K[e]}function N(e,t,n,r){const i=e.repeat||"perBar"
;if(e.lastFiredBarT!=null&&r<=e.lastFiredBarT)return;if(!D(e.id,r))return;e.lastFiredBarT=r;if(i==="perBar"){b(t=>{const n=t.find(t=>t.id===e.id);if(!n)return false;n.lastFiredBarT=r;return t})
}else if(i==="once"){e.disabled=true;J(e.id,null,r)}else{e.disabled=true;const t=ee();J(e.id,t>0?Date.now()+t:null,r)}_e(e,t,i==="interval"?ee():0,n)}function U(e){L.delete(e);F(e)
;chrome.storage.local.get(a,t=>{const n=t[a]||[];const r=n.find(t=>t.id===e);if(!r||r.type!=="trend")return;const o=(t,n)=>{b(r=>{const i=r.find(t=>t.id===e);if(!i)return false;i.armedBarTime=t
;i.lastFiredBarT=n!=null?n:null;delete i.armPending;return r})};x(i(r),r.tf,1).then(e=>{const t=e&&e[0];if(!t){o(null,null);return}const{touched:n,barTimeSec:i}=E(r,t);o(n?i:null,i-v(r.tf))
}).catch(()=>o(null,null))})}let W=[];let $={sound:"fanfare",volume:70,reactivate:"custom",reactivateMinutes:1};function q(){try{return!!chrome.runtime.id}catch{return false}}function H(e){
return!e.fired&&!e.disabled}if(window.__ktaReporter){try{window.__ktaReporter.stop()}catch(e){}window.__ktaReporter=null}if(window.__ktaBtReporter){try{window.__ktaBtReporter.stop()}catch(e){}
window.__ktaBtReporter=null}if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}const Y=function(){try{
if(!window.__ktReport||!window.__ktProbes||!window.__ktProbes[r.probeKey])return null;const e=window.__ktReport.createReporter({product:"kalert",exchange:r.id,
version:chrome.runtime.getManifest().version,probes:window.__ktProbes[r.probeKey].probes,skeletonRoots:window.__ktProbes[r.probeKey].skeletonRoots,
isPageReady:()=>r.isTradePage()&&!!document.getElementById(r.chartHostId),getMarket:()=>{const e=r.getSym();return e?"KRW-"+e:""},transport:e=>{try{chrome.runtime.sendMessage({action:"ktaReport",
payload:e},()=>{void chrome.runtime.lastError})}catch(e){}}});window.__ktaReporter=e;return e}catch(e){return null}}();function z(e,n){try{if(Y&&t())Y.fail(e,n||{})}catch(e){}}
window.addEventListener("kta-report",e=>{if(!t())return;const n=e&&e.detail||{};z(String(n.code||"chart_error"),{step:n.step,key:n.key,severity:n.severity,message:n.message})});function O(){
chrome.storage.local.get(o,e=>{$={sound:"ding",reactivate:"custom",reactivateMinutes:1,trendSameAsPrice:true,trendSound:"ding3",trendLastExtend:"right",trendLastScale:"linear",
trendLastRepeat:"perBar",priceLastRepeat:"interval",priceLastRepeatTf:"15",...e[o]||{}};j()})}function j(){window.dispatchEvent(new CustomEvent("kta-alarm-settings",{detail:{reactivate:$.reactivate,
reactivateMinutes:$.reactivateMinutes}}))}function X(){chrome.storage.local.get(c,e=>{const t=e[c];if(t)window.dispatchEvent(new CustomEvent("kta-line-settings",{detail:t}))})}function Z(){
const e=Date.now();const t=[];W.forEach(n=>{if(n.disabled&&n.reactivateAt&&e>=n.reactivateAt){n.disabled=false;delete n.reactivateAt;t.push(n.id)}});if(!t.length)return;b(e=>{let n=false
;e.forEach(e=>{if(t.indexOf(e.id)===-1)return;e.disabled=false;delete e.reactivateAt;n=true});return n?e:false})}function G(){chrome.storage.local.get(a,e=>{W=e[a]||[];V();Z();if(W.some(H))re()
;if(W.some(e=>e.type==="trend"&&H(e)))I();ye()})}function V(){if(n)return;if(W.length)return;try{const e=localStorage.getItem("upbit_alarms_v1");if(!e)return;const t=JSON.parse(e);if(!t.length)return
;W=t.map(e=>({...e,sym:e.code.replace("KRW-",""),kor:"",disabled:e.fired||false,fired:false}));chrome.storage.local.set({[a]:W});localStorage.removeItem("upbit_alarms_v1")}catch{}}function J(e,t,n){
return b(r=>{const i=r.find(t=>t.id===e);if(i){i.disabled=true;i.fired=false;if(t)i.reactivateAt=t;if(n!=null)i.lastFiredBarT=n}return r})}function Q(e){return b(t=>{const n=t.find(t=>t.id===e);if(n){
n.disabled=false;delete n.reactivateAt}return t})}function ee(){switch($.reactivate){case"30min":return 30*60*1e3;case"1hour":return 60*60*1e3;case"custom":
return Math.max(1,$.reactivateMinutes||60)*60*1e3;default:return 0}}function te(e){const t=e&&e.type==="trend"&&$.trendSameAsPrice===false;const n=t?$.trendSound:$.sound;if(n==="none")return
;fetch(chrome.runtime.getURL(`sounds/${n}.wav`)).then(e=>e.blob()).then(e=>{const t=URL.createObjectURL(e);const n=new Audio(t);n.volume=($.volume??70)/100;n.play().catch(()=>{})
;n.addEventListener("ended",()=>URL.revokeObjectURL(t))}).catch(()=>{})}function ne(){if(!t())return;if(!q()){if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}
return}const e=[...new Set(W.filter(H).map(i).filter(Boolean))];if(!e.length){if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}return}try{
chrome.runtime.sendMessage({action:"fetchPrices",codes:e,exchange:r.id},e=>{try{if(chrome.runtime.lastError||!e||!e.ok){z("price_fetch_failing",{step:"fetchPrices",severity:"low",
message:e&&e.error||"fetch_failed"});return}Object.keys(e.prices).forEach(t=>ie(t,e.prices[t]))}catch{}})}catch{if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}}
}function re(){if(!t())return;if(window.__ubPollTimer)clearInterval(window.__ubPollTimer);ne();window.__ubPollTimer=setInterval(ne,d)}function ie(e,t){const n=Math.floor(Date.now()/1e3);W.forEach(r=>{
if(!H(r)||i(r)!==e)return;if(r.type==="trend"){P(r,t,n);return}const a=r.price;const o=r.dir==="above"&&t>=a||r.dir==="below"&&t<=a;if(o)ae(r,t,a,n)})}function ae(e,t,n,r){const i=h(e)
;if(i==="perBar"){const i=T(w(e),r);if(e.lastFiredBarT!=null&&i<=e.lastFiredBarT)return;if(!D(e.id,i))return;e.lastFiredBarT=i;b(t=>{const n=t.find(t=>t.id===e.id);if(!n)return false;n.lastFiredBarT=i
;return t});_e(e,t,0,n)}else if(i==="once"){e.disabled=true;e.fired=false;J(e.id,null);_e(e,t,0,n)}else{e.disabled=true;e.fired=false;const r=ee();J(e.id,r>0?Date.now()+r:null);_e(e,t,r,n)}}
const oe="section.ty02 td.tit em";const ce='li[class*="coin-list-row"]';const se='[class*="coin-list-row__link"]';const le='[class*="coin-list__scroll"]';function de(e){
const t=String(e||"").toUpperCase();if(!t)return null;const n=new RegExp("(^|[^A-Z0-9])"+t.replace(/[^A-Z0-9]/g,"")+"\\/KRW");let r;try{r=document.querySelectorAll(ce)}catch(e){return null}
for(let e=0;e<r.length;e++){const t=(r[e].textContent||"").toUpperCase();if(!n.test(t))continue;let i=null;try{i=r[e].querySelector(se)}catch(e){}return i||r[e]}return null}const ue=30;const fe=50
;const pe=1200;function me(e){if(n)return de(e);const t=String(e||"").toUpperCase()+"/KRW";let r;try{r=document.querySelectorAll(oe)}catch(e){return null}for(let e=0;e<r.length;e++){
if((r[e].textContent||"").trim().toUpperCase()!==t)continue;const n=r[e].parentElement;const i=n&&n.querySelector("a");if(i)return i}return null}function he(){let e=null;if(n){try{
const e=document.querySelector(le);if(e)return e}catch(e){}try{e=document.querySelector(ce)}catch(t){e=null}}else{try{e=document.querySelector(oe)||document.querySelector("section.ty02")}catch(t){
e=null}}for(let t=e;t&&t!==document.body;t=t.parentElement){if(t.scrollHeight>t.clientHeight+40&&t.clientHeight>100)return t}return null}function we(e){try{if(!q())return;chrome.runtime.sendMessage({
action:"ktaNavStat",exchange:r.id,result:e},()=>{void chrome.runtime.lastError})}catch(e){}}function ge(e,t,n){let i=false;const a=e=>{if(i)return;i=true;try{n&&n(e)}catch(e){}};const o=e=>{
a("reload-"+e);if(t)window.location.href=t};const c=String(e||"").toUpperCase();if(!c||!t){o("bad-args");return}if(Ee()===c){a("same");return}if(!r.isTradePage()){o("not-trade-page");return}
const s=e=>{try{e.click()}catch(e){o("click-error");return}const t=Date.now();const n=()=>{if(Ee()===c){a("spa");return}if(Date.now()-t>pe){o("click-timeout");return}setTimeout(n,100)}
;setTimeout(n,100)};const l=me(c);if(l){s(l);return}const d=he();if(!d){o("no-list");return}const u=d.scrollTop;let f=0;try{d.scrollTop=0}catch(e){o("scroll-error");return}const p=()=>{const e=me(c)
;if(e){s(e);return}const t=d.scrollTop>=d.scrollHeight-d.clientHeight-2;if(f++>=ue||t){try{d.scrollTop=u}catch(e){}o("not-found");return}d.scrollTop=d.scrollTop+d.clientHeight*.8;setTimeout(p,fe)}
;setTimeout(p,fe)}function be(e,t,n,r){const i=document.createElement("div")
;i.style.cssText=`\n      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);\n      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));\n      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;\n      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;\n      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);\n      transition:transform .35s cubic-bezier(.2,1,.4,1);\n      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;\n      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;\n    `
;const a=document.createElement("div");a.textContent=e;i.appendChild(a);if(t){const e=document.createElement("div");e.textContent=t
;e.style.cssText="margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;";i.appendChild(e)}document.body.appendChild(i);requestAnimationFrame(()=>{
i.style.transform="translateX(-50%) translateY(0)"});const o=()=>{i.style.transform="translateX(-50%) translateY(-80px)";setTimeout(()=>i.remove(),400)};i.addEventListener("click",()=>{
if(r)ge(r,n,we);else if(n)window.location.href=n;o()});setTimeout(o,7e3)}let ke=Promise.resolve();function ve(e,t,n){const a=n!=null?n:e.price;const o={id:Date.now(),exchange:r.id,label:e.label,
sym:e.sym||i(e).replace("KRW-",""),price:a,dir:e.dir,currentPrice:t,memo:e.memo||"",firedAt:Date.now(),unread:true};ke=ke.then(()=>new Promise(e=>{let t=false;const n=()=>{if(!t){t=true;e()}}
;setTimeout(n,5e3);try{chrome.storage.local.get(s,e=>{try{const t=e[s]||[];t.unshift(o);if(t.length>l)t.length=l;chrome.storage.local.set({[s]:t},n)}catch(e){n()}})}catch(e){n()}}));return ke}
function _e(e,t,n,a){const o=a!=null?a:e.price;ve(e,t,o);if(q())chrome.runtime.sendMessage({action:"sendPush",alarm:{...e,price:o},currentPrice:t,exchange:r.id},()=>{})
;const c=e.type==="trend"?`${e.label} 추세선`:e.label
;const s=e.type==="trend"?`${c} 터치! ${Number(o).toLocaleString()}원\n현재가: ${Number(t).toLocaleString()}원`:`${c} ${Number(o).toLocaleString()}원 ${e.dir==="above"?"이상":"이하"} 도달!\n현재가: ${Number(t).toLocaleString()}원`
;const l=e.sym||String(i(e)||"").replace("KRW-","");const d=r.coinUrl(l);be(`🔔 ${s}`,e.memo||"",d,l);if(Notification.permission==="granted"){new Notification(`🔔 ${r.name} 가격 알람`,{body:s})}te(e)
;if(n>0)setTimeout(()=>Q(e.id),n)}function ye(){const e=Ee();if(!e)return;const t=W.filter(t=>i(t)===`KRW-${e}`);window.dispatchEvent(new CustomEvent("kta-alarms",{detail:t}));j()}
chrome.storage.onChanged.addListener(e=>{if(!t())return;if(e[a]){const t=e[a].oldValue||[];W=e[a].newValue||[];W.forEach(e=>{if(e.type!=="trend")return;const n=t.find(t=>t.id===e.id)
;if(n&&n.disabled&&!e.disabled)U(e.id)});if(W.some(H))re();else if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}if(W.some(e=>e.type==="trend"&&H(e)))I();else C()
;ye()}if(e[o]){$={sound:"ding",reactivate:"custom",reactivateMinutes:1,trendSameAsPrice:true,trendSound:"ding3",trendLastExtend:"right",trendLastScale:"linear",trendLastRepeat:"perBar",
priceLastRepeat:"interval",priceLastRepeatTf:"15",...e[o].newValue||{}};j()}});window.addEventListener("kta-symbol-changed",()=>{if(!t())return;setTimeout(ye,200)})
;window.addEventListener("kta-save-line-settings",e=>{if(!t()||!e.detail||typeof e.detail!=="object")return;const n=e.detail;chrome.storage.local.get(c,e=>{const t=e&&e[c]||{}
;chrome.storage.local.set({[c]:{...t,...n}})})});chrome.storage.onChanged.addListener((e,n)=>{if(n!=="local"||!e[c])return;const r=e[c].newValue
;if(r&&t())window.dispatchEvent(new CustomEvent("kta-line-settings",{detail:r}))});const Te=500;window.addEventListener("kta-update-memo",e=>{if(!t())return;const{id:n,memo:r}=e.detail||{}
;if(!n)return;if(typeof r!=="string")return;if(r.length>Te)return;const i=r.replace(/[\u0000-\u001f\u007f]/g,"");b(e=>{const t=e.find(e=>e.id===n);if(!t)return false;t.memo=i;return e})})
;window.addEventListener("kta-alarm-toggle",e=>{if(!t())return;const{id:n}=e.detail||{};if(!n)return;b(e=>{const t=e.find(e=>e.id===n);if(!t)return false;if(t.disabled){t.disabled=false;t.fired=false
}else{t.disabled=true}return e})});window.addEventListener("kta-alarm-delete",e=>{if(!t())return;const{id:n}=e.detail||{};if(!n)return;b(e=>e.filter(e=>e.id!==n))})
;window.addEventListener("kta-trend-edit-opt",e=>{if(!t())return;const{id:n,field:r,value:i}=e.detail||{};const a={extend:["right","both","none"],scale:["linear","log"],
repeat:["perBar","once","interval"]};if(!n||!a[r]||!a[r].includes(i))return;let c=false;b(e=>{const t=e.find(e=>e.id===n);if(!t||t.type!=="trend")return false;if(t[r]===i)return false;t[r]=i;c=true
;if(r==="extend"||r==="scale")t.armPending=Date.now();return e}).then(()=>{if(!c)return;chrome.storage.local.get(o,e=>{const t={...e[o]||{}}
;if(r==="extend")t.trendLastExtend=i;else if(r==="scale")t.trendLastScale=i;else if(r==="repeat")t.trendLastRepeat=i;chrome.storage.local.set({[o]:t})});if(r==="extend"||r==="scale")U(n);I()})})
;window.addEventListener("kta-price-edit-opt",e=>{if(!t())return;const{id:n,repeat:r,repeatTf:i}=e.detail||{};if(!n||!p.includes(r))return;const a=m.includes(i)?i:null
;const c=Math.floor(Date.now()/1e3);const s=W.find(e=>e.id===n);let l=null;if(s&&s.type!=="trend"&&r==="perBar"&&a&&a!==w(s)){l=T(a,c);K[n]={bar:l,at:Date.now()}}let d=false;b(e=>{
const t=e.find(e=>e.id===n);if(!t||t.type==="trend")return false;const i=h(t);const o=w(t);const c=a||o;if(i===r&&o===c)return false;t.repeat=r;t.repeatTf=c;if(l!=null)t.lastFiredBarT=l;d=true
;return e}).then(()=>{if(!d)return;chrome.storage.local.get(o,e=>{const t={...e[o]||{}};t.priceLastRepeat=r;if(a)t.priceLastRepeatTf=a;chrome.storage.local.set({[o]:t})});re()})})
;window.addEventListener("kta-price-quick-reprice",e=>{if(!t())return;const{id:n,price:i}=e.detail||{};if(!n||!Number.isFinite(i))return;const a=Ee();if(!a){
window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"no-sym"}}));return}const o="KRW-"+a;chrome.runtime.sendMessage({action:"fetchPrices",codes:[o],exchange:r.id
},e=>{if(chrome.runtime.lastError||!e||!e.ok||!Number.isFinite(e.prices?.[o])){window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"price-fetch-failed"}}));return}
const t=e.prices[o];const r=xe(i,t);if(!r){window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"tie"}}));return}b(e=>{const t=e.find(e=>e.id===n);if(!t)return false
;t.price=i;t.dir=r;t.fired=false;t.disabled=false;delete t.reactivateAt;t.lastFiredBarT=null;return e}).then(()=>{F(n);re();window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:true,
id:n,price:i,dir:r}}))})})});chrome.runtime.onMessage.addListener((e,n,i)=>{if(!t())return;if(e&&e.action==="startTrendPick"){window.dispatchEvent(new CustomEvent("kta-start-trend-pick",{detail:{
editId:e.editId}}));i&&i({ok:true})}if(e&&e.action==="startPriceAlarmPick"){window.dispatchEvent(new CustomEvent("kta-start-price-pick",{detail:{editId:e.editId}}));i&&i({ok:true})}
if(e&&e.action==="ktaPing"){i&&i({ok:true,script:"content.js"});return}if(e&&e.action==="ktaGoCoin"){const t=String(e.sym||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,20);if(!t){i&&i({ok:false,
result:"bad-sym"});return}ge(t,r.coinUrl(t),e=>{we(e);try{i&&i({ok:e==="spa",result:e})}catch(e){}});return true}if(e&&e.action==="ktaReportNow"){if(Y&&t()){try{Y.manualReport()}catch(e){}}i&&i({
ok:!!Y})}});window.addEventListener("kta-open-price-popup",()=>{if(!t()||!q())return;const e=Ee();if(!e)return;chrome.runtime.sendMessage({action:"quickAdd",sym:e})});function xe(e,t){
if(!Number.isFinite(e)||!Number.isFinite(t)||t<=0)return null;if(e>t)return"above";if(e<t)return"below";return null}window.addEventListener("kta-price-quick-create",e=>{if(!t())return
;const{price:n,repeatTf:i}=e.detail||{};if(!Number.isFinite(n)||n<=0)return;const a=Ee();if(!a){window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"no-sym"}}));return}
const o="KRW-"+a;chrome.runtime.sendMessage({action:"fetchPrices",codes:[o],exchange:r.id},e=>{if(chrome.runtime.lastError||!e||!e.ok||!Number.isFinite(e.prices?.[o])){
window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"price-fetch-failed"}}));return}const t=e.prices[o];const c=xe(n,t);if(!c){
window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"tie"}}));return}const s=Date.now();const l=p.includes($.priceLastRepeat)?$.priceLastRepeat:u
;const d=m.includes(i)?i:m.includes($.priceLastRepeatTf)?$.priceLastRepeatTf:f;b(e=>{e.push({id:s,code:o,sym:a,kor:"",label:a,exchange:r.id,price:n,dir:c,memo:"",repeat:l,repeatTf:d,fired:false,
disabled:false});return e}).then(()=>{re();window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:true,id:s,price:n,dir:c}}))})})});window.addEventListener("kta-trend-quick-save",e=>{
if(!t())return;const n=e.detail||{};const{a1:i,a2:a,scale:o,tf:c,memo:s,editId:l}=n;if(!i||!a)return;if(c==="1S")return;if(r.trendBlockedTfs.indexOf(String(c))!==-1)return;if(l){b(e=>{
const t=e.find(e=>e.id===l);if(!t)return false;t.a1=i;t.a2=a;t.tf=c;t.fired=false;t.disabled=false;delete t.reactivateAt;t.armPending=Date.now();return e}).then(()=>U(l));return}const d=Ee()
;if(!d)return;const u=$.trendLastExtend||"right";const f=$.trendLastScale||o||"linear";const p=$.trendLastRepeat||"perBar";const m=Date.now();b(e=>{e.push({id:m,code:"KRW-"+d,sym:d,kor:"",label:d,
exchange:r.id,type:"trend",a1:i,a2:a,extend:u,scale:f,tf:c,repeat:p,armedBarTime:null,lastFiredBarT:null,armPending:Date.now(),memo:(s||"").trim(),fired:false,disabled:false});return e}).then(()=>{I()
;U(m)})});document.addEventListener("visibilitychange",()=>{if(!t())return;if(document.visibilityState==="visible"){Z();if(W.some(H))re();if(W.some(e=>e.type==="trend"&&H(e)))I()}})
;if(Notification.permission==="default")Notification.requestPermission();O();X();G();function Ee(){return r.getSym()}function Le(){if(document.getElementById("kta-fab-style"))return
;const e=document.createElement("style");e.id="kta-fab-style"
;e.textContent=`\n#kta-fab-wrap{position:fixed;bottom:80px;right:20px;z-index:999999;width:46px;height:46px;}\n#kta-fab-wrap .kta-fab-main{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;\n  background:${r.fabMain};color:#fff;padding:0;\n  border:none;cursor:pointer;box-shadow:${r.fabShadow};\n  display:flex;align-items:center;justify-content:center;font-family:'Pretendard',system-ui,sans-serif;\n  transition:transform .22s cubic-bezier(.2,1.2,.4,1);z-index:2;}\n#kta-fab-wrap .kta-fab-main svg{display:block;pointer-events:none;}\n#kta-fab-wrap.open .kta-fab-main{transform:rotate(45deg);}\n\n\n#kta-fab-wrap .kta-fab-child{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;\n  border:none;cursor:pointer;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;\n  opacity:0;pointer-events:none;\n  transition:transform .22s cubic-bezier(.2,1.2,.4,1), opacity .18s;\n  box-shadow:0 6px 16px -4px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.3);\n  font-family:'Pretendard',system-ui,sans-serif;white-space:nowrap;text-align:center;line-height:1.15;}\n#kta-fab-wrap.open .kta-fab-child{opacity:1;pointer-events:auto;}\n\n\n#kta-fab-wrap .kta-fab-price{background:linear-gradient(160deg,#fbbf24,#d97706);transform:translateY(0) scale(.6);}\n#kta-fab-wrap.open .kta-fab-price{transform:translateY(-56px) scale(1);}\n#kta-fab-wrap .kta-fab-trend{background:linear-gradient(160deg,#fb7185,#be123c);transition-delay:0s;transform:translateX(0) scale(.6);}\n#kta-fab-wrap.open .kta-fab-trend{transform:translateX(-56px) scale(1);transition-delay:.04s;}\n`
;document.head.appendChild(e)}function Pe(e){if(document.getElementById("kta-fab-wrap"))return;Le();const t=document.createElement("div");t.id="kta-fab-wrap";const n=document.createElement("button")
;n.className="kta-fab-child kta-fab-trend";n.textContent="추세";n.title="추세선 알람 — 차트에서 좌표 찍기";n.addEventListener("click",e=>{e.stopPropagation();t.classList.remove("open")
;window.dispatchEvent(new CustomEvent("kta-start-trend-pick"))});const r=document.createElement("button");r.className="kta-fab-child kta-fab-price";r.textContent="가격";r.title=`${e} 가격 알람 — 차트에서 가격 찍기`
;r.addEventListener("click",e=>{e.stopPropagation();t.classList.remove("open");window.dispatchEvent(new CustomEvent("kta-start-price-pick"))});const i=document.createElement("button")
;i.className="kta-fab-main";i.id="kta-quick-add-btn"
;i.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20"><rect x="10.5" y="3" width="3" height="18" rx="1.5" fill="currentColor"/><rect x="3" y="10.5" width="18" height="3" rx="1.5" fill="currentColor"/></svg>'
;i.title=`${e} 알람 추가`;i.addEventListener("click",e=>{e.stopPropagation();t.classList.toggle("open")});document.addEventListener("click",()=>t.classList.remove("open"));t.appendChild(n)
;t.appendChild(r);t.appendChild(i);document.body.appendChild(t)}function Se(){chrome.storage.local.get("upbit_alarm_settings_v1",e=>{const t=e["upbit_alarm_settings_v1"]||{}
;if(t.quickAddBtn===false)return;const n=Ee();if(n)Pe(n);else if(r.symExpected())z("market_detect_failed",{step:"getUpbitSym"})})}Se();let Re=location.href;const Ce=setInterval(()=>{if(!t()){
clearInterval(Ce);return}if(location.href!==Re){Re=location.href;document.getElementById("kta-fab-wrap")?.remove();Se();ye()}},500);window.addEventListener("popstate",()=>{if(!t())return
;document.getElementById("kta-fab-wrap")?.remove();Se()})})();
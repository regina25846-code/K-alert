importScripts("kta_report_secret.js");importScripts("kta_storage_keys.js");const CURRENT_VERSION=(()=>{try{return chrome.runtime.getManifest().version||""}catch(t){return""}})()
;const HISTORY_KEYS_ALL=self.KTA_KEYS.HISTORY_KEYS_ALL;const SETTINGS_KEY="upbit_alarm_settings_v1";const PUSH_COOLDOWN_KEY="kta_push_cooldown_v1";const NAV_STATS_KEY="kta_nav_stats_v1"
;const VERSION_CHECK_URL="https://alert.krisb-infra.com/version.json";const UPDATE_PAGE_URL="https://alert.krisb-infra.com/";const UPDATE_CHECKED_AT_KEY="kta_update_checked_at_v1"
;const UPDATE_MIN_INTERVAL_MS=60*1e3;function updateBadge(){chrome.storage.local.get(HISTORY_KEYS_ALL.concat(["pendingUpdate"]),t=>{const e=self.KTA_KEYS.HISTORY_KEYS.upbit
;const n=self.KTA_KEYS.HISTORY_KEYS.bithumb;const a=e=>(t[e]||[]).filter(t=>t.unread).length;let r=a(e)+a(n);const o=t[self.KTA_KEYS.HISTORY_KEY_LEGACY]||[]
;if(t[e]===undefined)r+=o.filter(t=>t.unread&&t.exchange!=="bithumb").length;if(t[n]===undefined)r+=o.filter(t=>t.unread&&t.exchange==="bithumb").length;if(r>0){chrome.action.setBadgeText({
text:String(r)});chrome.action.setBadgeBackgroundColor({color:"#ef5350"})}else if(t.pendingUpdate){chrome.action.setBadgeText({text:"UP"});chrome.action.setBadgeBackgroundColor({color:"#ef5350"})
}else{chrome.action.setBadgeText({text:""})}})}function isNewerVersion(t,e){const n=String(t).split(".").map(t=>parseInt(t,10)||0);const a=String(e).split(".").map(t=>parseInt(t,10)||0)
;const r=Math.max(n.length,a.length);for(let t=0;t<r;t++){const e=n[t]||0,r=a[t]||0;if(e>r)return true;if(e<r)return false}return false}let _updateCheckInFlight=null;function checkForUpdate(t){
const e=t||{};const n=e.force?0:typeof e.minInterval==="number"?e.minInterval:UPDATE_MIN_INTERVAL_MS;if(_updateCheckInFlight)return _updateCheckInFlight;const a=(async()=>{if(n>0){let t=0;try{
const e=await chrome.storage.local.get(UPDATE_CHECKED_AT_KEY);t=e[UPDATE_CHECKED_AT_KEY]||0}catch(t){}if(t&&Date.now()-t<n)return{ok:true,skipped:true}}try{
const t=await fetch(VERSION_CHECK_URL+"?t="+Date.now(),{cache:"no-store"});if(!t.ok)throw new Error("http_"+t.status);const e=await t.json();const n=e.version||"0";await chrome.storage.local.set({
[UPDATE_CHECKED_AT_KEY]:Date.now()});if(CURRENT_VERSION&&isNewerVersion(n,CURRENT_VERSION)){await chrome.storage.local.set({pendingUpdate:{version:n,page:e.page||UPDATE_PAGE_URL,
changelog:e.changelog||""}})}else{await chrome.storage.local.remove("pendingUpdate")}updateBadge();return{ok:true,latest:n,current:CURRENT_VERSION}}catch(t){return{ok:false,
error:String(t&&t.message||t)}}})();_updateCheckInFlight=a;a.then(()=>{_updateCheckInFlight=null},()=>{_updateCheckInFlight=null});return a}chrome.storage.onChanged.addListener((t,e)=>{
if(e!=="local")return;if(HISTORY_KEYS_ALL.some(e=>t[e])||t["pendingUpdate"])updateBadge()});const UPBIT_URLS=[{urlPrefix:"https://upbit.com/"},{urlPrefix:"https://www.upbit.com/"}]
;const BITHUMB_URLS=[{urlPrefix:"https://www.bithumb.com/"}];const REPORT_HELPER_FILES=["kta_storage_keys.js","kta_dom_probes.js","kta_report_client.js"];const PING_TIMEOUT_MS=500
;function injectTab(t,e){let n=false;const a=()=>{if(n)return;n=true;chrome.scripting.executeScript({target:{tabId:t},files:REPORT_HELPER_FILES.concat([e])}).catch(()=>{})}
;setTimeout(a,PING_TIMEOUT_MS);try{chrome.tabs.sendMessage(t,{action:"ktaPing",script:e},t=>{const r=chrome.runtime.lastError;if(!r&&t&&t.ok===true&&t.script===e){n=true;return}a()})}catch(t){a()}}
const REPORT_URL="https://auth.krisb-infra.com/report";const REPORT_SECRET=self.KTA_REPORT_SECRET;async function sendErrorReport(t){const e=await fetch(REPORT_URL,{method:"POST",headers:{
"Content-Type":"application/json","x-kmemo-secret":REPORT_SECRET},body:JSON.stringify(t)});let n=null;try{n=await e.json()}catch(t){n=null}const a=e.ok&&!!(n&&n.ok);chrome.storage.local.set({
kt_report_last_v1:{ts:Date.now(),ok:a,id:n&&n.id||"",code:t&&t.code||""}});return{ok:a,id:n&&n.id}}function injectAllTabs(){chrome.tabs.query({url:["https://upbit.com/*","https://www.upbit.com/*"]
},t=>{(t||[]).forEach(t=>injectTab(t.id,"content.js"))});chrome.tabs.query({url:["https://www.bithumb.com/*"]},t=>{(t||[]).forEach(t=>injectTab(t.id,"content.js"))})}
chrome.webNavigation.onCompleted.addListener(t=>{if(t.frameId===0)injectTab(t.tabId,"content.js")},{url:UPBIT_URLS});chrome.webNavigation.onCompleted.addListener(t=>{
if(t.frameId===0)injectTab(t.tabId,"content.js")},{url:BITHUMB_URLS});chrome.runtime.onStartup.addListener(()=>{injectAllTabs();checkForUpdate({force:true})})
;chrome.runtime.onInstalled.addListener(()=>{injectAllTabs();checkForUpdate({force:true})});chrome.tabs.onActivated.addListener(({tabId:t})=>{chrome.tabs.get(t,e=>{if(!e.url)return
;if(e.url.startsWith("https://upbit.com/")||e.url.startsWith("https://www.upbit.com/")){injectTab(t,"content.js")}else if(e.url.startsWith("https://www.bithumb.com/")){injectTab(t,"content.js")}})})
;const _inFlight=new Map;function cacheGet(t){return new Promise(e=>{try{chrome.storage.session.get(t,n=>e(n[t]||null))}catch(t){e(null)}})}function cacheSet(t,e){try{chrome.storage.session.set({[t]:e
})}catch(t){}}async function cachedFetch(t,e,n){const a=await cacheGet(t);if(a&&Date.now()-a.ts<e)return a.data;if(_inFlight.has(t))return _inFlight.get(t);const r=(async()=>{const a=await cacheGet(t)
;if(a&&Date.now()-a.ts<e)return a.data;const r=await n();cacheSet(t,{ts:Date.now(),data:r});return r})();_inFlight.set(t,r);try{return await r}finally{_inFlight.delete(t)}}const CANDLE_BUCKET={
tokens:8,max:8,refillPerSec:4,lastRefill:Date.now()};let candleBackoffUntil=0;let candleBackoffMs=0;let candleSuccessStreak=0;function refillCandleBucket(){const t=Date.now()
;CANDLE_BUCKET.tokens=Math.min(CANDLE_BUCKET.max,CANDLE_BUCKET.tokens+(t-CANDLE_BUCKET.lastRefill)/1e3*CANDLE_BUCKET.refillPerSec);CANDLE_BUCKET.lastRefill=t}function takeCandleToken(){
refillCandleBucket();if(CANDLE_BUCKET.tokens>=1){CANDLE_BUCKET.tokens-=1;return true}return false}function onCandleSuccess(){candleSuccessStreak++;if(candleBackoffMs>0&&candleSuccessStreak>=2){
candleBackoffMs=0;candleBackoffUntil=0}}function onCandle429(){candleSuccessStreak=0;candleBackoffMs=candleBackoffMs?Math.min(candleBackoffMs*2,12e4):5e3;candleBackoffUntil=Date.now()+candleBackoffMs}
function rateLimitedError(t){return Object.assign(new Error("rate_limited"),{rateLimited:true,retryAfter:t})}function apiHost(t){return t==="bithumb"?"https://api.bithumb.com":"https://api.upbit.com"}
function candlePath(t){if(t==="1D")return"days";if(t==="1W")return"weeks";if(t==="1M")return"months";if(t==="12M")return"years";if(t==="1S")return"seconds";return`minutes/${t}`}
async function fetchCandlesInternal(t,e,n,a,r){if(Date.now()<candleBackoffUntil)throw rateLimitedError(candleBackoffUntil);if(!takeCandleToken())throw rateLimitedError(Date.now()+250)
;let o=`${apiHost(r)}/v1/candles/${candlePath(e)}?market=${t}&count=${n}`;if(a)o+=`&to=${encodeURIComponent(a)}`;const c=await fetch(o);if(c.status===429){onCandle429()
;throw rateLimitedError(candleBackoffUntil)}if(!c.ok)throw new Error("http_"+c.status);const s=await c.json();onCandleSuccess();return s}chrome.runtime.onMessage.addListener((t,e,n)=>{
if(t&&t.action==="ktaReport"){sendErrorReport(t.payload||{}).then(n).catch(e=>{chrome.storage.local.set({kt_report_last_v1:{ts:Date.now(),ok:false,id:"",code:t.payload&&t.payload.code||""}});n({
ok:false,error:String(e&&e.message||e)})});return true}if(t&&t.action==="ktaNavStat"){const e=t.exchange==="bithumb"?"bithumb":"upbit";const n=String(t.result||"unknown").slice(0,32)
;chrome.storage.local.get(NAV_STATS_KEY,t=>{const a=t[NAV_STATS_KEY]||{since:Date.now(),upbit:{},bithumb:{}};if(!a.upbit)a.upbit={};if(!a.bithumb)a.bithumb={};if(!a.since)a.since=Date.now()
;a[e][n]=(a[e][n]||0)+1;chrome.storage.local.set({[NAV_STATS_KEY]:a})});return}if(t.action==="checkForUpdate"){checkForUpdate({force:!!t.force,minInterval:t.minInterval}).then(t=>n(t||{ok:false
})).catch(()=>n({ok:false}));return true}if(t.action==="fetchCandles"&&t.market&&t.tf){const e=Math.min(200,Math.max(1,parseInt(t.count)||2));const a=t.to||"";const r=Math.max(1e3,t.maxAgeMs||15e3)
;const o=t.exchange==="bithumb"?"bithumb":"upbit";const c=`kta_cache_candle:${o}:${t.market}:${t.tf}:${e}:${a}`;cachedFetch(c,r,()=>fetchCandlesInternal(t.market,t.tf,e,a,o)).then(t=>n({ok:true,
candles:t})).catch(t=>n({ok:false,error:t.message,rateLimited:!!t.rateLimited,retryAfter:t.retryAfter||0}));return true}if(t.action==="fetchPrices"&&t.codes&&t.codes.length){
fetch(`${apiHost(t.exchange)}/v1/ticker?markets=${t.codes.join(",")}`).then(t=>t.json()).then(t=>{const e={};t.forEach(t=>{e[t.market]=t.trade_price});n({ok:true,prices:e})}).catch(t=>n({ok:false,
error:t.message}));return true}if(t.action==="fetchMarkets"){fetch("https://api.upbit.com/v1/market/all?isDetails=false").then(t=>t.json()).then(t=>{
const e=t.filter(t=>t.market.startsWith("KRW-")).map(t=>({code:t.market,sym:t.market.replace("KRW-",""),kor:t.korean_name,eng:t.english_name}));n({ok:true,markets:e})}).catch(t=>n({ok:false,
error:t.message}));return true}if(t.action==="quickAdd"){chrome.storage.local.set({quickAddSym:t.sym},()=>{chrome.action.openPopup().catch(()=>{})});return}if(t.action==="sendPush"){
chrome.storage.local.get([SETTINGS_KEY,PUSH_COOLDOWN_KEY],e=>{const a=e[SETTINGS_KEY]||{};if(!a.ntfyEnabled||!a.ntfyTopic){n({ok:false});return}const r=a.ntfyCooldown??30
;const o=e[PUSH_COOLDOWN_KEY]||{};const c=t.alarm;if(r>0&&Date.now()-(o[c.id]||0)<r*60*1e3){n({ok:false});return}o[c.id]=Date.now();chrome.storage.local.set({[PUSH_COOLDOWN_KEY]:o})
;const s=t.exchange==="bithumb"?"빗썸":"업비트";const i=c.dir==="above"?"이상":"이하"
;const l=`${c.label} ${Number(c.price).toLocaleString()}원 ${i} 도달!\n현재가: ${Number(t.currentPrice).toLocaleString()}원${c.memo?"\n메모: "+c.memo:""}`;fetch("https://ntfy.sh/",{method:"POST",headers:{
"Content-Type":"application/json"},body:JSON.stringify({topic:a.ntfyTopic,title:`🔔 ${s} 가격 알람`,message:l,priority:4,tags:["bell"]})}).then(()=>n({ok:true})).catch(t=>n({ok:false,error:t.message}))})
;return true}if(t.action==="ntfyTest"){fetch("https://ntfy.sh/",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic:t.topic,title:"🔔 Kris Trader Alarm 테스트",
message:"Push 알림이 정상 수신되었어요!",priority:4,tags:["bell"]})}).then(t=>n({ok:true,status:t.status})).catch(t=>n({ok:false,error:t.message}));return true}if(t.action==="fetchBithumbPrices"){
fetch("https://api.bithumb.com/public/ticker/ALL_KRW").then(t=>t.json()).then(t=>{const e={};if(t.status==="0000"){Object.entries(t.data).forEach(([t,n])=>{
if(t!=="date")e[t]=parseFloat(n.closing_price)})}n({ok:true,prices:e})}).catch(t=>n({ok:false,error:t.message}));return true}});
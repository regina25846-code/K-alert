(function(){"use strict";const e=window.__ktaGen=(window.__ktaGen||0)+1;function t(){return window.__ktaGen===e}if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}
if(window.__ktaTrendTimer){clearInterval(window.__ktaTrendTimer);window.__ktaTrendTimer=null}window.addEventListener("error",function(e){
if(e.message&&e.message.includes("Extension context invalidated"))e.preventDefault()});const n=/(^|\.)bithumb\.com$/i.test(location.hostname);const r=n?{id:"bithumb",name:"빗썸",
storageKey:"bithumb_alarms_v1",historyKey:window.KTA_KEYS.HISTORY_KEYS.bithumb,chartHostId:"coin-chart",probeKey:"bithumb",getSym:()=>{
const e=location.pathname.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i);return e?e[1].toUpperCase():null},trendBlockedTfs:["360","720"],isTradePage:()=>location.pathname.includes("/trade/"),
symExpected:()=>location.pathname.includes("/trade/order/"),coinUrl:e=>`https://www.bithumb.com/react/trade/order/${e}-KRW`,fabMain:"linear-gradient(160deg,#fb923c,#ea580c)",
fabShadow:"0 10px 24px -6px #ea580c, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(251,146,60,.16)"}:{id:"upbit",name:"업비트",storageKey:"upbit_alarms_v2",
historyKey:window.KTA_KEYS.HISTORY_KEYS.upbit,chartHostId:"tv_chart_container",probeKey:"upbit",getSym:()=>{const e=location.search.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i)
;return e?e[1].toUpperCase():null},trendBlockedTfs:[],isTradePage:()=>location.pathname==="/exchange",symExpected:()=>location.pathname==="/exchange"&&location.search.length>1,
coinUrl:e=>`https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${e}`,fabMain:"linear-gradient(160deg,#60a5fa,#2563eb)",
fabShadow:"0 10px 24px -6px #2563eb, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(96,165,250,.16)"};function i(e){if(!e)return"";const t=typeof e.code==="string"?e.code:""
;if(t.indexOf("KRW-")===0)return t;if(e.sym)return"KRW-"+String(e.sym).toUpperCase();if(t)return"KRW-"+t.toUpperCase();return""}const a=r.storageKey;const o="upbit_alarm_settings_v1"
;const c="kta_chart_settings_v1";const s=r.historyKey;const l=50;const d=1500;const u="interval";const f="15";const m=["perBar","once","interval"]
;const p=["1","3","5","10","15","30","60","240","1D","1W","1M"];function h(e){return m.includes(e.repeat)?e.repeat:u}function w(e){return p.includes(e.repeatTf)?e.repeatTf:f}let g=Promise.resolve()
;function b(e){g=g.then(()=>new Promise(t=>{let n=false;const r=()=>{if(!n){n=true;t()}};setTimeout(r,5e3);try{chrome.storage.local.get(a,t=>{try{const n=t[a]||[];const i=e(n);if(i===false){r();return
}chrome.storage.local.set({[a]:Array.isArray(i)?i:n},r)}catch(e){r()}})}catch(e){r()}}));return g}function y(e,t){let n=e.a1,r=e.a2;if(!n||!r)return null;if(r.t<n.t){const e=n;n=r;r=e}
const i=n.t,a=n.p,o=r.t,c=r.p;if(![i,o,a,c,t].every(Number.isFinite))return null;if(o===i)return null;const s=(t-i)/(o-i);const l=e.extend||"right";if(l==="none"&&(s<0||s>1))return null
;if(l==="right"&&s<0)return null;if(e.scale==="log"){if(a<=0||c<=0)return null;return a*Math.pow(c/a,s)}return a+(c-a)*s}function k(e){const t={"1S":1,1:60,3:180,5:300,10:600,15:900,30:1800,60:3600,
240:14400,"1D":86400,"1W":604800,"1M":2592e3};return t[e]||60}function v(e){return Math.min(3e5,Math.max(3e4,k(e)*1e3/4))}const _=new Map;function x(e,t){const n=k(e);const r=_.get(e)||0
;return Math.floor((t-r)/n)*n+r}function T(e,t,n){return new Promise((i,a)=>{if(!$()){a(new Error("ctx_invalid"));return}try{chrome.runtime.sendMessage({action:"fetchCandles",market:e,tf:t,count:n,
exchange:r.id,maxAgeMs:v(t)},e=>{if(chrome.runtime.lastError||!e||!e.ok){const n=e&&e.error||"fetch_failed";if(!(e&&e.rateLimited))j("candle_fetch_failing",{step:"fetchCandles",key:t,severity:"low",
message:n});a(new Error(n));return}i(e.candles)})}catch(e){a(e)}})}function E(e,t){const n=Math.floor(new Date(t.candle_date_time_utc+"Z").getTime()/1e3);const r=k(e.tf)
;if(Number.isFinite(n)&&r>0)_.set(e.tf,(n%r+r)%r);const i=y(e,n);const a=y(e,n+r);if(i==null&&a==null)return{touched:false,barTimeSec:n};const o=i==null?a:a==null?i:Math.min(i,a)
;const c=i==null?a:a==null?i:Math.max(i,a);const s=t.low_price<=c&&t.high_price>=o;return{touched:s,lineLo:o,lineHi:c,barTimeSec:n}}const S=new Map;function L(e,t,n){const r=y(e,n);if(r==null)return
;const i=t-r;const a=S.get(e.id);S.set(e.id,i);if(a===undefined)return;const o=a<=0&&i>=0||a>=0&&i<=0;if(!o)return;const c=x(e.tf,n);F(e,t,r,c)}const P=new Map;let R=null;function C(){
if(R)clearInterval(R);if(window.__ktaTrendTimer)clearInterval(window.__ktaTrendTimer);R=null;window.__ktaTrendTimer=null}async function M(e,t){try{const n=k(e.tf);const r=t?Math.ceil(t/1e3/n):1
;const a=Math.min(50,Math.max(3,r+2));const o=await T(i(e),e.tf,a);if(!o||!o.length)return;const c=[...o].sort((e,t)=>new Date(e.candle_date_time_utc)-new Date(t.candle_date_time_utc))
;const s=q.find(t=>t.id===e.id);if(!s||!O(s))return;if(s.armPending&&Date.now()-s.armPending<15e3)return;const l=s.lastFiredBarT;let d=null;for(const e of c){const{touched:t,barTimeSec:n}=E(s,e)
;if(!t||n===s.armedBarTime)continue;if(l!=null&&n<=l)continue;d={c:e,barTimeSec:n}}if(!d)return;const u=Math.floor(Date.now()/1e3);const f=y(s,u)
;F(s,d.c.trade_price,f!=null?f:d.c.trade_price,d.barTimeSec)}catch(e){}}function A(){if(!t()){C();return}if(!$()){C();return}const e=Date.now();const n=q.filter(e=>e.type==="trend"&&O(e))
;if(!n.length){C();return}n.forEach(t=>{const n=P.get(t.id)||{lastCheckAt:0};if(e-n.lastCheckAt<v(t.tf))return;const r=n.lastCheckAt?e-n.lastCheckAt:0;n.lastCheckAt=e;P.set(t.id,n);M(t,r)})}
function B(){if(!t())return;if(R&&window.__ktaTrendTimer===R)return;C();A();R=setInterval(A,5e3);window.__ktaTrendTimer=R}const I=window.__ktaFireLock=window.__ktaFireLock||{};const K=3e3
;function D(e,t){const n=Date.now();const r=I[e];if(r&&(t<=r.bar||n-r.at<K))return false;I[e]={bar:t,at:n};return true}function N(e){delete I[e]}function F(e,t,n,r){const i=e.repeat||"perBar"
;if(e.lastFiredBarT!=null&&r<=e.lastFiredBarT)return;if(!D(e.id,r))return;e.lastFiredBarT=r;if(i==="perBar"){b(t=>{const n=t.find(t=>t.id===e.id);if(!n)return false;n.lastFiredBarT=r;return t})
}else if(i==="once"){e.disabled=true;re(e.id,null,r)}else{e.disabled=true;const t=ae();re(e.id,t>0?Date.now()+t:null,r)}Fe(e,t,i==="interval"?ae():0,n)}function U(e){S.delete(e);N(e)
;chrome.storage.local.get(a,t=>{const n=t[a]||[];const r=n.find(t=>t.id===e);if(!r||r.type!=="trend")return;const o=(t,n)=>{b(r=>{const i=r.find(t=>t.id===e);if(!i)return false;i.armedBarTime=t
;i.lastFiredBarT=n!=null?n:null;delete i.armPending;return r})};T(i(r),r.tf,1).then(e=>{const t=e&&e[0];if(!t){o(null,null);return}const{touched:n,barTimeSec:i}=E(r,t);o(n?i:null,i-k(r.tf))
}).catch(()=>o(null,null))})}let q=[];let W={sound:"fanfare",volume:70,reactivate:"custom",reactivateMinutes:1};function $(){try{return!!chrome.runtime.id}catch{return false}}function O(e){
return!e.fired&&!e.disabled}if(window.__ktaReporter){try{window.__ktaReporter.stop()}catch(e){}window.__ktaReporter=null}if(window.__ktaBtReporter){try{window.__ktaBtReporter.stop()}catch(e){}
window.__ktaBtReporter=null}if(window.__btPollTimer){clearInterval(window.__btPollTimer);window.__btPollTimer=null}const H=function(){try{
if(!window.__ktReport||!window.__ktProbes||!window.__ktProbes[r.probeKey])return null;const e=window.__ktReport.createReporter({product:"kalert",exchange:r.id,
version:chrome.runtime.getManifest().version,probes:window.__ktProbes[r.probeKey].probes,skeletonRoots:window.__ktProbes[r.probeKey].skeletonRoots,
isPageReady:()=>r.isTradePage()&&!!document.getElementById(r.chartHostId),getMarket:()=>{const e=r.getSym();return e?"KRW-"+e:""},transport:e=>{try{chrome.runtime.sendMessage({action:"ktaReport",
payload:e},()=>{void chrome.runtime.lastError})}catch(e){}}});window.__ktaReporter=e;return e}catch(e){return null}}();function j(e,n){try{if(H&&t())H.fail(e,n||{})}catch(e){}}
window.addEventListener("kta-report",e=>{if(!t())return;const n=e&&e.detail||{};if(n.direct){X({code:String(n.code||"chart_error"),severity:n.severity,step:n.step,key:n.key,message:n.message},z,Y)
;return}j(String(n.code||"chart_error"),{step:n.step,key:n.key,severity:n.severity,message:n.message})});const z="kta_direct_report_cap_v1";const Y=10;const Z="kt_report_install_v1";function X(e,n,i){
try{if(!t()||!$()||!H||!H.isEnabled||!H.isEnabled())return;chrome.storage.local.get([n,Z],t=>{try{const a=(new Date).toISOString().slice(0,10);let o=t&&t[n];if(!o||o.day!==a)o={day:a,n:0,by:{}}
;if(!o.by||typeof o.by!=="object")o.by={};const c=n===G?o.n:o.by[e.code]||0;if(c>=i)return;if(n===G)o.n+=1;else o.by[e.code]=c+1;chrome.storage.local.set({[n]:o});const s=window.__ktReport
;const l=chrome.runtime.getManifest().version;let d=String(t&&t[Z]||"");if(!/^[a-z0-9]{12}$/i.test(d)||/\d{8}/.test(d))d="";const u=s.buildPayload({kind:"error",product:"kalert",version:l,
exchange:r.id,code:e.code,severity:e.severity||"high",count:1,step:String(e.step||"").slice(0,60),path:location.pathname,market:r.getSym()?"KRW-"+r.getSym():"",
chromeMajor:s.chromeMajorOf(navigator.userAgent),installId:d,fingerprint:s.fingerprintOf("kalert",r.id,e.code,e.key,l),error:{message:String(e.message||"").slice(0,200),extFrames:[]}})
;chrome.runtime.sendMessage({action:"ktaReport",payload:u},()=>{void chrome.runtime.lastError})}catch(e){}})}catch(e){}}const G="kta_trend_drift_cap_v1";window.addEventListener("kta-trend-drift",e=>{
try{if(!t()||!$()||!H||!H.isEnabled||!H.isEnabled())return;const n=e&&e.detail||{};const r=e=>Number.isFinite(Number(e))?String(Math.round(Number(e)/60)):"x"
;const i=e=>Number.isFinite(Number(e))?Number(e).toExponential(5):"x";const a=e=>Array.isArray(e)?r(e[0])+"m@"+i(e[1]):"x";let o="none";try{
const e=JSON.parse(sessionStorage.getItem("kta_last_nav")||"null");if(e&&e.r)o=String(e.r).replace(/[^a-z-]/g,"").slice(0,24)+"/"+Math.min(99999,Math.round((Date.now()-e.t)/1e3))+"s"}catch(e){}
let c="x";try{const e=performance.getEntriesByType("navigation")[0];c=(e&&e.type?e.type:"x")+"/"+Math.min(99999,Math.round(performance.now()/1e3))+"s"}catch(e){}
const s=Array.isArray(n.a)?n.a:[],l=Array.isArray(n.d)?n.d:[]
;const d=("tf="+String(n.tf||"").replace(/[^0-9A-Z]/g,"")+" lg="+(n.log?1:0)+" a="+a(s[0])+";"+a(s[1])+" d="+a(l[0])+";"+a(l[1])+" dv="+(Number(n.dev)*100).toFixed(2)+"% vd="+(n.vdev==null?"x":(Number(n.vdev)*100).toFixed(2)+"%")+" nav="+o+" ld="+c+" fb="+(n.first==null?"x":r(n.first)+"m")+" sub="+(Number(n.sub)||0)+" w="+String(n.why||"").slice(0,8)).slice(0,200)
;const u=String(n.tf||"x").replace(/[^0-9A-Z]/g,"")+"-"+Date.now().toString(36);X({code:"trend_line_drift",severity:"high",step:String(n.why||"").slice(0,20),key:u,message:d},G,10)}catch(e){}})
;function V(){chrome.storage.local.get(o,e=>{W={sound:"ding",reactivate:"custom",reactivateMinutes:1,trendSameAsPrice:true,trendSound:"ding3",trendLastExtend:"right",trendLastScale:"linear",
trendLastRepeat:"perBar",priceLastRepeat:"interval",priceLastRepeatTf:"15",...e[o]||{}};J()})}function J(){window.dispatchEvent(new CustomEvent("kta-alarm-settings",{detail:{reactivate:W.reactivate,
reactivateMinutes:W.reactivateMinutes}}))}function Q(){chrome.storage.local.get(c,e=>{const t=e[c];if(t)window.dispatchEvent(new CustomEvent("kta-line-settings",{detail:t}))})}function ee(){
const e=Date.now();const t=[];q.forEach(n=>{if(n.disabled&&n.reactivateAt&&e>=n.reactivateAt){n.disabled=false;delete n.reactivateAt;t.push(n.id)}});if(!t.length)return;b(e=>{let n=false
;e.forEach(e=>{if(t.indexOf(e.id)===-1)return;e.disabled=false;delete e.reactivateAt;n=true});return n?e:false})}function te(){chrome.storage.local.get(a,e=>{q=e[a]||[];ne();ee();if(q.some(O))se()
;if(q.some(e=>e.type==="trend"&&O(e)))B();Ue()})}function ne(){if(n)return;if(q.length)return;try{const e=localStorage.getItem("upbit_alarms_v1");if(!e)return;const t=JSON.parse(e);if(!t.length)return
;q=t.map(e=>({...e,sym:e.code.replace("KRW-",""),kor:"",disabled:e.fired||false,fired:false}));chrome.storage.local.set({[a]:q});localStorage.removeItem("upbit_alarms_v1")}catch{}}function re(e,t,n){
return b(r=>{const i=r.find(t=>t.id===e);if(i){i.disabled=true;i.fired=false;if(t)i.reactivateAt=t;if(n!=null)i.lastFiredBarT=n}return r})}function ie(e){return b(t=>{const n=t.find(t=>t.id===e)
;if(n){n.disabled=false;delete n.reactivateAt}return t})}function ae(){switch(W.reactivate){case"30min":return 30*60*1e3;case"1hour":return 60*60*1e3;case"custom":
return Math.max(1,W.reactivateMinutes||60)*60*1e3;default:return 0}}function oe(e){const t=e&&e.type==="trend"&&W.trendSameAsPrice===false;const n=t?W.trendSound:W.sound;if(n==="none")return
;fetch(chrome.runtime.getURL(`sounds/${n}.wav`)).then(e=>e.blob()).then(e=>{const t=URL.createObjectURL(e);const n=new Audio(t);n.volume=(W.volume??70)/100;n.play().catch(()=>{})
;n.addEventListener("ended",()=>URL.revokeObjectURL(t))}).catch(()=>{})}function ce(){if(!t())return;if(!$()){if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}
return}const e=[...new Set(q.filter(O).map(i).filter(Boolean))];if(!e.length){if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}return}try{
chrome.runtime.sendMessage({action:"fetchPrices",codes:e,exchange:r.id},e=>{try{if(chrome.runtime.lastError||!e||!e.ok){j("price_fetch_failing",{step:"fetchPrices",severity:"low",
message:e&&e.error||"fetch_failed"});return}Object.keys(e.prices).forEach(t=>le(t,e.prices[t]))}catch{}})}catch{if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}}
}function se(){if(!t())return;if(window.__ubPollTimer)clearInterval(window.__ubPollTimer);ce();window.__ubPollTimer=setInterval(ce,d)}function le(e,t){const n=Math.floor(Date.now()/1e3);q.forEach(r=>{
if(!O(r)||i(r)!==e)return;if(r.type==="trend"){L(r,t,n);return}const a=r.price;const o=r.dir==="above"&&t>=a||r.dir==="below"&&t<=a;if(o)de(r,t,a,n)})}function de(e,t,n,r){const i=h(e)
;if(i==="perBar"){const i=x(w(e),r);if(e.lastFiredBarT!=null&&i<=e.lastFiredBarT)return;if(!D(e.id,i))return;e.lastFiredBarT=i;b(t=>{const n=t.find(t=>t.id===e.id);if(!n)return false;n.lastFiredBarT=i
;return t});Fe(e,t,0,n)}else if(i==="once"){e.disabled=true;e.fired=false;re(e.id,null);Fe(e,t,0,n)}else{e.disabled=true;e.fired=false;const r=ae();re(e.id,r>0?Date.now()+r:null);Fe(e,t,r,n)}}
const ue="section.ty02 td.tit em";const fe='li[class*="coin-list-row"]';const me='[class*="coin-list-row__link"]';const pe='[class*="coin-list__scroll"]'
;const he='[class*="item-coin-name-text__symbol"]';function we(e){const t=String(e||"").toUpperCase();if(!t)return null;const n=t.replace(/[^A-Z0-9]/g,"")+"/KRW";let r=null;try{
r=document.querySelectorAll(he)}catch(e){r=null}if(r){for(let e=0;e<r.length;e++){if((r[e].textContent||"").trim().toUpperCase()!==n)continue;let t=null;try{
t=r[e].closest(me)||r[e].closest('[class*="coin-list-row"]')}catch(e){}if(t)return t}}const i=new RegExp("(^|[^A-Z0-9])"+t.replace(/[^A-Z0-9]/g,"")+"\\/KRW");let a;try{a=document.querySelectorAll(fe)
}catch(e){return null}for(let e=0;e<a.length;e++){const t=(a[e].textContent||"").toUpperCase();if(!i.test(t))continue;let n=null;try{n=a[e].querySelector(me)}catch(e){}return n||a[e]}return null}
const ge=30;const be=50;const ye=1200;const ke="원화";const ve=2e3;const _e=800;function xe(){try{
return[].slice.call(document.querySelectorAll(n?'li[role="tab"][class*="market-tab__tab"]':"section.ty02 li a"))}catch(e){return[]}}function Te(e){return(e&&e.textContent||"").trim()}function Ee(e){
if(n)return e.getAttribute("aria-selected")==="true";return String(e.className||"").split(/\s+/).indexOf("on")>=0}function Se(){const e=xe();for(let t=0;t<e.length;t++)if(Ee(e[t]))return Te(e[t])
;return""}function Le(e,t){if(Se()===e){t(true);return}const r=xe().filter(t=>Te(t)===e)[0];const i=r&&(n?r.querySelector("button")||r:r);if(!i){t(false);return}try{i.click()}catch(e){t(false);return}
const a=Date.now();const o=()=>{if(Se()===e){t(true);return}if(Date.now()-a>ve){t(false);return}setTimeout(o,60)};o()}function Pe(){try{
return document.querySelector(n?'[class*="market-list"] input':"section.ty02 input")}catch(e){return null}}function Re(){const e=Pe();return e?String(e.value||""):""}function Ce(e){const t=Pe()
;if(!t)return false;try{const n=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value");n.set.call(t,e);t.dispatchEvent(new Event("input",{bubbles:true}));return true}catch(e){
return false}}function Me(e){if(n)return we(e);const t=String(e||"").toUpperCase()+"/KRW";let r;try{r=document.querySelectorAll(ue)}catch(e){return null}for(let e=0;e<r.length;e++){
if((r[e].textContent||"").trim().toUpperCase()!==t)continue;const n=r[e].parentElement;const i=n&&n.querySelector("a");if(i)return i}return null}function Ae(){let e=null;if(n){try{
const e=document.querySelector(pe);if(e)return e}catch(e){}try{e=document.querySelector(fe)}catch(t){e=null}}else{try{e=document.querySelector(ue)||document.querySelector("section.ty02")}catch(t){
e=null}}for(let t=e;t&&t!==document.body;t=t.parentElement){if(t.scrollHeight>t.clientHeight+40&&t.clientHeight>100)return t}return null}function Be(e){try{if(!$())return;chrome.runtime.sendMessage({
action:"ktaNavStat",exchange:r.id,result:e},()=>{void chrome.runtime.lastError})}catch(e){}}function Ie(e,t,i){let a=false;let o=null;const c=e=>{if(a)return;a=true;try{
sessionStorage.setItem("kta_last_nav",JSON.stringify({r:String(e),t:Date.now()}))}catch(e){}try{i&&i(e)}catch(e){}if(e==="spa")setTimeout(d,0)};const s=e=>{c("reload-"+e);if(t)window.location.href=t}
;const l="보유";function d(){try{const e=o&&o.typed||"";const t=Re();if(t!==e&&t!==p&&t!=="")return;const n=o&&o.tab&&o.tab!==ke?ke:m;if(n&&Se()!==n)return;if(t!==u)Ce(u);if(Se()!==l)Le(l,()=>{})
}catch(e){}}const u=String(e||"").toUpperCase();if(!u||!t){s("bad-args");return}if($e()===u){c("same");return}if(!r.isTradePage()){s("not-trade-page");return}const f=e=>{try{e.click()}catch(e){
s("click-error");return}const t=Date.now();const n=()=>{if($e()===u){c("spa");return}if(Date.now()-t>ye){s("click-timeout");return}setTimeout(n,100)};setTimeout(n,100)};let m="",p="";try{m=Se();p=Re()
}catch(e){m="";p=""}const h=Me(u);if(h){f(h);return}const w=()=>{const e=Ae();if(!e){s("no-list");return}const t=e.scrollTop;let n=0;try{e.scrollTop=0}catch(e){s("scroll-error");return}const r=()=>{
const i=Me(u);if(i){f(i);return}const a=e.scrollTop>=e.scrollHeight-e.clientHeight-2;if(n++>=ge||a){try{e.scrollTop=t}catch(e){}s("not-found");return}e.scrollTop=e.scrollTop+e.clientHeight*.8
;setTimeout(r,be)};setTimeout(r,be)};const g=m!==""&&m!==ke||p!=="";if(!g&&!n){w();return}o={tab:m,search:p,typed:""};setTimeout(()=>{if(!a)s("watchdog")},9e3);const b=()=>{if(!Ce(u)){w();return}
o.typed=u;const e=Date.now();const t=()=>{const r=Me(u);if(r){f(r);return}if(Date.now()-e>_e){Ce("");const e=Date.now();const t=()=>{const r=Me(u);if(r){f(r);return}let i=false;try{
i=!!document.querySelector(n?he+","+fe:ue)}catch(e){}if(i||Date.now()-e>1e3){w();return}setTimeout(t,60)};setTimeout(t,60);return}setTimeout(t,60)};t()};if(m!==""&&m!==ke){if(p!=="")Ce("");Le(ke,e=>{
if(!e&&Se()!==ke){w();return}b()});return}b()}function Ke(e,t,n,r){const i=document.createElement("div")
;i.style.cssText=`\n      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);\n      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));\n      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;\n      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;\n      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);\n      transition:transform .35s cubic-bezier(.2,1,.4,1);\n      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;\n      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;\n    `
;const a=document.createElement("div");a.textContent=e;i.appendChild(a);if(t){const e=document.createElement("div");e.textContent=t
;e.style.cssText="margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;";i.appendChild(e)}document.body.appendChild(i);requestAnimationFrame(()=>{
i.style.transform="translateX(-50%) translateY(0)"});const o=()=>{i.style.transform="translateX(-50%) translateY(-80px)";setTimeout(()=>i.remove(),400)};i.addEventListener("click",()=>{
if(r)Ie(r,n,Be);else if(n)window.location.href=n;o()});setTimeout(o,7e3)}let De=Promise.resolve();function Ne(e,t,n){const a=n!=null?n:e.price;const o={id:Date.now(),exchange:r.id,label:e.label,
sym:e.sym||i(e).replace("KRW-",""),price:a,dir:e.dir,currentPrice:t,memo:e.memo||"",firedAt:Date.now(),unread:true};De=De.then(()=>new Promise(e=>{let t=false;const n=()=>{if(!t){t=true;e()}}
;setTimeout(n,5e3);try{chrome.storage.local.get(s,e=>{try{const t=e[s]||[];t.unshift(o);if(t.length>l)t.length=l;chrome.storage.local.set({[s]:t},n)}catch(e){n()}})}catch(e){n()}}));return De}
function Fe(e,t,n,a){const o=a!=null?a:e.price;Ne(e,t,o);if($())chrome.runtime.sendMessage({action:"sendPush",alarm:{...e,price:o},currentPrice:t,exchange:r.id},()=>{})
;const c=e.type==="trend"?`${e.label} 추세선`:e.label
;const s=e.type==="trend"?`${c} 터치! ${Number(o).toLocaleString()}원\n현재가: ${Number(t).toLocaleString()}원`:`${c} ${Number(o).toLocaleString()}원 ${e.dir==="above"?"이상":"이하"} 도달!\n현재가: ${Number(t).toLocaleString()}원`
;const l=e.sym||String(i(e)||"").replace("KRW-","");const d=r.coinUrl(l);Ke(`🔔 ${s}`,e.memo||"",d,l);if(Notification.permission==="granted"){new Notification(`🔔 ${r.name} 가격 알람`,{body:s})}oe(e)
;if(n>0)setTimeout(()=>ie(e.id),n)}function Ue(){const e=$e();if(!e)return;const t=q.filter(t=>i(t)===`KRW-${e}`);window.dispatchEvent(new CustomEvent("kta-alarms",{detail:t}));J()}
chrome.storage.onChanged.addListener(e=>{if(!t())return;if(e[a]){const t=e[a].oldValue||[];q=e[a].newValue||[];q.forEach(e=>{if(e.type!=="trend")return;const n=t.find(t=>t.id===e.id)
;if(n&&n.disabled&&!e.disabled)U(e.id)});if(q.some(O))se();else if(window.__ubPollTimer){clearInterval(window.__ubPollTimer);window.__ubPollTimer=null}if(q.some(e=>e.type==="trend"&&O(e)))B();else C()
;Ue()}if(e[o]){W={sound:"ding",reactivate:"custom",reactivateMinutes:1,trendSameAsPrice:true,trendSound:"ding3",trendLastExtend:"right",trendLastScale:"linear",trendLastRepeat:"perBar",
priceLastRepeat:"interval",priceLastRepeatTf:"15",...e[o].newValue||{}};J()}});window.addEventListener("kta-symbol-changed",()=>{if(!t())return;setTimeout(Ue,200)})
;window.addEventListener("kta-save-line-settings",e=>{if(!t()||!e.detail||typeof e.detail!=="object")return;const n=e.detail;chrome.storage.local.get(c,e=>{const t=e&&e[c]||{}
;chrome.storage.local.set({[c]:{...t,...n}})})});chrome.storage.onChanged.addListener((e,n)=>{if(n!=="local"||!e[c])return;const r=e[c].newValue
;if(r&&t())window.dispatchEvent(new CustomEvent("kta-line-settings",{detail:r}))});const qe=500;window.addEventListener("kta-update-memo",e=>{if(!t())return;const{id:n,memo:r}=e.detail||{}
;if(!n)return;if(typeof r!=="string")return;if(r.length>qe)return;const i=r.replace(/[\u0000-\u001f\u007f]/g,"");b(e=>{const t=e.find(e=>e.id===n);if(!t)return false;t.memo=i;return e})})
;window.addEventListener("kta-alarm-toggle",e=>{if(!t())return;const{id:n}=e.detail||{};if(!n)return;b(e=>{const t=e.find(e=>e.id===n);if(!t)return false;if(t.disabled){t.disabled=false;t.fired=false
}else{t.disabled=true}return e})});window.addEventListener("kta-alarm-delete",e=>{if(!t())return;const{id:n}=e.detail||{};if(!n)return;b(e=>e.filter(e=>e.id!==n))})
;window.addEventListener("kta-trend-edit-opt",e=>{if(!t())return;const{id:n,field:r,value:i}=e.detail||{};const a={extend:["right","both","none"],scale:["linear","log"],
repeat:["perBar","once","interval"]};if(!n||!a[r]||!a[r].includes(i))return;let c=false;b(e=>{const t=e.find(e=>e.id===n);if(!t||t.type!=="trend")return false;if(t[r]===i)return false;t[r]=i;c=true
;if(r==="extend"||r==="scale")t.armPending=Date.now();return e}).then(()=>{if(!c)return;chrome.storage.local.get(o,e=>{const t={...e[o]||{}}
;if(r==="extend")t.trendLastExtend=i;else if(r==="scale")t.trendLastScale=i;else if(r==="repeat")t.trendLastRepeat=i;chrome.storage.local.set({[o]:t})});if(r==="extend"||r==="scale")U(n);B()})})
;window.addEventListener("kta-price-edit-opt",e=>{if(!t())return;const{id:n,repeat:r,repeatTf:i}=e.detail||{};if(!n||!m.includes(r))return;const a=p.includes(i)?i:null
;const c=Math.floor(Date.now()/1e3);const s=q.find(e=>e.id===n);let l=null;if(s&&s.type!=="trend"&&r==="perBar"&&a&&a!==w(s)){l=x(a,c);I[n]={bar:l,at:Date.now()}}let d=false;b(e=>{
const t=e.find(e=>e.id===n);if(!t||t.type==="trend")return false;const i=h(t);const o=w(t);const c=a||o;if(i===r&&o===c)return false;t.repeat=r;t.repeatTf=c;if(l!=null)t.lastFiredBarT=l;d=true
;return e}).then(()=>{if(!d)return;chrome.storage.local.get(o,e=>{const t={...e[o]||{}};t.priceLastRepeat=r;if(a)t.priceLastRepeatTf=a;chrome.storage.local.set({[o]:t})});se()})})
;window.addEventListener("kta-price-quick-reprice",e=>{if(!t())return;const{id:n,price:i}=e.detail||{};if(!n||!Number.isFinite(i))return;const a=$e();if(!a){
window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"no-sym"}}));return}const o="KRW-"+a;chrome.runtime.sendMessage({action:"fetchPrices",codes:[o],exchange:r.id
},e=>{if(chrome.runtime.lastError||!e||!e.ok||!Number.isFinite(e.prices?.[o])){window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"price-fetch-failed"}}));return}
const t=e.prices[o];const r=We(i,t);if(!r){window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:false,id:n,reason:"tie"}}));return}b(e=>{const t=e.find(e=>e.id===n);if(!t)return false
;t.price=i;t.dir=r;t.fired=false;t.disabled=false;delete t.reactivateAt;t.lastFiredBarT=null;return e}).then(()=>{N(n);se();window.dispatchEvent(new CustomEvent("kta-price-repriced",{detail:{ok:true,
id:n,price:i,dir:r}}))})})});chrome.runtime.onMessage.addListener((e,n,i)=>{if(!t())return;if(e&&e.action==="startTrendPick"){window.dispatchEvent(new CustomEvent("kta-start-trend-pick",{detail:{
editId:e.editId}}));i&&i({ok:true})}if(e&&e.action==="startPriceAlarmPick"){window.dispatchEvent(new CustomEvent("kta-start-price-pick",{detail:{editId:e.editId}}));i&&i({ok:true})}
if(e&&e.action==="ktaPing"){i&&i({ok:true,script:"content.js"});return}if(e&&e.action==="ktaGoCoin"){const t=String(e.sym||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,20);if(!t){i&&i({ok:false,
result:"bad-sym"});return}Ie(t,r.coinUrl(t),e=>{Be(e);try{i&&i({ok:e==="spa",result:e})}catch(e){}});return true}if(e&&e.action==="ktaReportNow"){if(H&&t()){try{H.manualReport()}catch(e){}}i&&i({
ok:!!H})}});window.addEventListener("kta-open-price-popup",()=>{if(!t()||!$())return;const e=$e();if(!e)return;chrome.runtime.sendMessage({action:"quickAdd",sym:e})});function We(e,t){
if(!Number.isFinite(e)||!Number.isFinite(t)||t<=0)return null;if(e>t)return"above";if(e<t)return"below";return null}window.addEventListener("kta-price-quick-create",e=>{if(!t())return
;const{price:n,repeatTf:i}=e.detail||{};if(!Number.isFinite(n)||n<=0)return;const a=$e();if(!a){window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"no-sym"}}));return}
const o="KRW-"+a;chrome.runtime.sendMessage({action:"fetchPrices",codes:[o],exchange:r.id},e=>{if(chrome.runtime.lastError||!e||!e.ok||!Number.isFinite(e.prices?.[o])){
window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"price-fetch-failed"}}));return}const t=e.prices[o];const c=We(n,t);if(!c){
window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:false,reason:"tie"}}));return}const s=Date.now();const l=m.includes(W.priceLastRepeat)?W.priceLastRepeat:u
;const d=p.includes(i)?i:p.includes(W.priceLastRepeatTf)?W.priceLastRepeatTf:f;b(e=>{e.push({id:s,code:o,sym:a,kor:"",label:a,exchange:r.id,price:n,dir:c,memo:"",repeat:l,repeatTf:d,fired:false,
disabled:false});return e}).then(()=>{se();window.dispatchEvent(new CustomEvent("kta-price-created",{detail:{ok:true,id:s,price:n,dir:c}}))})})});window.addEventListener("kta-trend-quick-save",e=>{
if(!t())return;const n=e.detail||{};const{a1:i,a2:a,scale:o,tf:c,memo:s,editId:l}=n;if(!i||!a)return;if(c==="1S")return;if(r.trendBlockedTfs.indexOf(String(c))!==-1)return;if(l){b(e=>{
const t=e.find(e=>e.id===l);if(!t)return false;t.a1=i;t.a2=a;t.tf=c;t.fired=false;t.disabled=false;delete t.reactivateAt;t.armPending=Date.now();return e}).then(()=>U(l));return}const d=$e()
;if(!d)return;const u=W.trendLastExtend||"right";const f=W.trendLastScale||o||"linear";const m=W.trendLastRepeat||"perBar";const p=Date.now();b(e=>{e.push({id:p,code:"KRW-"+d,sym:d,kor:"",label:d,
exchange:r.id,type:"trend",a1:i,a2:a,extend:u,scale:f,tf:c,repeat:m,armedBarTime:null,lastFiredBarT:null,armPending:Date.now(),memo:(s||"").trim(),fired:false,disabled:false});return e}).then(()=>{B()
;U(p)})});document.addEventListener("visibilitychange",()=>{if(!t())return;if(document.visibilityState==="visible"){ee();if(q.some(O))se();if(q.some(e=>e.type==="trend"&&O(e)))B()}})
;if(Notification.permission==="default")Notification.requestPermission();V();Q();te();function $e(){return r.getSym()}function Oe(){if(document.getElementById("kta-fab-style"))return
;const e=document.createElement("style");e.id="kta-fab-style"
;e.textContent=`\n#kta-fab-wrap{position:fixed;bottom:80px;right:20px;z-index:999999;width:46px;height:46px;}\n#kta-fab-wrap .kta-fab-main{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;\n  background:${r.fabMain};color:#fff;padding:0;\n  border:none;cursor:pointer;box-shadow:${r.fabShadow};\n  display:flex;align-items:center;justify-content:center;font-family:'Pretendard',system-ui,sans-serif;\n  transition:transform .22s cubic-bezier(.2,1.2,.4,1);z-index:2;}\n#kta-fab-wrap .kta-fab-main svg{display:block;pointer-events:none;}\n#kta-fab-wrap.open .kta-fab-main{transform:rotate(45deg);}\n\n\n#kta-fab-wrap .kta-fab-child{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;\n  border:none;cursor:pointer;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;\n  opacity:0;pointer-events:none;\n  transition:transform .22s cubic-bezier(.2,1.2,.4,1), opacity .18s;\n  box-shadow:0 6px 16px -4px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.3);\n  font-family:'Pretendard',system-ui,sans-serif;white-space:nowrap;text-align:center;line-height:1.15;}\n#kta-fab-wrap.open .kta-fab-child{opacity:1;pointer-events:auto;}\n\n\n#kta-fab-wrap .kta-fab-price{background:linear-gradient(160deg,#fbbf24,#d97706);transform:translateY(0) scale(.6);}\n#kta-fab-wrap.open .kta-fab-price{transform:translateY(-56px) scale(1);}\n#kta-fab-wrap .kta-fab-trend{background:linear-gradient(160deg,#fb7185,#be123c);transition-delay:0s;transform:translateX(0) scale(.6);}\n#kta-fab-wrap.open .kta-fab-trend{transform:translateX(-56px) scale(1);transition-delay:.04s;}\n`
;document.head.appendChild(e)}function He(e){if(document.getElementById("kta-fab-wrap"))return;Oe();const t=document.createElement("div");t.id="kta-fab-wrap";const n=document.createElement("button")
;n.className="kta-fab-child kta-fab-trend";n.textContent="추세";n.title="추세선 알람 — 차트에서 좌표 찍기";n.addEventListener("click",e=>{e.stopPropagation();t.classList.remove("open")
;window.dispatchEvent(new CustomEvent("kta-start-trend-pick"))});const r=document.createElement("button");r.className="kta-fab-child kta-fab-price";r.textContent="가격";r.title=`${e} 가격 알람 — 차트에서 가격 찍기`
;r.addEventListener("click",e=>{e.stopPropagation();t.classList.remove("open");window.dispatchEvent(new CustomEvent("kta-start-price-pick"))});const i=document.createElement("button")
;i.className="kta-fab-main";i.id="kta-quick-add-btn"
;i.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20"><rect x="10.5" y="3" width="3" height="18" rx="1.5" fill="currentColor"/><rect x="3" y="10.5" width="18" height="3" rx="1.5" fill="currentColor"/></svg>'
;i.title=`${e} 알람 추가`;i.addEventListener("click",e=>{e.stopPropagation();t.classList.toggle("open")});document.addEventListener("click",()=>t.classList.remove("open"));t.appendChild(n)
;t.appendChild(r);t.appendChild(i);document.body.appendChild(t)}function je(){chrome.storage.local.get("upbit_alarm_settings_v1",e=>{const t=e["upbit_alarm_settings_v1"]||{}
;if(t.quickAddBtn===false)return;const n=$e();if(n)He(n);else if(r.symExpected())j("market_detect_failed",{step:"getUpbitSym"})})}je();let ze=location.href;const Ye=setInterval(()=>{if(!t()){
clearInterval(Ye);return}if(location.href!==ze){ze=location.href;document.getElementById("kta-fab-wrap")?.remove();je();Ue()}},500);window.addEventListener("popstate",()=>{if(!t())return
;document.getElementById("kta-fab-wrap")?.remove();je()})})();
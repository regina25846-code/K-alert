// [2026-08-23] 지난 사고 때 남아있던 무효 버전 문자열(3.2.0-1)을 실제 배포판(3.2.0)으로 정정
// — manifest.json도 같은 이유로 이미 되돌려놨음(project_kalert_trendline_ux_v2_design_20260823 메모리 참고).
const CURRENT_VERSION = '3.2.5';
const HISTORY_KEY = 'kta_alarm_history_v1';
const SETTINGS_KEY = 'upbit_alarm_settings_v1';
const PUSH_COOLDOWN_KEY = 'kta_push_cooldown_v1';
// [2026-08-27] 업데이트 체크 URL을 커스텀 도메인 직결로 교체.
// 예전 주소(regina25846-code.github.io/K-alert/*)는 2026-08-26 도메인 통일 이후
// 301 리다이렉트만 내려주는데, 그 301 응답엔 Access-Control-Allow-Origin 헤더가 없어서
// 확장 서비스워커의 CORS fetch가 리다이렉트 단계에서 통째로 실패했음(= 업데이트 감지 완전 먹통).
// 최종 도착지(alert.krisb-infra.com)는 ACAO:* 를 내려주므로 직결하면 정상 동작.
const VERSION_CHECK_URL = 'https://alert.krisb-infra.com/version.json';
const UPDATE_PAGE_URL   = 'https://alert.krisb-infra.com/';
const UPDATE_CHECKED_AT_KEY = 'kta_update_checked_at_v1';
// 팝업 열 때마다 체크하되, 이 간격 안에 이미 확인했으면 네트워크 요청은 생략(형이 하루에도 여러 번 여는 걸 감안).
const UPDATE_MIN_INTERVAL_MS = 60 * 1000;

function updateBadge() {
  chrome.storage.local.get([HISTORY_KEY, 'pendingUpdate'], data => {
    const unread = (data[HISTORY_KEY] || []).filter(h => h.unread).length;
    if (unread > 0) {
      chrome.action.setBadgeText({ text: String(unread) });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else if (data.pendingUpdate) {
      chrome.action.setBadgeText({ text: 'UP' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  });
}

// 문자열 비교(latest > CURRENT_VERSION)는 자릿수가 다른 순간 깨진다.
// 예: '3.2.10' > '3.2.9' → false, '3.10.0' > '3.2.4' → false.
// 점으로 끊어서 숫자로 비교하고, 마디 개수가 달라도(3.2.4 vs 3.2.3.3) 정확히 판정.
function isNewerVersion(latest, current) {
  const a = String(latest).split('.').map(n => parseInt(n, 10) || 0);
  const b = String(current).split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x > y) return true;
    if (x < y) return false;
  }
  return false;
}

// 동시에 여러 번 불려도(팝업 열기 + onStartup 등) 실제 네트워크 요청은 하나로 합친다.
let _updateCheckInFlight = null;

function checkForUpdate(opts) {
  const o = opts || {};
  const minInterval = o.force ? 0 : (typeof o.minInterval === 'number' ? o.minInterval : UPDATE_MIN_INTERVAL_MS);
  if (_updateCheckInFlight) return _updateCheckInFlight;

  const run = (async () => {
    if (minInterval > 0) {
      let last = 0;
      try {
        const st = await chrome.storage.local.get(UPDATE_CHECKED_AT_KEY);
        last = st[UPDATE_CHECKED_AT_KEY] || 0;
      } catch (e) {}
      if (last && (Date.now() - last) < minInterval) return { ok: true, skipped: true };
    }
    try {
      const r = await fetch(VERSION_CHECK_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) throw new Error('http_' + r.status);
      const data = await r.json();
      const latest = data.version || '0';
      await chrome.storage.local.set({ [UPDATE_CHECKED_AT_KEY]: Date.now() });
      if (isNewerVersion(latest, CURRENT_VERSION)) {
        await chrome.storage.local.set({ pendingUpdate: { version: latest, page: data.page || UPDATE_PAGE_URL, changelog: data.changelog || '' } });
      } else {
        await chrome.storage.local.remove('pendingUpdate');
      }
      updateBadge();
      return { ok: true, latest, current: CURRENT_VERSION };
    } catch (e) {
      // 오프라인/일시적 장애는 조용히 무시 — 기존 동작 유지(배너 상태는 직전 값 그대로 둔다).
      return { ok: false, error: String((e && e.message) || e) };
    }
  })();

  _updateCheckInFlight = run;
  run.then(() => { _updateCheckInFlight = null; }, () => { _updateCheckInFlight = null; });
  return run;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[HISTORY_KEY] || changes['pendingUpdate']) updateBadge();
});

const UPBIT_URLS = [{ urlPrefix: 'https://upbit.com/' }, { urlPrefix: 'https://www.upbit.com/' }];
const BITHUMB_URLS = [{ urlPrefix: 'https://www.bithumb.com/' }];

function injectTab(tabId, file) {
  chrome.scripting.executeScript({
    target: { tabId },
    files: [file]
  }).catch(() => {});
}

function injectAllTabs() {
  chrome.tabs.query({ url: ['https://upbit.com/*', 'https://www.upbit.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'content.js'));
  });
  chrome.tabs.query({ url: ['https://www.bithumb.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'bithumb_content.js'));
  });
}

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'content.js');
}, { url: UPBIT_URLS });

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'bithumb_content.js');
}, { url: BITHUMB_URLS });

// 기존 트리거는 중복 방어용으로 그대로 유지(브라우저 재시작 / 설치·업데이트 시점).
// 다만 이 둘만으로는 chrome://extensions 리로드(⟳) 경로를 못 잡아서,
// 아래 onMessage의 'checkForUpdate'(팝업 열 때마다 호출)가 실질적인 주 경로다.
chrome.runtime.onStartup.addListener(() => { injectAllTabs(); checkForUpdate({ force: true }); });
chrome.runtime.onInstalled.addListener(() => { injectAllTabs(); checkForUpdate({ force: true }); });

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (!tab.url) return;
    if (tab.url.startsWith('https://upbit.com/') || tab.url.startsWith('https://www.upbit.com/')) {
      injectTab(tabId, 'content.js');
    } else if (tab.url.startsWith('https://www.bithumb.com/')) {
      injectTab(tabId, 'bithumb_content.js');
    }
  });
});

// ── [2026-08-23] 캔들 트리거엔진 1단계: 공용 캐시 + in-flight 병합 + 캔들전용 토큰버킷 ──────────
// 목적: 탭을 여러 개 열어놔도(각 탭이 독립적으로 폴링) 실제 네트워크 호출이 배수로 안 늘어나게
// 이 서비스워커를 유일한 관문으로 만든다. background.js는 모든 탭이 공유하는 단일 인스턴스라
// 별도 리더선출 없이 이 파일 안의 in-memory 상태만으로 충분함(SW 재기동에도 캐시는
// chrome.storage.session에 저장돼서 살아남음 — 'storage' 권한 안에 이미 포함돼있어 매니페스트 변경 불필요).

const _inFlight = new Map(); // key → 진행중인 Promise, 동시요청 병합용

function cacheGet(key) {
  return new Promise(resolve => {
    try { chrome.storage.session.get(key, data => resolve(data[key] || null)); }
    catch (e) { resolve(null); }
  });
}
function cacheSet(key, value) {
  try { chrome.storage.session.set({ [key]: value }); } catch (e) {}
}

// key로 in-flight 요청을 병합하면서, maxAgeMs 안에 캐시가 있으면 그걸 그대로 씀.
async function cachedFetch(key, maxAgeMs, fetcher) {
  const cached = await cacheGet(key);
  if (cached && (Date.now() - cached.ts) < maxAgeMs) return cached.data;
  if (_inFlight.has(key)) return _inFlight.get(key);
  const p = (async () => {
    // 병합 대기 중 다른 호출이 이미 채워놨을 수 있으니 한 번 더 확인.
    const cached2 = await cacheGet(key);
    if (cached2 && (Date.now() - cached2.ts) < maxAgeMs) return cached2.data;
    const data = await fetcher();
    cacheSet(key, { ts: Date.now(), data });
    return data;
  })();
  _inFlight.set(key, p);
  try { return await p; } finally { _inFlight.delete(key); }
}

// 캔들 API 전용 토큰버킷(4req/s, 버스트8) — 업비트 실측 상한(초당10) 대비 안전마진.
// ticker는 group=candles와 버킷이 분리돼있어서 이 제한을 안 받음(기존 동작 그대로).
const CANDLE_BUCKET = { tokens: 8, max: 8, refillPerSec: 4, lastRefill: Date.now() };
let candleBackoffUntil = 0;
let candleBackoffMs = 0;
let candleSuccessStreak = 0;

function refillCandleBucket() {
  const now = Date.now();
  CANDLE_BUCKET.tokens = Math.min(CANDLE_BUCKET.max, CANDLE_BUCKET.tokens + ((now - CANDLE_BUCKET.lastRefill) / 1000) * CANDLE_BUCKET.refillPerSec);
  CANDLE_BUCKET.lastRefill = now;
}
function takeCandleToken() {
  refillCandleBucket();
  if (CANDLE_BUCKET.tokens >= 1) { CANDLE_BUCKET.tokens -= 1; return true; }
  return false;
}
function onCandleSuccess() {
  candleSuccessStreak++;
  if (candleBackoffMs > 0 && candleSuccessStreak >= 2) { candleBackoffMs = 0; candleBackoffUntil = 0; }
}
function onCandle429() {
  candleSuccessStreak = 0;
  candleBackoffMs = candleBackoffMs ? Math.min(candleBackoffMs * 2, 120000) : 5000;
  candleBackoffUntil = Date.now() + candleBackoffMs;
}

function rateLimitedError(retryAfter) {
  return Object.assign(new Error('rate_limited'), { rateLimited: true, retryAfter });
}

// tf(차트 resolution 문자열) → 업비트 캔들 REST 경로. 1S/1M/12M 포함 전 구간 지원(실측 확인됨).
function candlePath(tf) {
  if (tf === '1D') return 'days';
  if (tf === '1W') return 'weeks';
  if (tf === '1M') return 'months';
  if (tf === '12M') return 'years';
  if (tf === '1S') return 'seconds';
  return `minutes/${tf}`; // '1','3','5','10','15','30','60','240'
}

async function fetchCandlesInternal(market, tf, count, to) {
  // 백오프 중이면 토큰 소비도 안 하고 즉시 실패 반환 — 호출측(콘텐츠스크립트)이 폴링간격을 늦추는 신호로 씀.
  if (Date.now() < candleBackoffUntil) throw rateLimitedError(candleBackoffUntil);
  if (!takeCandleToken()) throw rateLimitedError(Date.now() + 250);
  let url = `https://api.upbit.com/v1/candles/${candlePath(tf)}?market=${market}&count=${count}`;
  if (to) url += `&to=${encodeURIComponent(to)}`;
  const r = await fetch(url);
  if (r.status === 429) { onCandle429(); throw rateLimitedError(candleBackoffUntil); }
  if (!r.ok) throw new Error('http_' + r.status);
  const data = await r.json();
  onCandleSuccess();
  return data;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 팝업이 열릴 때마다 호출된다. MV3 서비스워커가 잠들어 있어도 이 메시지가 깨우므로
  // "확장 리로드만 한" 사용자도 팝업 한 번 열면 곧바로 최신 버전을 확인하게 된다.
  if (msg.action === 'checkForUpdate') {
    checkForUpdate({ force: !!msg.force, minInterval: msg.minInterval })
      .then(res => sendResponse(res || { ok: false }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.action === 'fetchCandles' && msg.market && msg.tf) {
    const count = Math.min(200, Math.max(1, parseInt(msg.count) || 2));
    const to = msg.to || '';
    const maxAgeMs = Math.max(1000, msg.maxAgeMs || 15000);
    const key = `kta_cache_candle:${msg.market}:${msg.tf}:${count}:${to}`;
    cachedFetch(key, maxAgeMs, () => fetchCandlesInternal(msg.market, msg.tf, count, to))
      .then(candles => sendResponse({ ok: true, candles }))
      .catch(e => sendResponse({ ok: false, error: e.message, rateLimited: !!e.rateLimited, retryAfter: e.retryAfter || 0 }));
    return true;
  }
  if (msg.action === 'fetchPrices' && msg.codes && msg.codes.length) {
    fetch(`https://api.upbit.com/v1/ticker?markets=${msg.codes.join(',')}`)
      .then(r => r.json())
      .then(data => {
        const prices = {};
        data.forEach(d => { prices[d.market] = d.trade_price; });
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchMarkets') {
    fetch('https://api.upbit.com/v1/market/all?isDetails=false')
      .then(r => r.json())
      .then(data => {
        const markets = data
          .filter(m => m.market.startsWith('KRW-'))
          .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
        sendResponse({ ok: true, markets });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'quickAdd') {
    chrome.storage.local.set({ quickAddSym: msg.sym }, () => {
      chrome.action.openPopup().catch(() => {});
    });
    return;
  }
  if (msg.action === 'sendPush') {
    chrome.storage.local.get([SETTINGS_KEY, PUSH_COOLDOWN_KEY], data => {
      const s = data[SETTINGS_KEY] || {};
      if (!s.ntfyEnabled || !s.ntfyTopic) { sendResponse({ ok: false }); return; }
      const cooldownMin = s.ntfyCooldown ?? 30;
      const cooldowns = data[PUSH_COOLDOWN_KEY] || {};
      const alarm = msg.alarm;
      if (cooldownMin > 0 && (Date.now() - (cooldowns[alarm.id] || 0)) < cooldownMin * 60 * 1000) { sendResponse({ ok: false }); return; }
      cooldowns[alarm.id] = Date.now();
      chrome.storage.local.set({ [PUSH_COOLDOWN_KEY]: cooldowns });
      const exName = msg.exchange === 'bithumb' ? '빗썸' : '업비트';
      const dirText = alarm.dir === 'above' ? '이상' : '이하';
      const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(msg.currentPrice).toLocaleString()}원${alarm.memo ? '\n메모: ' + alarm.memo : ''}`;
      fetch('https://ntfy.sh/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: s.ntfyTopic, title: `🔔 ${exName} 가격 알람`, message: body, priority: 4, tags: ['bell'] })
      }).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message }));
    });
    return true;
  }
  if (msg.action === 'ntfyTest') {
    fetch('https://ntfy.sh/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: msg.topic, title: '🔔 Kris Trader Alarm 테스트', message: 'Push 알림이 정상 수신되었어요!', priority: 4, tags: ['bell'] })
    }).then(r => sendResponse({ ok: true, status: r.status })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchBithumbPrices') {
    fetch('https://api.bithumb.com/public/ticker/ALL_KRW')
      .then(r => r.json())
      .then(data => {
        const prices = {};
        if (data.status === '0000') {
          Object.entries(data.data).forEach(([sym, info]) => {
            if (sym !== 'date') prices[sym] = parseFloat(info.closing_price);
          });
        }
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

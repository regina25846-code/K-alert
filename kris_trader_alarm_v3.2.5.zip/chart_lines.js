(function () {
  'use strict';

  let _chart = null;
  let latestAlarms = [];
  let pendingAlarms = null;
  let _setupDone = false;
  let panelTheme = 'dark';
  let _shapeMap = new Map(); // alarmId → entityId
  let _pendingIds = new Set(); // createShape 진행 중인 alarmId
  // [2026-08-25] content.js가 kta-alarm-settings로 중계해주는 재활성화 설정(reactivate/reactivateMinutes)
  // 캐시 — 온차트 배너의 "재활성화 설정(N분 후)" 라벨용, 그 이상 용도로 확장 금지(최소 중계 원칙).
  let alarmSettings = {};

  // ── 추세선(익스텐디드 라인) 좌표 클릭 샘플링 상태 ──
  let _picking = false;
  let _pickStep = 0; // 0=idle, 1=1번째 클릭 대기, 2=2번째 클릭 대기
  let _pickA1 = null;
  let _pickA1Px = null; // 1번째 클릭의 페이지 기준 픽셀좌표(비고입력폼 위치용)
  let _pickCross = null; // crossHairMoved로 받은 최신 {time,price} — 상시 구독(setupEvents) 하나가 채움
  let _pickEditId = null; // 있으면 "좌표 재설정"(기존 알람 수정) 모드 — 메모 안 묻고 바로 저장
  // [2026-08-23] 가격 알람 좌표 다시찍기 추가 — 추세선(2클릭)과 같은 인프라(크로스헤어/자석/죽은구간
  // 체크)를 재사용하되 1클릭이면 바로 끝나야 해서 모드로 구분. 'trend'|'price'.
  let _pickMode = 'trend';

  // ── 3단계: 온차트 알람선 더블클릭 편집용 — _pickCross와 같은 상시 구독이 같이 채워줌 ──
  let _hoverCross = null;

  // [2026-08-25] 죽은구간(상장 이전 빈 구간) 폴백용 y↔가격 정렬 상수.
  // priceScale().coordinateToPrice()가 쓰는 y 좌표계와, iframe 문서 안 마우스이벤트의 clientY
  // 좌표계가 같은지는 실측으로 보장된 적이 없다(x축은 handlePickRawMouseMove에서 검증된 전례가
  // 있지만 y축은 없음). 그래서 "같다고 가정"하지 않고, crossHairMoved가 정상 발화하는 동안
  // (price, offsetY) 쌍을 받아 두 좌표계의 평행이동 상수만 실측해 둔다 —
  //   _paneYOffset = priceToY(calib, param.price) - param.offsetY
  // 이 값은 세로 줌/스케일이 바뀌어도 변하지 않는 순수 기하 상수(두 공간 모두 같은 pane의 픽셀
  // 공간이고, 배율 차이는 가격↔픽셀 매핑 쪽에만 들어가기 때문)라서, 나중에 죽은구간에서
  // 클릭 y로부터 가격을 되돌릴 때 그 시점의 calib과 조합해 쓰면 정확하다.
  let _paneYOffset = null;

  // ── 자석(매그넷) 스냅 — 좌표찍기 중일 때만 채워짐, 크로스헤어 값을 그 시각 실제 캔들 OHLC로 붙여줌 ──
  let _magnetHit = null; // {price, level, distPx} | null
  let _magnetRaf = null;
  let _magnetLastParam = null;

  // [2026-08-23] 진짜 원인 확정: 캔들 데이터가 없는 구간(상장 이전 등)에 마우스가 들어가면
  // TradingView의 crossHairMoved가 아예 이벤트를 안 쏨(실측 확인 — coordinateToTime이 그 구간에서
  // null을 주는 것과 일치) — 그래서 _pickCross가 "그 직전에 유효했던 값"에 그대로 얼어붙어있다가,
  // 그 상태로 클릭하면 finite하고 범위 안이라 기존 검증(Number.isFinite, chartDataTimeBounds)을 전부
  // 통과해버림(형이 3.2.0.12에서 재현 — 클릭한 자리랑 전혀 다른 곳에 선이 그려짐). Number.isFinite
  // 체크(3.2.0.11)도 chartDataTimeBounds(3.2.0.12 직전)도 둘 다 "값 자체의 유효성"만 봤지 "지금 이
  // 순간 커서 아래에 실제 데이터가 있는가"는 안 봤던 게 진짜 원인. crossHairMoved와 별개로 순수 DOM
  // mousemove를 직접 붙여서 매번 coordinateToTime으로 직접 확인해 "지금 죽은 구간에 있는지"를
  // 추적하고, 죽은 구간에 있으면 클릭을 무조건 거부한다(스냅된 캐시값과 무관하게).
  let _inDeadZone = false;

  // 알람선 UI 전용 팔레트 — 앱 accent(로즈)가 아니라 업비트 브랜드 남색(#003597) 계열.
  const ICO_SUN  = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block;vertical-align:-1px"><path d="M12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10Zm0-13.2a1 1 0 0 1-1-1V1.6a1 1 0 1 1 2 0v1.2a1 1 0 0 1-1 1Zm0 19.6a1 1 0 0 1-1-1v-1.2a1 1 0 1 1 2 0v1.2a1 1 0 0 1-1 1ZM22.4 13h-1.2a1 1 0 1 1 0-2h1.2a1 1 0 1 1 0 2Zm-19.6 0H1.6a1 1 0 1 1 0-2h1.2a1 1 0 1 1 0 2Zm16.02-7.42-.85.85a1 1 0 0 1-1.41-1.41l.85-.85a1 1 0 1 1 1.41 1.41ZM6.44 19.14l-.85.85a1 1 0 1 1-1.41-1.41l.85-.85a1 1 0 1 1 1.41 1.41Zm12 1.41-.85-.85a1 1 0 1 1 1.41-1.41l.85.85a1 1 0 0 1-1.41 1.41ZM5.03 6.44l-.85-.85A1 1 0 1 1 5.59 4.18l.85.85a1 1 0 0 1-1.41 1.41Z"/></svg>';
  const ICO_MOON = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block;vertical-align:-1px"><path d="M21.3 14.2A9.2 9.2 0 0 1 9.8 2.7a1 1 0 0 0-1.3-1.2A10.5 10.5 0 1 0 22.5 15.5a1 1 0 0 0-1.2-1.3Z"/></svg>';
  const ICO_BELL = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" style="display:block"><path d="M12 22a2.2 2.2 0 0 0 2.2-2.2H9.8A2.2 2.2 0 0 0 12 22Zm6.6-6.3V10.6c0-3.3-1.77-6.06-4.84-6.79v-.73a1.76 1.76 0 0 0-3.52 0v.73C7.18 4.54 5.4 7.29 5.4 10.6v5.1L3.6 17.5v.9h16.8v-.9l-1.8-1.8Z"/><path d="M2.6 8.2a1 1 0 0 1-.93-1.37A9.4 9.4 0 0 1 4.9 2.6a1 1 0 1 1 1.2 1.6 7.4 7.4 0 0 0-2.55 3.3 1 1 0 0 1-.95.7Zm18.8 0a1 1 0 0 1-.95-.7 7.4 7.4 0 0 0-2.55-3.3 1 1 0 1 1 1.2-1.6 9.4 9.4 0 0 1 3.23 4.23A1 1 0 0 1 21.4 8.2Z"/></svg>';
  const ICO_X    = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:block"><path d="M18.3 5.7a1.1 1.1 0 0 0-1.56 0L12 10.44 7.26 5.7A1.1 1.1 0 1 0 5.7 7.26L10.44 12 5.7 16.74a1.1 1.1 0 1 0 1.56 1.56L12 13.56l4.74 4.74a1.1 1.1 0 0 0 1.56-1.56L13.56 12l4.74-4.74a1.1 1.1 0 0 0 0-1.56Z"/></svg>';
  const ICO_REFRESH = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" style="display:inline-block;vertical-align:-2px"><path d="M17.65 6.35A7.95 7.95 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35Z"/></svg>';
  // [2026-08-23] 자석(매그넷) 아이콘 — 이모지 대신 인라인 SVG(2026-08 리브랜딩의 "이모지 전면
  // 아이콘화" 원칙 적용). 말굽자석 모양.
  const ICO_MAGNET = '<svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor" style="display:block"><path d="M4 3h5v8.7a3 3 0 0 0 6 0V3h5v8.7a8 8 0 0 1-16 0V3Zm0 0h5v3.3H4V3Zm11 0h5v3.3h-5V3Z"/></svg>';

  function getTheme() {
    return panelTheme === 'dark'
      ? {
          bg: '#1e2127', bg2: '#262a31', inset: '#101216',
          border: '#2e333b', borderStrong: '#3d434d',
          // [2026-08-07] 다크 모드 대비 개선 — t3(#7e8794)는 배경 #1e2127 대비 4.44:1이라
          // 알람선 설정 패널의 작은 라벨이 잘 안 보였다. #9aa3b2로 올려 6.34:1 확보.
          // 라이트 모드(아래 분기) 값은 그대로 둔다.
          text: '#e9ecf1', t2: '#aeb6c2', t3: '#9aa3b2', lbl: '#aeb6c2',
          hl: 'rgba(255,255,255,.055)', sink: 'rgba(0,0,0,.45)',
          grad: 'linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0))',
          a1: '#2451c9', a2: '#003597', aInk: '#8fb4ff', aSoft: 'rgba(36,81,201,.18)',
          accent: '#2451c9', accentH: '#003597',
          x: '#7e8794', div: '#2e333b',
          shadow: '0 26px 54px -18px rgba(0,0,0,.7)',
          icon: ICO_SUN, nextLabel: '라이트'
        }
      : {
          bg: '#ffffff', bg2: '#ffffff', inset: '#f2f5fa',
          border: '#dfe4ec', borderStrong: '#c8cfdb',
          text: '#161a21', t2: '#4a5361', t3: '#6c7688', lbl: '#4a5361',
          hl: 'rgba(255,255,255,.9)', sink: 'rgba(15,23,42,.06)',
          grad: 'linear-gradient(180deg, #ffffff, #f7f9fc)',
          a1: '#3b6fe0', a2: '#003597', aInk: '#1d4ed8', aSoft: 'rgba(0,53,151,.10)',
          accent: '#3b6fe0', accentH: '#003597',
          x: '#6c7688', div: '#dfe4ec',
          shadow: '0 26px 54px -18px rgba(16,24,40,.35)',
          icon: ICO_MOON, nextLabel: '다크'
        };
  }

  const DEFAULT_SETTINGS = {
    showBell: false, showArrow: false, showMemo: true, showPrice: false,
    aboveColor: '#ef5350', belowColor: '#26a69a',
    // [2026-08-23] 추세선 전용 색상 — 예전엔 가격알람의 이상/아래(dir) 색을 그대로 재사용했는데,
    // 추세알람의 dir은 UI에서 뺀 값이라 실질적으로 항상 'above'로 고정돼있어서
    // 상승/하락 추세선이 둘 다 "이상색상"으로만 그려지는 버그가 있었음. 기울기로 직접 판정해서 씀.
    trendUpColor: '#ef5350', trendDownColor: '#26a69a',
    lineStyle: 2, lineWidth: 1,
    fontSize: 11, fontBold: false,
    horzAlign: 'right', vertAlign: 'bottom',
    // [2026-08-23] 좌표찍기 "1번째/2번째 지점을 클릭하세요" 안내배너 위치 — 기본은 상단 가운데인데
    // 업비트 자체 UI(파란 탭 밑줄 등)와 겹쳐서 눈에 안 띈다는 형 피드백으로 드래그 가능하게 만들고,
    // 마지막으로 옮긴 자리를 기억해서 다음 추세알람 픽 시작할 때도 그 자리에서 뜨게 함.
    pickBannerPos: null,
    // [2026-08-23] 자석(캔들 스냅) — 기본 켜짐, 임계값은 픽셀(캔들 화면크기가 타임프레임별로
    // 크게 요동쳐서 가격%가 아니라 픽셀 기준, 오푸스 실측근거 project_kalert_magnet_snap_design 참고).
    // [2026-08-23 스트롱 마그네틱] 형이 "트레이딩뷰처럼 찰싹 붙는 느낌"을 요청해서 기본 임계값을
    // 8→10px로 넉넉하게 키움(놓는 반경은 magnetSnap 내부에서 이 값의 1.8배로 자동 계산됨).
    magnetEnabled: true,
    magnetPx: 10,
  };
  let lineSettings = { ...DEFAULT_SETTINGS };

  // popup.js의 trendDirLabel과 동일한 판정 로직(사본) — a1/a2 순서 무관, 기울기 부호로 상승/하락.
  function trendIsUp(a) {
    let A = a.a1, B = a.a2;
    if (!A || !B) return true;
    if (B.t < A.t) { const tmp = A; A = B; B = tmp; }
    let slope;
    if (a.scale === 'log') {
      if (A.p <= 0 || B.p <= 0) return true;
      slope = Math.log(B.p / A.p);
    } else {
      slope = B.p - A.p;
    }
    return slope >= 0;
  }

  // content.js의 trendPriceAt과 동일한 로직(사본) — 이 파일(MAIN world)은 chrome.storage에 접근 못 해서
  // kta-alarms 이벤트로 받은 원시 alarm 객체(a1/a2/extend/scale)만 갖고 여기서 직접 계산해야 함.
  function trendPriceAt(a, nowSec) {
    let A = a.a1, B = a.a2;
    if (!A || !B) return null;
    if (B.t < A.t) { const tmp = A; A = B; B = tmp; }
    const t1 = A.t, p1 = A.p, t2 = B.t, p2 = B.p;
    if (![t1, t2, p1, p2, nowSec].every(Number.isFinite)) return null;
    if (t2 === t1) return null;
    const k = (nowSec - t1) / (t2 - t1);
    const ext = a.extend || 'right';
    if (ext === 'none' && (k < 0 || k > 1)) return null;
    if (ext === 'right' && k < 0) return null;
    if (a.scale === 'log') {
      if (p1 <= 0 || p2 <= 0) return null;
      return p1 * Math.pow(p2 / p1, k);
    }
    return p1 + (p2 - p1) * k;
  }

  // ── 3단계: 온차트 알람선 더블클릭 편집 — 가격↔y 픽셀변환 ──
  // TradingView는 y→price(coordinateToPrice)만 주고 역함수(price→y)는 안 줌(실측 확인) — 근데 일반축/
  // 로그축 둘 다 완전 1차(로그축은 log(price)가 1차)관계라, 두 점만 샘플링하면 닫힌형 역함수를 만들 수 있음.
  function priceYCalib(chart) {
    try {
      const ps = chart.getSeries().priceScale();
      const mode = ps.getMode();
      const Y0 = 0, Y1 = 300;
      const p0 = ps.coordinateToPrice(Y0), p1 = ps.coordinateToPrice(Y1);
      if (!Number.isFinite(p0) || !Number.isFinite(p1) || p0 === p1) return null;
      return { mode, Y0, Y1, p0, p1 };
    } catch (e) { return null; }
  }
  function priceToY(calib, price) {
    if (!calib || !Number.isFinite(price)) return null;
    const { mode, Y0, Y1, p0, p1 } = calib;
    if (mode === 1) {
      if (price <= 0 || p0 <= 0 || p1 <= 0) return null;
      return Y0 + (Math.log(price) - Math.log(p0)) * (Y1 - Y0) / (Math.log(p1) - Math.log(p0));
    }
    return Y0 + (price - p0) * (Y1 - Y0) / (p1 - p0);
  }
  // [2026-08-25] priceToY의 역함수 — 죽은구간에서 클릭 y로부터 가격을 되돌릴 때만 쓴다.
  // (평소 경로는 crossHairMoved가 주는 param.price를 그대로 쓰므로 이 함수를 안 탄다.)
  function yToPrice(calib, y) {
    if (!calib || !Number.isFinite(y)) return null;
    const { mode, Y0, Y1, p0, p1 } = calib;
    if (Y1 === Y0) return null;
    let v;
    if (mode === 1) {
      if (p0 <= 0 || p1 <= 0) return null;
      v = Math.exp(Math.log(p0) + (y - Y0) * (Math.log(p1) - Math.log(p0)) / (Y1 - Y0));
    } else {
      v = p0 + (y - Y0) * (p1 - p0) / (Y1 - Y0);
    }
    return Number.isFinite(v) ? v : null;
  }

  // ── [2026-08-25] 업비트 KRW 마켓 호가단위(틱) 스냅 — 오푸스 조사+설계 그대로 구현 ──
  // 형 제보: 차트 클릭으로 가격 알람/추세선 좌표를 찍으면 크로스헤어가 준 연속 실수 가격을 그대로
  // 저장해서 "호가에도 없는 소수점"이 생김. 틱은 심볼이 아니라 "그 가격 자체"의 순수함수(업비트
  // 2025-07-31 개편 표 + KRW 286종목 호가창 전수 실측으로 이중확인, USDT/USDC만 1000~10000원
  // 구간에서 0.5원 예외). 네트워크 왕복 없이 이 파일 안에서 순수 계산만으로 끝남.
  const KRW_TICKS = [
    [2000000, 1000], [1000000, 1000], [500000, 500], [100000, 100],
    [50000, 50], [10000, 10], [5000, 5], [1000, 1], [100, 1],
    [10, 0.1], [1, 0.01], [0.1, 0.001], [0.01, 0.0001],
    [0.001, 0.00001], [0.0001, 0.000001], [0.00001, 0.0000001],
  ];
  const KRW_TICK_MIN = 0.00000001;
  const HALF_TICK_SYMS = new Set(['USDT', 'USDC']); // 2025-03-21부터 1,000~10,000원 구간만 0.5원
  function tickSizeFor(price, sym) {
    if (!Number.isFinite(price) || price <= 0) return null;
    if (sym && HALF_TICK_SYMS.has(sym) && price >= 1000 && price < 10000) return 0.5;
    for (const [lo, u] of KRW_TICKS) if (price >= lo) return u;
    return KRW_TICK_MIN;
  }
  // 틱의 소수 자릿수 — toFixed 반올림에 필요(안 그러면 0.1*3=0.30000000000000004류 부동소수 잔재가 남음).
  function tickDecimals(u) {
    const [m, e] = u.toExponential().split('e');
    const exp = +e;
    return exp < 0 ? -exp + (m.includes('.') ? m.split('.')[1].length : 0) : 0;
  }
  // mode: 'round'(가까운 쪽, 기본)|'floor'|'ceil'. 판정 불가(가격 비정상 등)면 원본 그대로(추측 금지 원칙).
  function roundToTick(price, sym, mode) {
    const u = tickSizeFor(price, sym);
    if (!u) return price;
    const n = price / u;
    const k = mode === 'floor' ? Math.floor(n + 1e-9)
      : mode === 'ceil' ? Math.ceil(n - 1e-9)
        : Math.round(n);
    return Number((k * u).toFixed(tickDecimals(u)));
  }
  // chart_lines.js는 MAIN world라 content.js의 getUpbitSym()과 같은 방식(location)으로 심볼을 얻는다
  // — USDT/USDC 0.5원 예외 판정에만 쓰이고, 그 외엔 아무 영향 없음(못 얻어도 KRW_TICKS만으로 동작).
  function currentKrwSym() {
    const m = location.search.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i);
    return m ? m[1].toUpperCase() : null;
  }

  // ── [2026-08-25] 상장 이전 죽은구간에서도 "가격 알람"만은 다룰 수 있게 하는 폴백 ──
  // 배경(형 실기 제보): 상장한 지 얼마 안 된 코인의 차트 왼쪽 빈 구간(캔들이 아예 없는 구간)에서는
  // TradingView의 crossHairMoved가 발화하지 않는다(파일 상단 _inDeadZone 주석의 실측 결론).
  // 그래서 _hoverCross/_pickCross가 마지막 유효 위치에 얼어붙고, 더블클릭 편집·좌표찍기 양쪽의
  // "신선도 체크"(클릭좌표 vs 크로스헤어좌표 대조)가 실패해 ①수평선 더블클릭이 무시되고
  // ②새 가격알람 클릭이 "캔들 데이터가 없는 구간이에요" 토스트로 거절됐다.
  // 가격(수평) 알람은 정의상 y(가격)만 쓰고 시간축이 아예 안 들어가므로 이 제약 자체가 개념적으로
  // 안 맞는다 → 죽은구간에 한해 크로스헤어를 안 거치고 클릭 이벤트 자신의 y로 가격을 직접 계산한다.
  //
  // 신선도 체크가 막아주던 진짜 위험(차트 밖 호가창/주문창 클릭이 얼어붙은 크로스헤어로 통과,
  // 3.2.0.13/16 회귀)은 그대로 유지하려고 폴백을 아래 3중 조건으로 좁혔다:
  //   ① 이벤트가 차트 iframe 문서 안에서 발생했을 것(차트 밖 UI는 애초에 여기서 탈락)
  //   ② 클릭 x가 "데이터가 시작되는 첫 픽셀"보다 왼쪽일 것 = 진짜 상장 이전 빈 구간일 것
  //      (가격축·시간축·오른쪽 여백은 전부 데이터 시작점보다 오른쪽이라 폴백 대상이 아님)
  //   ③ 크로스헤어가 살아있던 동안 실측해 둔 y좌표계 정렬 상수(_paneYOffset)가 있을 것
  //      (한 번도 차트 위에서 마우스를 움직인 적 없으면 폴백 안 함 — fail-closed)
  function updatePaneYOffset(chart, param) {
    if (!param || !Number.isFinite(param.price) || !Number.isFinite(param.offsetY)) return;
    const calib = priceYCalib(chart);
    if (!calib) return;
    const yc = priceToY(calib, param.price);
    if (yc == null || !Number.isFinite(yc)) return;
    _paneYOffset = yc - param.offsetY;
  }

  // 데이터(캔들)가 존재하는 가장 왼쪽 x픽셀 — 없으면 null(= 판단 불가, 폴백 안 함).
  //
  // [2026-08-25 정정] 예전 주석은 "coordinateToTime의 x가 iframe clientX와 같은 좌표계라는 건
  // handlePickRawMouseMove가 실측 검증한 전제"라고 적어놨는데, 이건 과장이다 — 그 코드가 실제로
  // 확인한 건 "여기가 데이터 있는 구간이냐 아니냐(null이냐)"라는 이진 판정뿐이라, 원점이 수십 px
  // 밀려 있어도 통과한다(죽은구간은 보통 수백 px 폭이라 경계가 조금 밀려도 결과가 같음).
  // 실제로 pane 좌표계는 문서 좌표계와 원점이 다르다(y축은 renderMagnetPreview가 실측 보정 중,
  // 아래 screenXForTime 4차 수정 주석 참고) — 이 잘못된 주석을 믿고 호버 마커를 절대좌표로
  // 계산했다가 3.2.1.8에서 전 종목 마커가 통째로 밀리는 버그를 냈다.
  // 여기(firstDataX/deadZonePriceCross)는 원래 목적이 이진 판정이라 그대로 두지만, 그 대가로
  // 죽은구간 경계가 pane 원점 차이만큼 보수적으로(= 실제보다 좁게) 잡힌다는 걸 명시해 둔다 —
  // 폴백을 덜 하는 방향이라 안전(fail-closed)하고, 기존 동작과 1비트도 다르지 않다.
  // 이 함수의 반환값을 화면 위치 계산에 쓰면 안 된다(반드시 차이로만 쓸 것).
  function firstDataX(chart, maxX) {
    let ts;
    try { ts = chart.getTimeScale(); } catch (e) { return null; }
    const has = x => {
      try { const t = ts.coordinateToTime(x); return t != null && Number.isFinite(t); } catch (e) { return false; }
    };
    const W = Number.isFinite(maxX) ? Math.floor(maxX) : 0;
    if (W <= 0) return null;
    if (has(0)) return 0; // 왼쪽 끝부터 데이터 있음 — 죽은구간 자체가 없음
    let hi = -1;
    for (let x = 8; x <= W; x += 8) { if (has(x)) { hi = x; break; } }
    if (hi < 0) return null; // 화면 어디에도 데이터가 없음 — 이상 상황이라 폴백 안 함(추측 금지)
    let lo = hi - 8; // has(lo) === false 가 보장됨
    while (hi - lo > 1) {
      const mid = lo + Math.floor((hi - lo) / 2);
      if (has(mid)) hi = mid; else lo = mid;
    }
    return hi;
  }

  // 죽은구간(상장 이전) 클릭이면 {price, offsetX, offsetY} 유사 크로스헤어를 만들어 주고,
  // 아니면 null(= 기존 신선도 체크 경로를 그대로 타라는 뜻).
  function deadZonePriceCross(e, chart) {
    if (!chart || _paneYOffset == null) return null;
    const idoc = getChartIframeDoc();
    if (!idoc || !e.target || e.target.ownerDocument !== idoc) return null; // ①
    if (!Number.isFinite(e.clientX) || !Number.isFinite(e.clientY)) return null;
    const iframeEl = document.querySelector('#tv_chart_container iframe');
    const w = iframeEl ? iframeEl.getBoundingClientRect().width : 0;
    const x0 = firstDataX(chart, w);
    if (x0 == null || x0 <= 0 || e.clientX >= x0) return null; // ②
    const calib = priceYCalib(chart);
    if (!calib) return null;
    const price = yToPrice(calib, e.clientY + _paneYOffset); // ③
    if (price == null || !(price > 0)) return null;
    return { time: null, price, offsetX: e.clientX, offsetY: e.clientY, deadZone: true };
  }
  // 추세선의 화면상 기울기(y픽셀/x픽셀) — 가파른 선일수록 "클릭 시각의 값과 가격만 비교"가 엄격해지는 걸
  // 보정하려고 수선거리(perpendicular distance)를 쓰는데, 그러려면 화면상 기울기가 필요함.
  //
  // [2026-08-25 수정] 예전엔 x폭을 (|B.t-A.t|/봉길이)×barSpacing으로 구했는데, 이건
  // trendPointScreenPos가 이미 같은 이유로 폐기한 근사식이다 — 업비트는 거래가 없는 구간엔 봉 자체를
  // 안 만들어서(결손), 시간차를 봉길이로 나누면 "실제로 존재하지 않는 봉"까지 세버려서 x폭을
  // 과대평가한다 → 기울기 과소평가 → 수선거리 과대평가 → 가파른 추세선은 정확히 위에 올려놔도
  // 히트가 안 잡히고, 완만한 다른 선이 대신 잡힌다(호버 라벨이 엉뚱한 알람의 좌표를 그리는 경로).
  // resolution()이 맵에 없는 값(예: '120')이면 tfSecLocal이 60으로 떨어지는 2차 오차도 같이 탄다.
  //   → 커서가 있는 봉을 기준으로 "정확히 N봉 옆" 봉을 인덱스로 집어서 두 점의 화면좌표차로 구한다.
  //     인덱스차는 결손과 무관하게 항상 정확하고(findBarByTime 설계와 동일 근거), x폭 = N×barSpacing은
  //     barSpacing의 정의 그 자체라 봉길이/해상도 문자열에 전혀 의존하지 않는다.
  // 기준 봉을 못 찾으면(커서 시각 미지정·죽은구간 등) 예전 근사식으로 그대로 폴백 —
  // refTime을 안 넘기는 기존 호출부는 동작이 1비트도 안 바뀐다(회귀 방지).
  const SLOPE_PROBE_BARS = 10;
  function slopeProbeTimes(chart, refTime) {
    if (!Number.isFinite(refTime)) return null;
    try {
      const d = chart.getSeries().data();
      const first = d.first(), last = d.last();
      if (!first || !last || !Array.isArray(first.value) || !Array.isArray(last.value)) return null;
      if (!Number.isFinite(first.index) || !Number.isFinite(last.index)) return null;
      const bar1 = findBarByTime(d, first, last, Math.round(refTime));
      if (!bar1 || !Number.isFinite(bar1.index)) return null;
      let n = SLOPE_PROBE_BARS;
      if (bar1.index + n > last.index) n = -SLOPE_PROBE_BARS; // 오른쪽 끝이면 왼쪽으로 재본다
      const i2 = bar1.index + n;
      if (i2 < first.index || i2 > last.index) return null;
      const bar2 = safeBarSearch(d, i2);
      if (!bar2 || !Array.isArray(bar2.value) || !Number.isFinite(bar2.value[0])) return null;
      return { t1: Math.round(bar1.value[0]), t2: Math.round(bar2.value[0]), bars: n };
    } catch (e) { return null; }
  }
  function trendSlopePx(calib, alarm, chart, refTime) {
    if (alarm.type !== 'trend') return 0;
    const A = alarm.a1, B = alarm.a2;
    if (!A || !B || A.t === B.t) return 0;
    let barSpacingPx;
    try { barSpacingPx = chart.getTimeScale().barSpacing(); } catch (e) { return 0; }
    if (!Number.isFinite(barSpacingPx) || !barSpacingPx) return 0;
    // ① 정확 경로 — 결손/해상도 문자열과 무관.
    const probe = slopeProbeTimes(chart, refTime);
    if (probe) {
      const q1 = trendPriceAt(alarm, probe.t1), q2 = trendPriceAt(alarm, probe.t2);
      if (q1 != null && q2 != null) {
        const yq1 = priceToY(calib, q1), yq2 = priceToY(calib, q2);
        if (yq1 != null && yq2 != null) {
          const dxProbe = probe.bars * barSpacingPx;
          if (dxProbe) return (yq2 - yq1) / dxProbe;
        }
      }
    }
    // ② 폴백 — 예전 근사식 그대로(결손이 있으면 과소평가되지만 기존 동작과 완전히 동일).
    const y1 = priceToY(calib, A.p), y2 = priceToY(calib, B.p);
    if (y1 == null || y2 == null) return 0;
    let secPerBar;
    try { secPerBar = tfSecLocal(chart.resolution()); } catch (e) { return 0; }
    if (!secPerBar) return 0;
    const dxPx = (Math.abs(B.t - A.t) / secPerBar) * barSpacingPx;
    if (!dxPx) return 0;
    return (y2 - y1) / dxPx;
  }
  // content.js의 tfSec과 동일(사본) — 봉 하나의 길이(초).
  function tfSecLocal(tf) {
    const map = { '1S': 1, '1': 60, '3': 180, '5': 300, '10': 600, '15': 900, '30': 1800, '60': 3600, '240': 14400, '1D': 86400, '1W': 604800, '1M': 2592000 };
    return map[tf] || 60;
  }
  // [2026-08-25] 가격(수평) 알람 "봉마다 반복"용 — 수평선엔 자기 tf가 없어서, perBar를 고른 순간의
  // 차트 해상도를 봉 길이로 스냅샷해 알람에 적어둔다(content.js의 repeatTf). popup.js TF_KOR 사본.
  const TF_KOR_LOCAL = {
    '1': '1분봉', '3': '3분봉', '5': '5분봉', '10': '10분봉', '15': '15분봉', '30': '30분봉',
    '60': '1시간봉', '240': '4시간봉', '1D': '일봉', '1W': '주봉', '1M': '월봉'
  };
  // content.js의 PRICE_REPEAT_TFS와 반드시 같은 목록(1초봉 제외 — 초 단위 재발동은 알림 폭탄).
  const PRICE_REPEAT_TFS_LOCAL = Object.keys(TF_KOR_LOCAL);
  const PRICE_REPEAT_TF_FALLBACK_LOCAL = '15';
  function currentResolution() {
    try { const r = _chart && _chart.resolution(); return typeof r === 'string' ? r : null; } catch (e) { return null; }
  }
  // 이 알람의 "봉마다"가 실제로 몇 분봉인지 — 이미 정해져 있으면 그 값, 아니면 지금 보고 있는 차트 해상도.
  function priceRepeatTfFor(alarm) {
    if (PRICE_REPEAT_TFS_LOCAL.includes(alarm.repeatTf)) return alarm.repeatTf;
    const cur = currentResolution();
    if (PRICE_REPEAT_TFS_LOCAL.includes(cur)) return cur;
    return PRICE_REPEAT_TF_FALLBACK_LOCAL;
  }

  const ALARM_HIT_PX = 6;
  // 더블클릭 지점(크로스헤어의 그 순간 time/price)과 가장 가까운 알람선을 찾음 — 못 찾으면 null(무동작).
  // [2026-08-25] opts 추가 — 추세선 호버 툴팁에서 재사용하려고 확장(trendOnly/hitPx/releasePx/prevId).
  // opts를 안 주는 기존 더블클릭 호출부는 동작이 1비트도 안 바뀜(전부 기존 기본값으로 폴백).
  function findAlarmAtCross(cross, chart, opts) {
    if (!cross || cross.price == null || !chart) return null;
    // [2026-08-25] priceOnly — 가격(수평) 알람은 정의상 시간축이 아예 안 들어가므로 time 없이도
    // 찾을 수 있어야 한다(상장 이전 죽은구간 더블클릭 편집용). 추세선은 time이 반드시 필요하므로
    // 이 모드에선 후보에서 제외하고, 기본(opts 없음) 경로는 예전처럼 time을 그대로 요구한다.
    const priceOnly = !!(opts && opts.priceOnly);
    if (!priceOnly && cross.time == null) return null;
    const calib = priceYCalib(chart);
    if (!calib) return null;
    const yClick = priceToY(calib, cross.price);
    if (yClick == null) return null;
    const trendOnly = !!(opts && opts.trendOnly);
    const hitPx = (opts && Number.isFinite(opts.hitPx)) ? opts.hitPx : ALARM_HIT_PX;
    const candidates = [];
    latestAlarms.forEach(a => {
      // [2026-08-24] 꺼진/이미 발동한 알람은 실제 화면에 선이 안 그려짐(drawTVLines와 동일 필터,
      // 565행 부근) — 그런데 히트테스트엔 필터가 없어서 "안 보이는데 더블클릭하면 편집창이 뜨는"
      // 현상의 원인 중 하나였음(오푸스 최종검토에서 발견). 그려지는 선만 히트 대상으로 맞춤.
      if (a.fired || a.disabled) return;
      if (trendOnly && a.type !== 'trend') return;
      if (priceOnly && a.type === 'trend') return; // 시간 없이는 추세선 가격을 계산할 수 없음(추측 금지)
      const ref = a.type === 'trend' ? trendPriceAt(a, cross.time) : (Number.isFinite(a.price) ? a.price : null);
      if (ref == null) return;
      const yLine = priceToY(calib, ref);
      if (yLine == null) return;
      const slopePx = trendSlopePx(calib, a, chart, cross.time);
      const dist = Math.abs(yClick - yLine) / Math.sqrt(1 + slopePx * slopePx);
      candidates.push({ alarm: a, dist });
    });
    if (!candidates.length) return null;
    // 히스테리시스 — 직전에 보여주던 알람이 아직 "놓는 반경"(releasePx) 안이면 그대로 유지해서
    // 경계선 근처에서 깜빡이는 걸 방지(자석 스티키 판정과 동일 원칙, magnetSnap 참고).
    if (opts && opts.prevId) {
      const sticky = candidates.find(c => c.alarm.id === opts.prevId);
      if (sticky && sticky.dist <= (Number.isFinite(opts.releasePx) ? opts.releasePx : hitPx)) return sticky.alarm;
    }
    candidates.sort((x, y) => x.dist - y.dist);
    return candidates[0].dist <= hitPx ? candidates[0].alarm : null;
  }

  // ── 자석(매그넷) 스냅 — 좌표찍기 중 크로스헤어 값을 그 시각 봉의 실제 OHLC로 붙여줌 ──
  // 오푸스 실측설계(project_kalert_magnet_snap_design_20260823) 그대로 구현:
  // ①검증 관문 — 찾은 봉의 시각이 cross.time과 정확히 일치하는지 반드시 대조, 못 찾으면 추측
  //   스냅 절대 금지(null) ②후보는 그 봉 하나로 한정(옆 봉 섞으면 t는 A봉인데 p는 B봉값인 존재하지
  //   않는 좌표가 만들어짐) ③하이킨아시는 시가/저가가 실제 체결된 적 없는 합성값이라 강제 비활성.
  //
  // [2026-08-23 3차 수정 — idx 추정 공식을 이분탐색으로 교체] 원래는 idx = first.index +
  // round((t-first.t)/봉초) 산수로 인덱스를 "추정"하고 ±3만 재스캔했는데, 업비트는 거래 없는
  // 구간엔 봉 자체를 안 만들어서([[project_kalert_trendline_phase2_design_20260823]] 캔들트리거엔진
  // 설계와 동일 현상) 그 결손이 데이터 시작점부터 누적되면 산수 추정이 ±3을 훌쩍 넘어 어긋남 —
  // 형이 저타임프레임(15분봉 등)에서 자석 미리보기가 아예 안 뜬다고 재현(MBL 15분봉 실측: 300봉
  // 중 12곳 결손, 후반부 누적결손 11~12개). 인덱스 공간 자체는 결손이 있어도 연속적임을 같은
  // 실측으로 확인(firstIdx~lastIdx 범위의 모든 인덱스가 실제 봉 하나씩을 가리킴 — 결손은 시간축
  // 에서만 생기지 인덱스축엔 빈틈이 없음) — 그래서 산수로 추정하는 대신 [first.index,last.index]
  // 범위에서 시각 기준 이분탐색으로 정확히 찾으면 결손 개수와 무관하게 항상 맞는다(O(log n)).
  const MAGNET_LEVEL_LABEL = { open: '시가', high: '고가', low: '저가', close: '종가' };
  function safeBarSearch(d, idx) {
    try { return d.search(idx, 0); } catch (e) { return null; }
  }
  function findBarByTime(d, first, last, targetT) {
    if (targetT < Math.round(first.value[0]) || targetT > Math.round(last.value[0])) return null;
    let lo = first.index, hi = last.index;
    while (lo <= hi) {
      const mid = lo + Math.floor((hi - lo) / 2);
      const bar = safeBarSearch(d, mid);
      if (!bar || !Array.isArray(bar.value) || !Number.isFinite(bar.value[0])) return null; // 인덱스 공간이 예상과 다르면 추측 대신 포기
      const t = Math.round(bar.value[0]);
      if (t === targetT) return bar;
      if (t < targetT) lo = mid + 1; else hi = mid - 1;
    }
    return null; // 정확히 그 시각의 봉이 없음(그 시각 자체가 결손) — 추측 스냅 절대 금지
  }
  // [2026-08-23 스트롱 마그네틱] 형이 "트레이딩뷰처럼 찰싹 달라붙는 느낌"을 요청 — 처음 붙는
  // 반경(thresholdPx)과 별개로 "놓는" 반경(releasePx)을 더 넉넉하게 둬서, 한번 붙은 뒤엔 마우스가
  // 살짝 흔들려도 안 떨어지게 함(히스테리시스). 같은 봉+같은 레벨일 때만 유지하고, 다른 봉으로
  // 넘어가면 처음부터 다시 판정(엉뚱한 봉에 눌러붙는 걸 방지).
  const MAGNET_RELEASE_MULT = 1.8;
  function magnetSnap(chart, cross, opts, prevHit) {
    if (!opts || !opts.enabled) return null;
    if (!cross || !Number.isFinite(cross.time) || !Number.isFinite(cross.price)) return null;
    if (!chart) return null;
    try {
      if (typeof chart.chartType === 'function' && chart.chartType() === 8) return null; // 하이킨아시
    } catch (e) {}
    const calib = priceYCalib(chart);
    if (!calib) return null;
    let d, first, last;
    try {
      d = chart.getSeries().data();
      first = d.first();
      last = d.last();
    } catch (e) { return null; }
    if (!first || !last || !Array.isArray(first.value) || !Array.isArray(last.value) ||
        !Number.isFinite(first.index) || !Number.isFinite(last.index)) return null;
    const targetT = Math.round(cross.time);
    const bar = findBarByTime(d, first, last, targetT);
    if (!bar) return null; // 시각이 정확히 일치하는 봉을 못 찾으면 추측 스냅 절대 금지
    const v = bar.value;
    const o = v[1], h = v[2], l = v[3], c = v[4];
    if (!Number.isFinite(h) || !Number.isFinite(l) || h < l) return null; // 손상봉 방어
    let chartType = 1;
    try { chartType = typeof chart.chartType === 'function' ? chart.chartType() : 1; } catch (e) {}
    const raw = (chartType === 2 || chartType === 3)
      ? [{ level: 'close', price: c }] // 라인/영역 차트는 화면에 종가선만 보이니 종가만 후보
      : [{ level: 'open', price: o }, { level: 'high', price: h }, { level: 'low', price: l }, { level: 'close', price: c }];
    const yClick = priceToY(calib, cross.price);
    if (yClick == null) return null;
    const candidates = [];
    raw.forEach(cand => {
      if (!Number.isFinite(cand.price)) return;
      const y = priceToY(calib, cand.price);
      if (y == null) return;
      candidates.push({ level: cand.level, price: cand.price, distPx: Math.abs(y - yClick) });
    });
    if (!candidates.length) return null;
    // 직전 프레임에 붙어있던 후보가 같은 봉에서 아직 "놓는 반경" 안이면 그대로 유지(스티키).
    if (prevHit && prevHit.barT === targetT) {
      const sticky = candidates.find(x => x.level === prevHit.level);
      if (sticky && sticky.distPx <= opts.thresholdPx * MAGNET_RELEASE_MULT) {
        return { price: sticky.price, level: sticky.level, distPx: sticky.distPx, barT: targetT };
      }
    }
    const minDist = Math.min(...candidates.map(x => x.distPx));
    if (minDist > opts.thresholdPx) return null;
    const order = { high: 0, low: 1, close: 2, open: 3 }; // 1px 미만 차이면 이 순서로 타이브레이크
    const near = candidates.filter(x => x.distPx - minDist < 1).sort((a, b) => order[a.level] - order[b.level]);
    const picked = near[0];
    return { price: picked.price, level: picked.level, distPx: picked.distPx, barT: targetT };
  }

  function scheduleMagnetPreview(param) {
    _magnetLastParam = param;
    if (_magnetRaf) return;
    _magnetRaf = requestAnimationFrame(() => { _magnetRaf = null; renderMagnetPreview(_magnetLastParam); });
  }
  function renderMagnetPreview(param) {
    if (!_magnetHit || !_chart || !param) { removeMagnetPreview(); return; }
    const calib = priceYCalib(_chart);
    if (!calib) { removeMagnetPreview(); return; }
    const yLine = priceToY(calib, _magnetHit.price);
    const yClick = priceToY(calib, param.price);
    if (yLine == null || yClick == null || !Number.isFinite(param.offsetX) || !Number.isFinite(param.offsetY)) {
      removeMagnetPreview(); return;
    }
    // offsetY(크로스헤어 픽셀)와 priceToY(가격좌표) 원점이 다름(차트 상단 레전드/툴바 높이만큼) —
    // 레이아웃 의존이라 상수로 못 박지 않고 매번 실측해서 보정.
    const deltaY = param.offsetY - yClick;
    const iframeEl = document.querySelector('#tv_chart_container iframe');
    const rect = iframeEl ? iframeEl.getBoundingClientRect() : { left: 0, top: 0 };
    const x = rect.left + param.offsetX;
    const y = rect.top + yLine + deltaY;
    let dot = document.getElementById('kta-magnet-dot');
    if (!dot) {
      dot = document.createElement('div');
      dot.id = 'kta-magnet-dot';
      dot.style.cssText = 'position:fixed;z-index:2147483647;width:8px;height:8px;border-radius:50%;' +
        'background:#2451c9;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,53,151,.6);pointer-events:none;transform:translate(-50%,-50%);';
      document.body.appendChild(dot);
    }
    let lbl = document.getElementById('kta-magnet-label');
    if (!lbl) {
      lbl = document.createElement('div');
      lbl.id = 'kta-magnet-label';
      lbl.style.cssText = 'position:fixed;z-index:2147483647;transform:translate(9px,-50%);' +
        "background:linear-gradient(180deg,#2451c9,#003597);color:#fff;font:700 10.5px/1.2 'Pretendard',system-ui,sans-serif;" +
        'padding:2px 6px;border-radius:6px;pointer-events:none;white-space:nowrap;';
      document.body.appendChild(lbl);
    }
    dot.style.left = x + 'px'; dot.style.top = y + 'px';
    lbl.style.left = x + 'px'; lbl.style.top = y + 'px';
    lbl.textContent = MAGNET_LEVEL_LABEL[_magnetHit.level] || '';
  }
  function removeMagnetPreview() {
    document.getElementById('kta-magnet-dot')?.remove();
    document.getElementById('kta-magnet-label')?.remove();
    if (_magnetRaf) { cancelAnimationFrame(_magnetRaf); _magnetRaf = null; }
  }

  // ── [2026-08-25] 추세선 호버 좌표 라벨 — 형 재지시로 재설계(1차는 마우스 옆 정보카드였는데,
  // 형이 원한 건 좌표 찍을 때 뜨는 자석 미리보기(점+"고가/저가" 말풍선, renderMagnetPreview/위 314행)
  // 그 스타일 그대로를 "그 점 위치에" 보여주는 것 — 카드 방식 전면 폐기하고 이 스타일로 교체).
  // 어느 레벨로 찍혔는지는 저장을 안 해서(a1/a2는 {t,p}만 저장) 호버 시점에 그 봉의 OHLC와
  // 대조해서 역추적한다(trendPointLevel). 하이킨아시(합성 캔들)는 대조 자체를 안 하고, 못 맞추면
  // 라벨 없이 점만 보여준다(추측 금지 — magnetSnap과 동일 원칙).
  const TIP_HIT_PX = 6, TIP_RELEASE_PX = 10; // 히트/놓는 반경(히스테리시스) — 자석 스티키와 동일 계열 설계
  const TREND_LEVEL_ORDER = ['high', 'low', 'close', 'open']; // magnetSnap의 타이브레이크 순서와 동일하게

  // 저장된 좌표가 그 시각 봉의 OHLC 중 어느 값과 정확히 일치하는지 역추적 — 정확히 일치할 때만
  // 라벨을 반환(±오차 허용 안 함, 자석이 찍을 때 봉의 원시값을 그대로 저장하므로 안전한 등호 비교).
  function trendPointLevel(chart, point) {
    if (!chart || !point || !Number.isFinite(point.t) || !Number.isFinite(point.p)) return null;
    try {
      if (typeof chart.chartType === 'function' && chart.chartType() === 8) return null; // 하이킨아시 — 라벨링 비활성
      const d = chart.getSeries().data();
      const first = d.first(), last = d.last();
      if (!first || !last || !Array.isArray(first.value) || !Array.isArray(last.value)) return null;
      const bar = findBarByTime(d, first, last, Math.round(point.t));
      if (!bar || !Array.isArray(bar.value)) return null;
      const v = bar.value;
      const vals = { open: v[1], high: v[2], low: v[3], close: v[4] };
      for (const lvl of TREND_LEVEL_ORDER) {
        if (Number.isFinite(vals[lvl]) && vals[lvl] === point.p) return lvl;
      }
      return null; // 정확히 일치하는 값이 없음(수동 미세조정 등) — 추측 안 하고 라벨 생략
    } catch (e) { return null; }
  }

  // ── [2026-08-25 3차 수정] 좌표 환산을 "우리가 재구성"에서 "차트에게 직접 물어보기"로 교체 ──
  // 1차(시간차/secPerBar) → 2차(봉 인덱스차 × barSpacing)까지 고쳤는데도 형이 실기에서 "좌표가
  // 이상하다"고 재제보(15분봉, 타임프레임 바꿔도 재현, ctrl+F5하면 즉시 정상). 남은 구조적 문제는
  // 이 함수가 트레이딩뷰의 좌표계를 우리 손으로 "재구성"하고 있었다는 것 자체다 — 재구성 오차는
  // 셋 다 커서에서 멀어질수록 비례해서 커지는 성질이라, 형이 본 "가까운 점은 정확한데 먼 점만
  // 붕 뜬다"는 모양이 정확히 이 오차의 모양이다:
  //   ① x의 기준점을 param.offsetX(마우스 x)로 잡았는데, 마우스 x는 그 봉의 중앙이 아니다.
  //      → 같은 봉 안에서 마우스를 좌우로 움직이는 것만으로 마커 두 개가 통째로 최대 barSpacing만큼
  //        미끄러진다(줌인 상태일수록 크게 보임).
  //   ② series.data()의 index 공간과 타임스케일의 픽셀 index 공간이 "동일하다"는 미검증 가정 위에서
  //      index차 × barSpacing으로 픽셀을 만들었다 — 어긋나면 오차가 index차에 정확히 비례한다.
  //   ③ y는 (0,300) 두 점만 찍어 만든 1차/로그 보정식(priceYCalib)을 그 범위 밖까지 외삽했다.
  //      가격축이 그 모델과 조금이라도 다르면 오차가 가격차에 비례한다. 자석/히트테스트는 커서
  //      ±10px만 보기 때문에 이 오차가 드러날 수 없었고, 이 호버 마커가 이 파일에서 처음으로
  //      "원거리 외삽"을 쓰는 기능이다.
  // → 셋을 한꺼번에 없애는 방법은 하나뿐이다: 차트가 실제로 화면을 그릴 때 쓰는 매핑
  //   (coordinateToTime / coordinateToPrice)을 이분탐색으로 그대로 뒤집어서 좌표를 "물어본다".
  //   두 API 모두 이 파일이 이미 firstDataX/priceYCalib에서 신뢰하고 쓰는 통로다.
  //   못 뒤집으면(화면 밖 등) 추측하지 않고 null → 마커 숨김(기존 안전 원칙 그대로).
  //
  // ── [2026-08-25 4차 수정 — 3차의 진짜 결함] ────────────────────────────────────────────
  // 3차를 3.2.1.8로 내보냈더니 형이 실기에서 즉시 재현: "새로 그은 선인데도, 이더리움만이 아니라
  // 모든 코인에서, 두 점 다 원래 찍은 자리에서 멀어져 보인다". 3차가 지목한 원인 3개는 전부
  // "커서에서 멀수록 오차가 커진다"는 성질이라 이 증상(방금 찍어서 커서 바로 옆에 있는 점까지
  // 통째로 어긋남)을 설명하지 못한다 → 3차의 진단 자체가 틀렸다.
  //
  // 진짜 원인: **좌표계 원점을 안 맞췄다.** coordinateToTime/coordinateToPrice가 쓰는 x/y는
  // iframe 문서 좌표(마우스 clientX/clientY, crossHairMoved의 offsetX/offsetY)가 아니라 차트
  // pane 내부 좌표다. 이 파일은 그 사실을 y축에서 이미 실측으로 알고 있었다 —
  // renderMagnetPreview(위 "offsetY(크로스헤어 픽셀)와 priceToY(가격좌표) 원점이 다름(차트 상단
  // 레전드/툴바 높이만큼) — 레이아웃 의존이라 상수로 못 박지 않고 매번 실측해서 보정" 주석)이
  // 매 프레임 deltaY를 실측해서 쓰는 게 그 증거이고, 이건 형이 실기에서 확인한 기능이다.
  // x축도 같은 pane의 좌표라 왼쪽 그리기툴바 폭만큼 원점이 밀려 있는데, 3차는 x에 대해서만
  // "원점이 같다"고 가정하고 이분탐색 결과를 rect.left에 바로 더해버렸다 → 모든 종목/모든 점이
  // 항상 같은 방향으로 통째로 밀린다. 형이 본 증상과 정확히 일치.
  //
  // 왜 이 가정이 그동안 안 들켰나: 이 파일에서 coordinateToTime을 쓰는 다른 코드(firstDataX,
  // handlePickRawMouseMove)는 전부 "null이냐 아니냐"(= 여기 데이터가 있냐)만 보고 픽셀값 자체는
  // 안 쓴다. 원점이 수십 px 밀려 있어도 죽은구간 경계가 그만큼 밀릴 뿐 판정 결과는 그대로라
  // 티가 안 났다. 즉 "coordinateToTime의 x = clientX"는 이 코드베이스에서 한 번도 정밀 검증된
  // 적이 없는 가정이고, 그 쌍둥이인 y축은 오히려 "다르다"고 실측돼 있었다.
  //
  // → 수정 원칙: 화면 위치는 **절대 좌표로 계산하지 않는다.** 이미 실기 검증된
  //   renderMagnetPreview와 똑같이 "커서를 기준점으로 삼고 차이만 더한다":
  //     화면x = param.offsetX + (pane x(점) - pane x(커서 봉))
  //     화면y = param.offsetY + (pane y(점) - pane y(커서 가격))
  //   두 pane 값이 같은 함수에서 나오므로 원점(그 값이 얼마든)은 뺄셈에서 그대로 상쇄된다 —
  //   원점을 알 필요도, 가정할 필요도 없어진다.
  // → y는 새 API(screenYForPrice) 자체를 폐기하고 기존 검증된 priceToY/priceYCalib으로 되돌린다.
  //   가격축은 일반/로그/퍼센트 어느 모드든 (가격 또는 log가격)↔y가 완전 1차라 2점 보정식이
  //   수학적으로 정확하고, 무엇보다 이 경로는 자석 미리보기가 실기에서 이미 쓰고 있는 경로다.
  // → x만 이분탐색을 남긴다(결손 구간 때문에 다른 방법이 없음). 단 그 결과는 "pane 내부 좌표"
  //   이므로 반드시 차이로만 쓴다.
  // 남는 오차: 기준점이 "커서의 봉 중앙"인데 실제 커서는 그 봉 안 아무 데나 있을 수 있어서
  //   최대 ±(봉폭/2)만큼 두 마커가 함께 평행이동한다(두 점의 상대 위치는 정확). 이건 2차 코드도
  //   갖고 있던 성질이고 형이 문제 삼은 적 없는 크기(보통 2~5px)라, 원점 불일치(수십 px 고정
  //   오차)를 없애는 대가로 감수한다. 더 줄이려면 원점 자체를 여러 프레임에 걸쳐 실측해야 하는데,
  //   그건 실기 검증 없이 넣을 만한 크기의 변경이 아니다.

  // 시각 t가 지금 화면의 몇 번째 픽셀에 있는지 — **pane 내부 좌표계** 값이다(iframe 문서 좌표가
  // 아님, 위 4차 수정 주석 참고). 반드시 같은 함수로 구한 다른 값과의 "차이"로만 쓸 것.
  // refX는 "데이터가 있는 것이 확실한 기준 x"(커서) — coordinateToTime이 데이터 없는 구간에서
  // null을 준다는 firstDataX의 실측 결과를 이용해, null이 나온 지점이 target의 왼쪽인지
  // 오른쪽인지를 이 기준으로 판별한다(이 용도는 원점이 밀려 있어도 결론이 안 바뀜).
  function screenXForTime(chart, t, width, refX) {
    if (!Number.isFinite(t) || !(width > 0) || !Number.isFinite(refX)) return null;
    let ts, barSpacingPx;
    try { ts = chart.getTimeScale(); barSpacingPx = ts.barSpacing(); } catch (e) { return null; }
    const target = Math.round(t);
    let failed = false;
    // 그 x가 가리키는 봉의 시각(초). 데이터 밖이면 null.
    const timeAt = x => {
      let v;
      try { v = ts.coordinateToTime(x); } catch (e) { failed = true; return null; }
      return (v == null || !Number.isFinite(v)) ? null : Math.round(v);
    };
    // -1 = 이 x는 target보다 과거 / 0 = 정확히 target 봉 / 1 = target보다 미래
    const cmpAt = x => {
      const r = timeAt(x);
      if (failed) return 0;
      if (r == null) return x < refX ? -1 : 1; // 데이터 밖(왼쪽/오른쪽)
      return r < target ? -1 : r > target ? 1 : 0;
    };
    const W = Math.floor(width);
    if (cmpAt(W) < 0 || failed) return null; // 화면 오른쪽 밖 — 숨김
    // target 이상이 되는 가장 왼쪽 픽셀을 찾는다(coordinateToTime은 x에 대해 단조증가).
    let lo = 0, hi = W;
    while (lo < hi) {
      const mid = lo + Math.floor((hi - lo) / 2);
      const c = cmpAt(mid);
      if (failed) return null;
      if (c >= 0) hi = mid; else lo = mid + 1;
    }
    const cLo = cmpAt(lo);
    if (failed) return null;
    // 그 봉이 차지하는 픽셀 구간의 왼쪽 끝이 lo — 중앙은 여기에 봉 폭의 절반.
    if (cLo === 0) return barSpacingPx > 1 ? lo + barSpacingPx / 2 : lo;
    // 어떤 픽셀도 정확히 그 봉을 안 가리키는 경우 = 봉이 1픽셀보다 좁을 때(줌아웃)만 허용한다.
    // 이때 반드시 좌우 이웃 픽셀이 "둘 다 실제 봉"이어야 한다 — 한쪽이라도 데이터 밖(null)이면
    // 그건 좁은 봉이 아니라 target이 화면 밖(왼쪽/오른쪽)이라는 뜻이라 위치를 지어내면 안 된다.
    if (lo > 0 && cLo > 0) {
      const tPrev = timeAt(lo - 1), tLo = timeAt(lo);
      if (!failed && tPrev != null && tLo != null && tPrev < target && tLo > target) return lo;
    }
    return null; // 화면 왼쪽/오른쪽 밖 등 — 추측 금지
  }

  // 커서(크로스헤어) 자신의 pane 내부 좌표 — 모든 마커가 이 기준과의 "차이"로만 위치를 잡는다.
  // 두 점이 공유하므로 프레임당 한 번만 계산한다(이분탐색 왕복을 반으로 줄이는 효과도 있음).
  // 커서는 정의상 데이터 위에 있으므로(crossHairMoved가 발화한 자리) 보통 항상 구해진다 —
  // 못 구하면 기준이 없다는 뜻이라 추측하지 않고 null(마커 숨김).
  function trendHoverRef(chart, calib, param, rect) {
    if (!param || !rect || !(rect.width > 0) || !(rect.height > 0)) return null;
    if (!Number.isFinite(param.offsetX) || !Number.isFinite(param.offsetY)) return null;
    const yCur = priceToY(calib, param.price);
    if (yCur == null) return null;
    const xCur = screenXForTime(chart, param.time, rect.width, param.offsetX);
    if (xCur == null) return null;
    return { xCur, yCur };
  }

  // 점(time,price) 하나를 현재 화면 픽셀좌표(iframe 문서 기준)로 환산.
  // 절대 좌표를 만들지 않고 커서 기준 상대 변위만 더한다 → pane↔문서 좌표계 원점 차이가
  // x/y 양쪽 모두에서 상쇄된다(위 4차 수정 주석). y 경로는 자석 미리보기(renderMagnetPreview)가
  // 실기에서 쓰고 있는 priceToY + deltaY와 완전히 동일한 식이다.
  function trendPointScreenPos(chart, calib, param, point, rect, ref) {
    if (!ref || !param || !point || !rect || !(rect.width > 0) || !(rect.height > 0)) return null;
    const yPt = priceToY(calib, point.p);
    if (yPt == null) return null;
    const xPt = screenXForTime(chart, point.t, rect.width, param.offsetX);
    if (xPt == null) return null; // 화면 밖이거나 판단 불가 — 추측 대신 숨김
    return { x: param.offsetX + (xPt - ref.xCur), y: param.offsetY + (yPt - ref.yCur) };
  }

  // 자석 미리보기(#kta-magnet-dot/#kta-magnet-label, 위 329행 부근)와 완전히 같은 인라인 스타일 —
  // 형이 "그 스타일 그대로"를 요청해서 문자열까지 동일하게 맞춤. idx로 두 점(1/2) 구분.
  function ensureTrendTipMarker(idx) {
    let dot = document.getElementById('kta-trend-tip-dot' + idx);
    if (!dot) {
      dot = document.createElement('div');
      dot.id = 'kta-trend-tip-dot' + idx;
      dot.style.cssText = 'position:fixed;z-index:2147483647;width:8px;height:8px;border-radius:50%;' +
        'background:#2451c9;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,53,151,.6);pointer-events:none;transform:translate(-50%,-50%);';
      document.body.appendChild(dot);
    }
    let lbl = document.getElementById('kta-trend-tip-lbl' + idx);
    if (!lbl) {
      lbl = document.createElement('div');
      lbl.id = 'kta-trend-tip-lbl' + idx;
      lbl.style.cssText = 'position:fixed;z-index:2147483647;transform:translate(9px,-50%);' +
        "background:linear-gradient(180deg,#2451c9,#003597);color:#fff;font:700 10.5px/1.2 'Pretendard',system-ui,sans-serif;" +
        'padding:2px 6px;border-radius:6px;pointer-events:none;white-space:nowrap;';
      document.body.appendChild(lbl);
    }
    return { dot, lbl };
  }
  function hideTrendTip() {
    _tipCurAlarmId = null;
    [1, 2].forEach(idx => {
      document.getElementById('kta-trend-tip-dot' + idx)?.remove();
      document.getElementById('kta-trend-tip-lbl' + idx)?.remove();
    });
    if (_tipRaf) { cancelAnimationFrame(_tipRaf); _tipRaf = null; }
  }
  // 알람의 원본 두 점(a1/a2) 각각을 화면에 자석 미리보기와 동일한 점+라벨로 찍는다. 지금 화면에
  // 안 보이는(스크롤 밖) 점은 억지로 클램프하지 않고 그냥 숨긴다(추측 금지 원칙 연장).
  function renderTrendAnchorMarkers(alarm, chart, param) {
    const calib = priceYCalib(chart);
    if (!calib) { hideTrendTip(); return; }
    const iframeEl = document.querySelector('#tv_chart_container iframe');
    const rect = iframeEl ? iframeEl.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
    const ref = trendHoverRef(chart, calib, param, rect);
    if (!ref) { hideTrendTip(); return; } // 기준점(커서)을 못 잡으면 상대 계산 자체가 불가 — 숨김
    [{ idx: 1, t: alarm.a1.t, p: alarm.a1.p }, { idx: 2, t: alarm.a2.t, p: alarm.a2.p }].forEach(pt => {
      const { dot, lbl } = ensureTrendTipMarker(pt.idx);
      const pos = trendPointScreenPos(chart, calib, param, pt, rect, ref);
      if (!pos || pos.x < -20 || pos.x > rect.width + 20 || pos.y < -20 || pos.y > rect.height + 20) {
        dot.style.display = 'none'; lbl.style.display = 'none';
        return;
      }
      const x = rect.left + pos.x, y = rect.top + pos.y;
      dot.style.display = ''; dot.style.left = x + 'px'; dot.style.top = y + 'px';
      const lvl = trendPointLevel(chart, pt);
      lbl.style.display = lvl ? '' : 'none'; // 못 맞추면 점만(추측 금지) — 카드 때의 "칩 생략"과 동일 원칙
      if (lvl) { lbl.style.left = x + 'px'; lbl.style.top = y + 'px'; lbl.textContent = MAGNET_LEVEL_LABEL[lvl]; }
    });
  }
  let _tipCurAlarmId = null; // 현재 표시 중인 알람 id — 히스테리시스 판정용
  let _tipRaf = null, _tipLastArgs = null;
  function scheduleTrendAnchorMarkers(alarm, chart, param) {
    _tipLastArgs = { alarm, chart, param };
    if (_tipRaf) return;
    _tipRaf = requestAnimationFrame(() => {
      _tipRaf = null;
      if (_tipLastArgs) renderTrendAnchorMarkers(_tipLastArgs.alarm, _tipLastArgs.chart, _tipLastArgs.param);
    });
  }
  // 억제 조건 전부 여기 한 곳에 모음 — 기존 crossHairMoved 상시 구독 콜백 안에서만 호출(새 구독 금지).
  function updateTrendHoverTip(chart, param) {
    if (_picking || document.getElementById('kta-draw-banner')) { hideTrendTip(); return; }
    if (!param || !Number.isFinite(param.time) || !Number.isFinite(param.price) ||
        !Number.isFinite(param.offsetX) || !Number.isFinite(param.offsetY)) { hideTrendTip(); return; }
    const alarm = findAlarmAtCross(param, chart, {
      trendOnly: true, hitPx: TIP_HIT_PX, releasePx: TIP_RELEASE_PX, prevId: _tipCurAlarmId,
    });
    if (!alarm) { hideTrendTip(); return; }
    _tipCurAlarmId = alarm.id;
    scheduleTrendAnchorMarkers(alarm, chart, param);
  }

  function findChart() {
    try {
      const iframe = document.querySelector('#tv_chart_container iframe');
      if (!iframe) return null;
      const api = iframe.contentWindow?.tradingViewApi;
      if (!api) return null;
      return api.activeChart();
    } catch (e) { return null; }
  }

  setInterval(() => {
    if (!_chart) {
      _chart = findChart();
      if (_chart && !_setupDone) {
        _setupDone = true;
        console.log('[KTA] chart 발견, 이벤트 연결');
        setupEvents();
        const toRender = pendingAlarms ?? latestAlarms;
        pendingAlarms = null;
        if (toRender.length) renderLines(toRender);
      }
    }
    syncFab();
  }, 300);

  function setupEvents() {
    const chart = _chart;
    try {
      chart.onSymbolChanged().subscribe(null, () => {
        clearTVLines();
        stopTrendPick();
        hideTrendTip();
        window.dispatchEvent(new CustomEvent('kta-symbol-changed'));
      });
    } catch (e) {}
    // [2026-08-23] crossHairMoved 구독은 앱 전체에서 이 자리 하나만 둔다 — 예전엔 좌표찍기 시작할 때마다
    // startTrendPick()에서 별도로 subscribe(null, cb)를 또 걸었는데, TradingView의 구독 델리게이트가
    // 같은 null 컨텍스트로 두 번 구독하는 걸 제대로 못 받아서(실측: 형이 좌표를 찍었는데 엉뚱한 자리에
    // 그려지는 버그로 나타남) 좌표찍기용 구독이 이 구독한테 밀려 죽어버렸음. 상시 구독 하나로 합치고
    // _pickCross/_hoverCross 둘 다 여기서 갱신 — 더블클릭 히트테스트와 좌표찍기가 항상 최신값을 공유.
    try {
      chart.crossHairMoved().subscribe(null, param => {
        _hoverCross = param; _pickCross = param;
        // [2026-08-25] 죽은구간 폴백용 y좌표계 정렬 상수 실측 — 새 구독 추가 금지 원칙 그대로
        // 이 콜백 본문에 얹는다. 크로스헤어가 정상 발화하는 "살아있는" 영역에서만 갱신되므로,
        // 상장 이전 구간처럼 이벤트가 안 오는 곳에서도 마지막으로 실측된 기하 상수를 쓸 수 있다.
        updatePaneYOffset(chart, param);
        // 자석 미리보기는 좌표찍기 중(1/2단계, 메모입력폼 단계는 제외)에만 계산 — 새 구독 추가 금지
        // 원칙 지켜서 이 콜백 본문에 그대로 얹음(2026-08-23 중복구독 사고 전례).
        if (_picking && _pickStep >= 1) {
          _magnetHit = magnetSnap(chart, param, { enabled: lineSettings.magnetEnabled, thresholdPx: lineSettings.magnetPx }, _magnetHit);
          if (_magnetHit) scheduleMagnetPreview(param);
          else removeMagnetPreview();
        } else if (_magnetHit || document.getElementById('kta-magnet-dot')) {
          _magnetHit = null;
          removeMagnetPreview();
        }
        // [2026-08-25] 추세선 호버 툴팁 — 새 구독 추가 금지 원칙 그대로, 이 콜백 본문에 얹는다.
        updateTrendHoverTip(chart, param);
      });
    } catch (e) {}
    // [2026-08-25] 타임프레임(해상도) 변경 구독 — 위 crossHairMoved 주석의 "중복 구독 절대 금지"
    // 원칙 그대로, 앱 전체에서 이 자리 하나만 둔다. 추세선 안전 재투영(safeTrendPoints)이
    // "현재 해상도에서 로드된 봉 범위"를 기준으로 계산되기 때문에, 해상도가 바뀌면 다시 계산해서
    // 다시 그려야 한다(안 그러면 1시간봉에서 만들어둔 shape이 15분봉으로 넘어가도 갱신 안 됨).
    try {
      chart.onIntervalChanged().subscribe(null, () => {
        if (_picking) stopTrendPick(); // 좌표찍기 중이었으면 기준 봉이 통째로 바뀌니 취소
        hideTrendTip(); // 해상도가 바뀌면 봉 경계·픽셀좌표가 통째로 달라짐 — 우선 숨김
        scheduleIntervalRedraw(0);
      });
    } catch (e) {}
    setupAlarmDblClick();
  }

  // 해상도 변경 직후엔 새 봉 데이터가 아직 안 와 있을 수 있고(그 상태에서 createMultipointShape는
  // "Cannot create shape"으로 실패하는 걸 실측 확인), 데이터가 채워지는 시점이 일정하지 않아서
  // 데이터가 실제로 들어올 때까지 짧게 재시도한다(최대 약 6초).
  let _intervalRedrawTimer = null;
  function scheduleIntervalRedraw(tries) {
    const n = Number.isFinite(tries) ? tries : 0;
    if (_intervalRedrawTimer) { clearTimeout(_intervalRedrawTimer); _intervalRedrawTimer = null; }
    _intervalRedrawTimer = setTimeout(() => {
      _intervalRedrawTimer = null;
      if (!_chart) return;
      if (!chartDataTimeBounds(_chart)) {
        if (n < 20) scheduleIntervalRedraw(n + 1);
        return;
      }
      drawTVLines();
    }, n === 0 ? 350 : 300);
  }

  // ── 3단계: 온차트 알람선 더블클릭 편집 ──
  // [2026-08-24] 최상위 document에도 걸려있던 리스너를 제거함 — 오푸스 최종검토에서 "아무데서나
  // 더블클릭하면 편집창이 뜬다"는 형 제보의 원인으로 지목. 히트테스트 입력이 클릭 좌표(e)가 아니라
  // _hoverCross(크로스헤어 상시구독 캐시)라서, 차트 밖(호가창/주문창/설정패널 등)을 더블클릭해도
  // "마지막으로 차트 위에 있었던 크로스헤어 위치"로 판정돼버림 — 애초에 온차트 편집 기능이니
  // 차트 iframe 문서 안에서 일어난 더블클릭만 다루는 게 맞음.
  function setupAlarmDblClick() {
    const idoc = getChartIframeDoc();
    if (idoc) {
      idoc.addEventListener('dblclick', handleAlarmDblClick, true);
      // [2026-08-25] 마우스가 차트(iframe) 밖으로 나가면 crossHairMoved가 새 이벤트를 안 쏴서
      // _hoverCross가 마지막 위치에 얼어붙는 기존 버그 계열(위 _inDeadZone 주석 참고)과 같은 함정 —
      // 순수 DOM 리스너라 상시 구독 중복 금지 원칙과 무관, 자유롭게 추가 가능.
      idoc.addEventListener('mouseleave', hideTrendTip, true);
    }
  }

  function handleAlarmDblClick(e) {
    if (_picking) return; // 좌표찍기 중엔 편집 팝업이 끼어들면 혼선되니 비활성.
    if (document.getElementById('kta-draw-banner')) return; // 이미 뜬 배너 있으면 중복 오픈 방지.
    // [2026-08-24] _hoverCross 신선도 체크 추가 — crossHairMoved가 안 오는 영역(범례/y축 등)을
    // 스쳐서 얼어붙은 값을 그대로 믿지 않고, 실제 더블클릭 좌표와 어긋나면 무동작으로 무시.
    // 픽클릭(단일클릭, ±3px)보다 넉넉하게 잡음 — 더블클릭은 두 번의 클릭 사이 손떨림이 자연히
    // 더 크고, 오탐 회귀(3.2.0.13/16)를 다시 겪을 이유가 없어서 여유를 더 둠.
    // [2026-08-25] 죽은구간(상장 이전 빈 구간) 폴백 — 거기선 crossHairMoved가 아예 안 와서
    // _hoverCross가 얼어붙고 아래 신선도 체크가 무조건 실패한다(형 실기 제보 증상①: 캔들 없는
    // 왼쪽 구간의 수평선을 더블클릭하면 편집창이 안 뜸). 가격 알람은 시간축이 필요 없으므로
    // 클릭 y로 가격을 직접 계산해 가격 알람만 히트테스트한다(추세선은 제외 — 시간이 필요함).
    const dzCross = deadZonePriceCross(e, _chart);
    if (dzCross) {
      const dzAlarm = findAlarmAtCross(dzCross, _chart, { priceOnly: true });
      if (dzAlarm) showAlarmQuickEdit(dzAlarm, clickPagePos(e));
      return;
    }
    if (!_hoverCross || !Number.isFinite(_hoverCross.offsetX) || !Number.isFinite(_hoverCross.offsetY)) return;
    if (!Number.isFinite(e.clientX) || !Number.isFinite(e.clientY) ||
        Math.abs(e.clientX - _hoverCross.offsetX) > 8 || Math.abs(e.clientY - _hoverCross.offsetY) > 8) return;
    // preventDefault/stopPropagation은 히트 여부와 무관하게 절대 호출 안 함 — 차트 본연의
    // 더블클릭 동작(줌/리셋 등)을 안 깨뜨리기 위함(기존 좌표찍기 클릭 핸들러와 동일 원칙).
    const alarm = findAlarmAtCross(_hoverCross, _chart);
    if (!alarm) return;
    showAlarmQuickEdit(alarm, clickPagePos(e));
  }

  // 더블클릭으로 찾은 알람의 인라인 미니편집 배너 — 좌표찍기 배너(#kta-draw-banner)를 재사용해
  // 스타일/드래그 없는 고정배치 패턴을 그대로 씀. 메모(엔터저장)/켜기·끄기/삭제, 추세선이면 좌표 다시찍기까지.
  function showAlarmQuickEdit(alarm, pagePos) {
    removeDrawBanner();
    hideTrendTip(); // [2026-08-25 오푸스 최종검토 발견] 안 지우면 배너와 호버 점+라벨이 겹쳐 보임
    injectDrawBannerStyleOnce();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    const isTrend = alarm.type === 'trend';
    const memoVal = (alarm.memo || '').replace(/"/g, '&quot;');
    // [2026-08-23] 좌표 다시찍기는 이제 가격 알람(수평선)에도 동일 제공 — 추세선은 2클릭(startTrendPick),
    // 가격은 1클릭(startPriceAlarmPick)으로 내부 흐름만 다르고 버튼은 똑같이 노출.
    // [2026-08-25 오푸스 설계] 1행은 기존 그대로(.qe-row로 한 겹만 감쌈, 가격 알람은 이 1행만 나감).
    // 2행(.qe-opts)은 추세선일 때만 — 연장/축/반복은 팝업 목록 편집폼(popup.js 319~334줄)과
    // 선택값/옵션 순서를 글자 하나까지 동일하게 맞춘다(구버전 알람 필드 없을 때 기본값도 동일).
    // [2026-08-25] 가격 알람에도 2행을 준다 — 단 **반복 select 하나만**. 연장/축은 수평선엔
    // 개념 자체가 없어서(형 확정) 계속 숨긴다. 반복 기본값은 추세선(perBar)과 정반대인 'interval' —
    // 이유는 content.js 상단 PRICE_REPEAT_FALLBACK 주석 참고(기존 저장 알람 하위호환).
    let row2 = '';
    if (isTrend) {
      const ext = alarm.extend === 'both' ? 'both' : alarm.extend === 'none' ? 'none' : 'right';
      const scale = alarm.scale === 'log' ? 'log' : 'linear';
      const repeat = alarm.repeat === 'once' ? 'once' : alarm.repeat === 'interval' ? 'interval' : 'perBar';
      const reactLabel = reactivateLabel();
      const intervalText = reactLabel ? `재활성화 설정(${reactLabel})` : '재활성화 설정';
      row2 = `
      <div class="qe-row qe-opts">
        <label class="qe-opt"><span class="qe-lab">연장</span>
          <select class="qe-sel" data-field="extend">
            <option value="right" ${ext === 'right' ? 'selected' : ''}>오른쪽 연장</option>
            <option value="both" ${ext === 'both' ? 'selected' : ''}>양쪽 연장</option>
            <option value="none" ${ext === 'none' ? 'selected' : ''} title="아주 오래된 추세선은 화면 왼쪽 끝에서 잘려 보일 수 있어요(알람 판정에는 영향 없음)">선분만</option>
          </select></label>
        <label class="qe-opt"><span class="qe-lab">축</span>
          <select class="qe-sel" data-field="scale">
            <option value="linear" ${scale === 'linear' ? 'selected' : ''}>일반축</option>
            <option value="log" ${scale === 'log' ? 'selected' : ''}>로그축</option>
          </select></label>
        <label class="qe-opt"><span class="qe-lab">반복</span>
          <select class="qe-sel" data-field="repeat">
            <option value="perBar" ${repeat === 'perBar' ? 'selected' : ''}>봉마다 반복</option>
            <option value="once" ${repeat === 'once' ? 'selected' : ''}>한 번만 울림</option>
            <option value="interval" ${repeat === 'interval' ? 'selected' : ''}>${intervalText}</option>
          </select></label>
      </div>`;
    } else {
      // 가격(수평) 알람 — 반복 하나만. perBar 라벨엔 실제 봉 길이를 같이 적어서
      // "수평선의 봉마다가 대체 몇 분봉이냐"가 화면에서 바로 보이게 한다.
      const repeat = alarm.repeat === 'perBar' ? 'perBar' : alarm.repeat === 'once' ? 'once' : 'interval';
      const rtf = priceRepeatTfFor(alarm);
      const reactLabel = reactivateLabel();
      const intervalText = reactLabel ? `재활성화 설정(${reactLabel})` : '재활성화 설정';
      // [2026-08-25] 저장된 기준봉(rtf)과 지금 보고 있는 봉(liveTf)이 다를 수 있다 — HTML <select>는
      // 이미 선택된 옵션을 다시 눌러도 change가 안 뜨므로, "봉마다 반복"이 이미 떠 있는 상태에선
      // 아무리 눌러도 낡은 기준봉이 그대로 남는다. 그래서 **저장 로직은 그대로 두고 표시만** 고친다:
      // 두 값이 다르면 둘 다 보여주고, 바꾸는 건 아래 '지금 봉으로 바꾸기'를 명시적으로 눌렀을 때만.
      // (마우스오버·배너 열림 같은 순간에 몰래 재스냅샷해 자동 저장하는 방식은 "손도 안 댔는데 값이
      //  바뀐다"는 새 사고를 낳는다고 오푸스 최종검토가 명시적으로 반대 — 절대 자동 저장 금지.)
      const liveTf = currentResolution();
      const tfMismatch = repeat === 'perBar' && PRICE_REPEAT_TFS_LOCAL.includes(liveTf) && liveTf !== rtf;
      const perBarText = tfMismatch
        ? `봉마다 반복(${TF_KOR_LOCAL[rtf] || rtf} · 지금 ${TF_KOR_LOCAL[liveTf] || liveTf})`
        : `봉마다 반복(${TF_KOR_LOCAL[rtf] || rtf})`;
      row2 = `
      <div class="qe-row qe-opts">
        <label class="qe-opt"><span class="qe-lab">반복</span>
          <select class="qe-sel" data-field="repeat" data-tf="${rtf}"
                  title="봉마다 반복을 고르면 지금 보고 있는 차트의 봉 길이가 기준으로 저장됩니다">
            <option value="perBar" ${repeat === 'perBar' ? 'selected' : ''}>${perBarText}</option>
            <option value="once" ${repeat === 'once' ? 'selected' : ''}>한 번만 울림</option>
            <option value="interval" ${repeat === 'interval' ? 'selected' : ''}>${intervalText}</option>
          </select></label>
        ${tfMismatch ? `<span class="linkish" data-act="usetf" title="이 알람의 기준 봉을 지금 보고 있는 봉으로 바꿉니다">지금 봉으로 바꾸기</span>` : ''}
      </div>`;
    }
    // 2행이 붙는 순간 배너는 세로 스택 레이아웃이 된다(예전엔 추세선 전용 클래스였음 — 가격도 쓰게 개명).
    if (row2) banner.classList.add('qe-stack');
    banner.innerHTML = `<div class="qe-row">
      <span class="step">✎</span>
      <input type="text" id="kta-quickedit-memo" placeholder="비고(선택) · 엔터로 저장" autocomplete="off" value="${memoVal}"/>
      <span class="save" data-act="repick">좌표 다시 찍기</span>
      <span class="save" data-act="toggle">${alarm.disabled ? '켜기' : '끄기'}</span>
      <span class="cancel" data-act="delete">삭제</span>
      <span class="cancel" data-act="close">✕</span>
    </div>${row2}`;
    document.body.appendChild(banner);
    positionBannerAt(banner, pagePos, true);
    const input = banner.querySelector('#kta-quickedit-memo');
    let lastSentMemo = memoVal; // 이미 보낸 값과 같으면 재전송 안 함(Enter/blur 이중발화 방지)
    const flushMemo = () => {
      const v = input.value.trim();
      if (v === lastSentMemo) return;
      lastSentMemo = v;
      window.dispatchEvent(new CustomEvent('kta-update-memo', { detail: { id: alarm.id, memo: v } }));
    };
    const submit = () => { flushMemo(); banner.remove(); };
    input.addEventListener('keydown', ev => {
      if (ev.key === 'Enter') { ev.preventDefault(); submit(); }
      else if (ev.key === 'Escape') { ev.preventDefault(); banner.remove(); }
    });
    // [2026-08-25] select로 넘어가려고 포커스를 옮기면 blur가 뜬다 — 옵션만 바꾸고 ✕로 닫아도
    // 타이핑해둔 비고가 안 날아가게 여기서 한 번 더 흘려보냄(오푸스 설계 2-1).
    input.addEventListener('blur', flushMemo);
    banner.querySelector('[data-act="close"]').addEventListener('click', () => banner.remove());
    banner.querySelector('[data-act="toggle"]').addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('kta-alarm-toggle', { detail: { id: alarm.id } }));
      banner.remove();
    });
    banner.querySelector('[data-act="delete"]').addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('kta-alarm-delete', { detail: { id: alarm.id } }));
      banner.remove();
    });
    banner.querySelector('[data-act="repick"]').addEventListener('click', () => {
      banner.remove();
      if (isTrend) startTrendPick(alarm.id); else startPriceAlarmPick(alarm.id);
    });
    // [2026-08-25] 연장/축/반복 — 바꾸는 즉시 저장, 배너는 안 닫는다(연속 조정 가능, 자석토글과 같은 관례).
    // 값은 반드시 그 순간 ev.target.value로 읽는다 — 배너 열 때 캡처한 alarm 스냅샷은 참조하지 않는다
    // (_inDeadZone 캐시-타이밍 사고와 같은 계열의 함정을 피하려고, 오푸스 설계 2-2/2-6).
    banner.querySelectorAll('.qe-sel').forEach(sel => {
      sel.addEventListener('change', ev => {
        const field = ev.target.dataset.field;
        const value = ev.target.value;
        // 배너가 열려있는 동안 알람이 삭제됐을 수 있음 — window 리스너 추가 없이 그 순간 재확인.
        if (!latestAlarms.find(a => a.id === alarm.id)) { banner.remove(); return; }
        if (isTrend) {
          window.dispatchEvent(new CustomEvent('kta-trend-edit-opt', { detail: { id: alarm.id, field, value } }));
          return;
        }
        // 가격 알람: repeat과 repeatTf가 세트라 전용 이벤트로 보낸다(추세선 안전코드는 안 건드림).
        // repeatTf는 "봉마다 반복"을 고르는 그 순간의 차트 해상도 스냅샷 — 지금 화면에 보이는 봉이
        // 곧 기준이 되게. 해상도를 못 읽으면 배너를 그릴 때 계산해둔 값(data-tf)을 그대로 쓴다.
        const live = currentResolution();
        const tf = PRICE_REPEAT_TFS_LOCAL.includes(live) ? live : (ev.target.dataset.tf || PRICE_REPEAT_TF_FALLBACK_LOCAL);
        window.dispatchEvent(new CustomEvent('kta-price-edit-opt', {
          detail: { id: alarm.id, repeat: value, repeatTf: value === 'perBar' ? tf : undefined }
        }));
        // 라벨의 봉 이름이 방금 스냅샷한 값과 어긋나지 않게 즉시 갱신(배너는 계속 열어둠).
        if (value === 'perBar') {
          ev.target.dataset.tf = tf;
          const opt = ev.target.querySelector('option[value="perBar"]');
          if (opt) opt.textContent = `봉마다 반복(${TF_KOR_LOCAL[tf] || tf})`;
          // 방금 저장한 기준봉이 곧 지금 보고 있는 봉이면 어긋남이 해소된 것 — 안내 액션도 같이 내린다.
          // (해상도를 못 읽어 data-tf 폴백을 쓴 경우엔 여전히 어긋나 있을 수 있으므로 그대로 남겨둔다.)
          if (PRICE_REPEAT_TFS_LOCAL.includes(live) && tf === live) {
            const fixBtn = banner.querySelector('[data-act="usetf"]');
            if (fixBtn) fixBtn.remove();
          }
        }
      });
    });
    // [2026-08-25] '지금 봉으로 바꾸기' — 저장된 기준봉과 지금 보고 있는 봉이 다를 때만 나타나는
    // 명시적 액션. <select>가 "이미 선택된 옵션 재클릭"엔 change를 안 쏘는 탓에 낡은 기준봉이
    // 갇히는 문제를, 사용자가 직접 누를 때만 풀어주는 유일한 경로다(자동 재스냅샷은 금지 — 위 주석).
    const fixTfBtn = banner.querySelector('[data-act="usetf"]');
    if (fixTfBtn) {
      fixTfBtn.addEventListener('click', () => {
        // 배너를 그릴 때 읽어둔 값이 아니라 **누르는 그 순간**의 해상도를 다시 읽는다
        // (배너를 열어둔 채 봉을 바꿨을 수 있음 — _inDeadZone 캐시-타이밍 사고와 같은 계열의 함정).
        const nowTf = currentResolution();
        if (!PRICE_REPEAT_TFS_LOCAL.includes(nowTf)) return; // 해상도를 못 읽으면 무동작(기존 값 유지)
        // 배너가 열려있는 동안 알람이 삭제됐을 수 있음 — 저장 직전 그 순간 재확인.
        if (!latestAlarms.find(a => a.id === alarm.id)) { banner.remove(); return; }
        window.dispatchEvent(new CustomEvent('kta-price-edit-opt', {
          detail: { id: alarm.id, repeat: 'perBar', repeatTf: nowTf }
        }));
        const sel = banner.querySelector('.qe-sel[data-field="repeat"]');
        if (sel) {
          sel.dataset.tf = nowTf;
          const opt = sel.querySelector('option[value="perBar"]');
          if (opt) opt.textContent = `봉마다 반복(${TF_KOR_LOCAL[nowTf] || nowTf})`;
        }
        fixTfBtn.remove(); // 어긋남이 해소됐으니 안내도 사라짐(배너는 계속 열어둠)
      });
    }
    setTimeout(() => input.focus(), 30);
  }

  function buildLabel(alarm) {
    // [2026-08-23] 추세선은 죽은 dir 필드 대신 실제 기울기(trendIsUp)로 화살표 방향을 정함 — 가격
    // 알람(수평선)은 종전대로 dir(이상/이하)이 실제 유효한 값이라 그대로 사용.
    const isAbove = alarm.type === 'trend' ? trendIsUp(alarm) : alarm.dir === 'above';
    const parts = [];
    if (lineSettings.showBell) parts.push('🔔');
    if (lineSettings.showArrow) parts.push(isAbove ? '↑' : '↓');
    if (lineSettings.showPrice && Number.isFinite(alarm.price)) parts.push(Number(alarm.price).toLocaleString());
    if (lineSettings.showMemo && alarm.memo) parts.push(alarm.memo);
    return parts.join(' ');
  }

  // pts를 같이 넘기면(=safeTrendPoints 결과) 재투영된 좌표까지 서명에 포함된다 — 타임프레임이
  // 바뀌어 재투영 결과가 달라지면 서명이 달라져서 drawTVLines가 알아서 shape을 다시 만든다.
  function trendSig(a, pts) {
    const base = [a.a1.t, a.a1.p, a.a2.t, a.a2.p, a.extend, a.scale].join('|');
    if (!pts) return base;
    return base + '#' + [pts[0].t, pts[0].p, pts[1].t, pts[1].p].join('|');
  }

  // ── [2026-08-25] 추세선 좌표 안전 재투영 ────────────────────────────────────────────
  // 트레이딩뷰는 createMultipointShape에 넘긴 절대시각을 내부에서 "봉 인덱스"로 바꾸는데
  // (activeChart()._convertUserPointsToDataSource 실측), 화면에 로드된 첫 봉보다 2001봉 넘게
  // 이전인 시각은 외삽에 실패해서 조용히 index 0(=로드된 첫 봉)으로 뭉개버린다. 게다가 그 점의
  // 저장 시각까지 첫 봉 시각으로 덮어써서(getPoints/getRawPoints 둘 다 바뀌는 것 실측) 이후
  // 데이터가 더 로드돼도 스스로 복구되지 않는다.
  //   → 업비트 15분봉은 한 번에 300봉(약 3.2일)만 로드돼서 안전 한계가 "약 24일 전"까지인데,
  //     1시간봉은 같은 300봉이 12.5일이라 한계가 약 96일이다. 그래서 오래 유지한 추세선이
  //     1시간봉에선 멀쩡한데 15분봉에서만 말도 안 되는 급경사(거의 수직)로 그려진다
  //     (INJ/KRW 실측 재현 — 픽셀 측정으로 이상적 직선 대비 +311/-464원 어긋남 확인).
  // 대응: 좌표가 안전 구간 밖이면 "같은 직선 위의 다른 두 점"으로 다시 잡아서 넘긴다. 직선 자체는
  // 완전히 동일하고, 알람 발동 판정(content.js)은 저장된 원본 a1/a2를 그대로 쓰므로 영향이 없다.
  const TREND_SAFE_MARGIN_BARS = 1500; // 트레이딩뷰 실측 한계 2001봉보다 넉넉히 안쪽

  function chartPriceScaleIsLog(chart) {
    try { return chart.getSeries().priceScale().getMode() === 1; } catch (e) { return false; }
  }

  function safeTrendPoints(a) {
    const A = { t: a.a1 && a.a1.t, p: a.a1 && a.a1.p };
    const B = { t: a.a2 && a.a2.t, p: a.a2 && a.a2.p };
    const orig = [A, B];
    if (!_chart) return orig;
    if (!Number.isFinite(A.t) || !Number.isFinite(B.t) ||
        !Number.isFinite(A.p) || !Number.isFinite(B.p) || A.t === B.t) return orig;
    const bounds = chartDataTimeBounds(_chart);
    if (!bounds) return orig;
    let secPerBar = 0;
    try { secPerBar = tfSecLocal(_chart.resolution()); } catch (e) { return orig; }
    if (!secPerBar) return orig;
    const safeLeft = bounds.firstSec - TREND_SAFE_MARGIN_BARS * secPerBar;
    if (A.t >= safeLeft && B.t >= safeLeft) return orig; // 정상 범위 — 원본 그대로(기존 동작 유지)
    // 화면에 그려지는 직선을 그대로 재현해야 하므로 보간식은 차트의 "현재" 가격축 모드를 따른다
    // (로그축이면 화면 y가 log(price)라서 기하보간이 같은 직선이 된다).
    const useLog = chartPriceScaleIsLog(_chart) && A.p > 0 && B.p > 0;
    const priceAt = t => {
      const k = (t - A.t) / (B.t - A.t);
      return useLog ? A.p * Math.pow(B.p / A.p, k) : A.p + (B.p - A.p) * k;
    };
    const aIsEarlier = A.t < B.t;
    const E = aIsEarlier ? A : B;
    const L = aIsEarlier ? B : A;
    // [2026-08-25 오푸스 최종검토 발견] "선분만"(extend:none)이고 두 점이 다 안전범위 밖이면 아래의
    // "늦은 쪽을 마지막봉까지 벌리는" 보정을 하면 안 됨 — extendRight/Left가 없는 선분이라 그렇게
    // 늘어난 두 점이 그대로 화면을 가로지르는 선의 끝점이 되어, 실제로는 화면 밖에 있어야 할 오래된
    // 선분이 유령처럼 전체 화면에 그려짐(더블클릭도 안 되고 호버도 안 뜨는, 팝업에서만 지울 수 있는
    // 선이 생김). extend:right/both는 어차피 화면 끝까지 연장되니 이 문제가 없음. 이 조합에서만
    // 재투영을 포기하고 원본을 그대로 반환 — 기존 2001봉 클램프(둘 다 index 0으로 뭉개짐)로
    // 안전하게 폴백한다(발동 판정은 어차피 원본 a1/a2를 쓰므로 영향 없음).
    const ext = a.extend === 'both' ? 'both' : a.extend === 'none' ? 'none' : 'right';
    if (ext === 'none' && L.t < safeLeft) return orig;
    const tE = E.t < safeLeft ? safeLeft : E.t;
    const tL = L.t < safeLeft ? bounds.lastSec : L.t; // 여기 도달하면 extend:none인 경우 L.t >= safeLeft가 보장됨
    if (!(tE < tL)) return orig;
    const pE = priceAt(tE), pL = priceAt(tL);
    if (!Number.isFinite(pE) || !Number.isFinite(pL)) return orig;
    const newE = { t: Math.round(tE), p: pE };
    const newL = { t: Math.round(tL), p: pL };
    return aIsEarlier ? [newE, newL] : [newL, newE];
  }

  function clearTVLines() {
    for (const [, entry] of _shapeMap) {
      try { _chart?.removeEntity(entry.eid); } catch (e) {}
    }
    _shapeMap.clear();
    _pendingIds.clear();
  }

  function createShapeFor(a) {
    const alarmId = a.id;
    const price = parseFloat(a.price);
    const isAbove = a.dir === 'above';
    const color = isAbove ? lineSettings.aboveColor : lineSettings.belowColor;
    const label = buildLabel(a);
    const styleMap = { 0: 0, 1: 1, 2: 2 };
    _pendingIds.add(alarmId);
    Promise.resolve(_chart.createShape(
      { price, time: Date.now() / 1000 | 0 },
      {
        shape: 'horizontal_line',
        lock: true,
        disableSelection: true,
        disableSave: true,
        overrides: {
          linecolor: color,
          linewidth: lineSettings.lineWidth,
          linestyle: styleMap[lineSettings.lineStyle] ?? 2,
          showLabel: !!label,
          textcolor: color,
          fontSize: lineSettings.fontSize,
          bold: lineSettings.fontBold,
          text: label,
          horzLabelsAlign: lineSettings.horzAlign,
        }
      }
    )).then(eid => {
      _pendingIds.delete(alarmId);
      if (eid != null) _shapeMap.set(alarmId, { eid, price, label });
    }).catch(() => { _pendingIds.delete(alarmId); });
  }

  function createTrendShapeFor(a, pts) {
    const alarmId = a.id;
    const P = pts || safeTrendPoints(a);
    const color = trendIsUp(a) ? lineSettings.trendUpColor : lineSettings.trendDownColor;
    const label = buildLabel(a);
    const styleMap = { 0: 0, 1: 1, 2: 2 };
    const ext = a.extend || 'right';
    const extendLeft = ext === 'both';
    const extendRight = ext === 'right' || ext === 'both';
    _pendingIds.add(alarmId);
    Promise.resolve(_chart.createMultipointShape(
      [
        { time: P[0].t, price: P[0].p },
        { time: P[1].t, price: P[1].p },
      ],
      {
        shape: 'trend_line',
        lock: true,
        disableSelection: true,
        disableSave: true,
        overrides: {
          linecolor: color,
          linewidth: lineSettings.lineWidth,
          linestyle: styleMap[lineSettings.lineStyle] ?? 2,
          showLabel: !!label,
          textcolor: color,
          fontSize: lineSettings.fontSize,
          bold: lineSettings.fontBold,
          text: label,
          horzLabelsAlign: lineSettings.horzAlign,
          extendLeft,
          extendRight,
        }
      }
    )).then(eid => {
      _pendingIds.delete(alarmId);
      if (eid != null) _shapeMap.set(alarmId, { eid, label, sig: trendSig(a, P) });
    }).catch(() => { _pendingIds.delete(alarmId); });
  }

  function drawTVLines() {
    if (!_chart) return;
    const active = latestAlarms.filter(a => !a.fired && !a.disabled);
    const activeIds = new Set(active.map(a => a.id));

    // 제거된 알람 shape 삭제
    for (const [id, entry] of _shapeMap) {
      if (!activeIds.has(id)) {
        try { _chart.removeEntity(entry.eid); } catch (e) {}
        _shapeMap.delete(id);
      }
    }

    // [2026-08-25] 추세선을 그리기 전에 "봉 데이터가 실제로 와 있는지"를 먼저 본다.
    // safeTrendPoints의 안전선(=첫 봉보다 1500봉 앞)은 로드된 봉 범위를 기준으로 계산되는데,
    // 범위를 못 얻으면(=아직 데이터가 안 옴) 원본 좌표를 그대로 넘겨버려서 트레이딩뷰의 2001봉
    // 클램프 보호가 통째로 무력화된다. 게다가 한 번 클램프되면 트레이딩뷰가 그 점의 저장 시각까지
    // 덮어써서 스스로 복구되지 않고, 우리 쪽 서명(_shapeMap.sig)은 "그대로"라 다시 그리지도 않는다
    // — 페이지를 새로고침할 때까지 선이 어긋난 채로 남는 경로. 해상도 변경 경로엔 이미 같은 가드가
    // 있는데(scheduleIntervalRedraw: "데이터 없으면 createMultipointShape 실패" 실측 주석) 최초
    // 로드·심볼 전환·저장소 변경으로 들어오는 이 경로엔 없었다. 데이터가 올 때까지 미루고 재시도한다.
    const dataBounds = chartDataTimeBounds(_chart);
    if (!dataBounds && active.some(a => a.type === 'trend')) scheduleIntervalRedraw(0);

    for (const a of active) {
      if (_pendingIds.has(a.id)) continue;
      const label = buildLabel(a);
      const existing = _shapeMap.get(a.id);
      if (a.type === 'trend') {
        if (!dataBounds) continue; // 데이터 없으면 추측 좌표로 그리지 않음(위 재시도가 이어받음)
        // [2026-08-25] 안전 재투영 결과까지 서명에 포함 — 타임프레임이 바뀌어 재투영 값이
        // 달라졌으면 서명이 달라져서 여기서 자동으로 지우고 새 좌표로 다시 그린다.
        // firstSec(로드된 첫 봉 시각)도 서명에 넣는다 — 재투영의 기준점 자체가 바뀌면(심볼 전환
        // 직후의 짧은 데이터 창, 왼쪽 스크롤로 과거 봉 추가 로드 등) 같은 알람이라도 안전 좌표가
        // 달라지므로 다시 그려야 한다. 새 봉이 붙는 것만으론 firstSec이 안 변해서 불필요한 재생성은 없음.
        const pts = safeTrendPoints(a);
        const sig = trendSig(a, pts) + '@' + dataBounds.firstSec;
        if (existing) {
          if (existing.sig === sig && existing.label === label) continue;
          try { _chart.removeEntity(existing.eid); } catch (e) {}
          _shapeMap.delete(a.id);
        }
        try { createTrendShapeFor(a, pts); } catch (e) { console.log('[KTA] createMultipointShape err:', e.message); }
        continue;
      }
      const price = parseFloat(a.price);
      if (existing) {
        // 가격 또는 라벨 변경 시 shape 교체
        if (existing.price === price && existing.label === label) continue;
        try { _chart.removeEntity(existing.eid); } catch (e) {}
        _shapeMap.delete(a.id);
      }
      try { createShapeFor(a); } catch (e) { console.log('[KTA] createShape err:', e.message); }
    }
  }

  function redrawAllTVLines() {
    clearTVLines();
    drawTVLines();
  }

  function renderLines(alarms) {
    latestAlarms = alarms;
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  }

  // ── FAB ──────────────────────────────────────────────────────────────
  function findUpbitLogo() {
    const header = document.querySelector('header');
    if (!header) return null;
    const a = header.querySelector('a');
    if (a) return a;
    return header.firstElementChild || null;
  }

  function getLogoAnchorPos() {
    const el = findUpbitLogo();
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || r.top > 80) return null;
    return {
      l: Math.max(2, Math.round(r.left) - 42),
      t: Math.max(2, Math.round(r.top + (r.height - 32) / 2)),
    };
  }

  function syncFab() {
    const onChart = !!document.getElementById('tv_chart_container');
    const widget = document.getElementById('kta-widget');
    if (!onChart) {
      if (widget) { widget._cleanup?.(); widget.remove(); }
      stopTrendPick();
      return;
    }
    if (widget) {
      const pos = getLogoAnchorPos();
      if (pos) { widget.style.left = pos.l + 'px'; widget.style.top = pos.t + 'px'; }
      return;
    }
    const pos = getLogoAnchorPos() || { l: 4, t: 8 };
    const w = document.createElement('div');
    w.id = 'kta-widget';
    w.style.cssText = `position:fixed;left:${pos.l}px;top:${pos.t}px;z-index:2147483647;`;
    w._cleanup = () => {};
    const btn = document.createElement('button');
    btn.id = 'kta-line-fab';
    btn.title = '클릭으로 알람선 설정 열기';
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="19" height="19" style="display:block;pointer-events:none;"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>`;
    // 업비트 브랜드 남색(#003597) 유지 — 시안 .kta-fab 그대로
    btn.style.cssText = `display:flex;align-items:center;justify-content:center;width:38px;height:34px;background:linear-gradient(180deg,#2451c9,#003597);border:none;padding:0;border-radius:9px 9px 0 0;cursor:pointer;user-select:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.3), 0 6px 16px -6px #003597;transition:.15s;`;
    w.appendChild(btn);
    document.body.appendChild(w);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const panel = document.getElementById('kta-line-settings');
      if (panel) closeSettingsPanel();
      else showSettingsPanel();
    });
  }

  // ── 설정 패널 ─────────────────────────────────────────────────────────
  let _lineSettingsSnapshot = null; // 패널 열 때 스냅샷 — 적용 없이 닫으면 여기로 되돌림
  let _previewDebounce = null;

  function showSettingsPanel() {
    document.getElementById('kta-line-settings')?.remove();
    const widget = document.getElementById('kta-widget');
    if (!widget) return;
    _lineSettingsSnapshot = { ...lineSettings };
    const s = lineSettings;
    const t = getTheme();

    const panel = document.createElement('div');
    panel.id = 'kta-line-settings';
    panel.innerHTML = `
<style>
#kta-line-settings{position:absolute;top:100%;left:0;margin-top:-1px;width:286px;background:${t.grad};background-color:${t.bg};border:1px solid ${t.borderStrong};border-radius:0 13px 13px 13px;padding:13px;color:${t.text};font:13px/1.5 'Pretendard',system-ui,sans-serif;box-shadow:${t.shadow}, inset 0 1px 0 ${t.hl};max-height:calc(100vh - 60px);overflow-y:auto;}
#kta-line-settings *{box-sizing:border-box;}
#kta-line-settings .ls-hd{display:flex;align-items:center;gap:8px;margin-bottom:11px;font-size:14px;font-weight:800;}
#kta-line-settings .ls-hd-left{display:flex;align-items:center;gap:8px;}
#kta-line-settings .ls-hd-ico{color:${t.aInk};}
#kta-line-settings .ls-hd-right{margin-left:auto;display:flex;align-items:center;gap:5px;}
#kta-line-settings .ls-theme{height:28px;padding:0 10px;border-radius:8px;display:inline-flex;align-items:center;gap:5px;font:700 12px 'Pretendard',system-ui,sans-serif;cursor:pointer;background:${t.grad};background-color:${t.bg2};border:1px solid ${t.border};color:${t.t2};box-shadow:inset 0 1px 0 ${t.hl};transition:.15s;white-space:nowrap;}
#kta-line-settings .ls-theme:hover{color:${t.text};border-color:${t.borderStrong};transform:translateY(-1px);}
#kta-line-settings .ls-sec{margin-bottom:11px;}
#kta-line-settings .ls-lbl{display:flex;align-items:center;gap:6px;color:${t.t2};font-size:11.5px;font-weight:800;margin-bottom:6px;}
#kta-line-settings .ls-lbl em{font-style:normal;color:${t.aInk};font-variant-numeric:tabular-nums;}
#kta-line-settings .ls-row{display:flex;gap:8px;flex-wrap:wrap;}
#kta-line-settings label{cursor:pointer;display:inline-flex;align-items:center;gap:6px;font-size:11.5px;font-weight:600;color:${t.t3};background:${t.inset};border:1px solid ${t.border};border-radius:8px;padding:5px 9px;box-shadow:inset 0 1px 3px ${t.sink};transition:.15s;}
#kta-line-settings label:hover{border-color:${t.borderStrong};color:${t.t2};}
#kta-line-settings label:has(input:checked){color:#fff;background:linear-gradient(180deg,${t.a1},${t.a2});border-color:transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.28);}
#kta-line-settings label input[type=checkbox],#kta-line-settings label input[type=radio]{position:absolute;opacity:0;width:0;height:0;margin:0;}
/* [2026-08-07] 선 스타일 미리보기 스와치.
   기존에는 border-top:2px dashed/dotted 를 썼는데, 폭 22px · 두께 2px 짜리 얇은 조각에서는
   크롬이 파선(dashed)을 거의 실선처럼 그려버려서 "파선인데 실선으로 보인다"는 문제가 있었다.
   border-style의 자동 대시 계산에 맡기지 말고 반복 그라디언트로 길이/간격을 직접 지정한다. */
#kta-line-settings .sp{width:22px;height:2px;border-radius:2px;background:currentColor;display:inline-block;}
#kta-line-settings .sp.dot{border-radius:0;background-image:repeating-linear-gradient(90deg,currentColor 0 2px,transparent 2px 5px);background-color:transparent;}
#kta-line-settings .sp.dash{border-radius:0;background-image:repeating-linear-gradient(90deg,currentColor 0 6px,transparent 6px 10px);background-color:transparent;}
#kta-line-settings input[type=range]{width:100%;accent-color:${t.a1};vertical-align:middle;height:6px;cursor:pointer;}
#kta-line-settings .ls-col{display:flex;align-items:center;gap:8px;background:${t.inset};border:1px solid ${t.border};border-radius:9px;padding:5px 7px;box-shadow:inset 0 1px 3px ${t.sink};}
#kta-line-settings input[type=color]{width:100%;height:24px;border:none;border-radius:6px;cursor:pointer;padding:0;background:none;}
#kta-line-settings .ls-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px;}
#kta-line-settings .ls-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;padding:9px;background:linear-gradient(180deg,${t.a1},${t.a2});border:none;border-radius:9px;color:#fff;font-weight:800;cursor:pointer;font-size:12.5px;font-family:'Pretendard',system-ui,sans-serif;margin-top:10px;box-shadow:inset 0 1px 0 rgba(255,255,255,.28), 0 6px 16px -6px ${t.a2};transition:.16s;}
#kta-line-settings .ls-btn:hover{transform:translateY(-1px);filter:saturate(1.12);}
#kta-line-settings .ls-x{cursor:pointer;color:${t.x};width:24px;height:24px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:${t.grad};background-color:${t.bg2};border:1px solid ${t.border};box-shadow:inset 0 1px 0 ${t.hl};transition:.15s;}
#kta-line-settings .ls-x:hover{color:${t.text};border-color:${t.borderStrong};}
#kta-line-settings .ls-div{border:none;border-top:1px solid ${t.div};margin:10px 0;}
/* [2026-08-23] 가격/추세 공통·전용 항목 구분 — 형이 "가격과 추세 공통항목/가격 항목/추세 항목을
   구분해서 넣어달라"고 요청. 색점 + 소제목으로 그룹을 나눔(기능은 그대로, 배치만 재구성). */
#kta-line-settings .ls-group-title{display:flex;align-items:center;gap:6px;font-size:12.5px;font-weight:800;margin:0 0 9px;color:${t.text};}
#kta-line-settings .ls-group-title.notfirst{margin-top:15px;padding-top:14px;border-top:1px solid ${t.div};}
#kta-line-settings .ls-group-title .gdot{width:7px;height:7px;border-radius:50%;flex:none;}
#kta-line-settings .ls-group-title.common .gdot{background:${t.aInk};}
#kta-line-settings .ls-group-title.price .gdot{background:#3b82f6;}
#kta-line-settings .ls-group-title.trend .gdot{background:#f43f5e;}
</style>
<div class="ls-hd">
  <div class="ls-hd-left"><span class="ls-hd-ico">${ICO_BELL}</span>알람선 설정</div>
  <div class="ls-hd-right">
    <button class="ls-theme">${t.icon} ${t.nextLabel}</button>
    <span class="ls-x">${ICO_X}</span>
  </div>
</div>

<div class="ls-group-title common"><span class="gdot"></span>공통(가격·추세 알람선)</div>
<div class="ls-sec">
  <div class="ls-lbl">표시 항목</div>
  <div class="ls-row">
    <label><input type="checkbox" id="ls-bell" ${s.showBell?'checked':''}> 종</label>
    <label><input type="checkbox" id="ls-memo" ${s.showMemo?'checked':''}> 비고</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 스타일</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-st" value="0" ${s.lineStyle===0?'checked':''}><i class="sp"></i>실선</label>
    <label><input type="radio" name="ls-st" value="1" ${s.lineStyle===1?'checked':''}><i class="sp dot"></i>점선</label>
    <label><input type="radio" name="ls-st" value="2" ${s.lineStyle===2?'checked':''}><i class="sp dash"></i>파선</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 굵기 <em><span id="ls-wv">${s.lineWidth}</span>px</em></div>
  <input type="range" id="ls-w" min="1" max="4" value="${s.lineWidth}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">폰트 크기 <em><span id="ls-fsv">${s.fontSize}</span>px</em></div>
  <input type="range" id="ls-fs" min="9" max="18" value="${s.fontSize}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">텍스트 가로 위치</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-ha" value="left" ${s.horzAlign==='left'?'checked':''}> 왼쪽</label>
    <label><input type="radio" name="ls-ha" value="center" ${s.horzAlign==='center'?'checked':''}> 가운데</label>
    <label><input type="radio" name="ls-ha" value="right" ${s.horzAlign==='right'?'checked':''}> 오른쪽</label>
  </div>
</div>
<div class="ls-sec"><label><input type="checkbox" id="ls-bold" ${s.fontBold?'checked':''}> 폰트 굵게</label></div>

<div class="ls-group-title price notfirst"><span class="gdot"></span>가격 알람 전용</div>
<div class="ls-sec">
  <div class="ls-lbl">표시 항목</div>
  <div class="ls-row">
    <label><input type="checkbox" id="ls-arrow" ${s.showArrow?'checked':''}> 방향(↑↓)</label>
    <label><input type="checkbox" id="ls-price" ${s.showPrice?'checked':''}> 가격</label>
  </div>
</div>
<div class="ls-grid ls-sec">
  <div><div class="ls-lbl">이상 색상</div><div class="ls-col"><input type="color" id="ls-ac" value="${s.aboveColor}"></div></div>
  <div><div class="ls-lbl">이하 색상</div><div class="ls-col"><input type="color" id="ls-bc" value="${s.belowColor}"></div></div>
</div>

<div class="ls-group-title trend notfirst"><span class="gdot"></span>추세선 알람 전용</div>
<div class="ls-grid ls-sec">
  <div><div class="ls-lbl">상승 색상</div><div class="ls-col"><input type="color" id="ls-tuc" value="${s.trendUpColor}"></div></div>
  <div><div class="ls-lbl">하락 색상</div><div class="ls-col"><input type="color" id="ls-tdc" value="${s.trendDownColor}"></div></div>
</div>
<div class="ls-sec"><label>${ICO_MAGNET} &nbsp;<input type="checkbox" id="ls-magnet" ${s.magnetEnabled?'checked':''}> 자석(캔들 스냅)</label></div>
<div class="ls-sec">
  <div class="ls-lbl">자석 범위 <em><span id="ls-magpxv">${s.magnetPx}</span>px</em></div>
  <input type="range" id="ls-magpx" min="2" max="20" value="${s.magnetPx}" ${s.magnetEnabled?'':'disabled'}>
</div>

<button class="ls-btn">${ICO_REFRESH} 적용 — 알람선 다시 그리기</button>`;

    widget.appendChild(panel);
    panel.querySelector('.ls-x').onclick = () => closeSettingsPanel();
    panel.querySelector('.ls-theme').onclick = () => {
      panelTheme = panelTheme === 'dark' ? 'light' : 'dark';
      saveChartSettings(); showSettingsPanel();
    };
    document.getElementById('ls-w').oninput = function () { document.getElementById('ls-wv').textContent = this.value; };
    document.getElementById('ls-fs').oninput = function () { document.getElementById('ls-fsv').textContent = this.value; };
    document.getElementById('ls-magpx').oninput = function () { document.getElementById('ls-magpxv').textContent = this.value; };
    document.getElementById('ls-magnet').addEventListener('change', function () {
      document.getElementById('ls-magpx').disabled = !this.checked;
    });

    // [2026-08-23] 값 바꾸면 적용 누르기 전에도 차트에 바로 반영(실시간 미리보기) — 형 피드백.
    // 색상피커/슬라이더를 드래그하는 동안 계속 쏟아지는 input 이벤트마다 매번 전체 재생성(비동기)을
    // 걸면 깜빡임·경합이 생길 수 있어서 짧게 debounce.
    panel.addEventListener('input', () => {
      lineSettings = readPanelSettings(panel);
      if (_previewDebounce) clearTimeout(_previewDebounce);
      _previewDebounce = setTimeout(() => { redrawAllTVLines(); _previewDebounce = null; }, 120);
    });

    panel.querySelector('.ls-btn').onclick = () => {
      lineSettings = readPanelSettings(panel);
      _lineSettingsSnapshot = null; // 저장 완료 — 닫을 때 되돌릴 필요 없음
      saveChartSettings();
      redrawAllTVLines();
      closeSettingsPanel();
    };

    // [2026-08-23] 패널 바깥을 클릭하면 자동으로 닫히게 — 예전엔 적용/종버튼을 눌러야만 닫혔음(형 피드백).
    document.addEventListener('click', handlePanelOutsideClick, true);
  }

  // 폼 현재 값을 lineSettings 형태로 읽어옴 — 실시간 미리보기와 "적용" 저장이 공유해서 씀.
  function readPanelSettings(panel) {
    return {
      showBell: document.getElementById('ls-bell').checked,
      showArrow: document.getElementById('ls-arrow').checked,
      showMemo: document.getElementById('ls-memo').checked,
      showPrice: document.getElementById('ls-price').checked,
      lineStyle: parseInt(panel.querySelector('input[name="ls-st"]:checked')?.value ?? '2'),
      lineWidth: parseInt(document.getElementById('ls-w').value),
      fontSize: parseInt(document.getElementById('ls-fs').value),
      fontBold: document.getElementById('ls-bold').checked,
      horzAlign: panel.querySelector('input[name="ls-ha"]:checked')?.value ?? 'right',
      vertAlign: 'bottom',
      aboveColor: document.getElementById('ls-ac').value,
      belowColor: document.getElementById('ls-bc').value,
      trendUpColor: document.getElementById('ls-tuc').value,
      trendDownColor: document.getElementById('ls-tdc').value,
      magnetEnabled: document.getElementById('ls-magnet').checked,
      magnetPx: parseInt(document.getElementById('ls-magpx').value),
      // 이 패널에서 다루는 항목이 아니니 기존 값(안내배너 위치) 유지 — 안 그러면 적용 누를 때마다 초기화됨.
      pickBannerPos: lineSettings.pickBannerPos,
    };
  }

  // 적용 없이 닫히는 모든 경로(X버튼/바깥클릭/종버튼 재클릭)가 공용으로 타는 닫기 함수 —
  // 미리보기로 바꿔본 값이 있으면 패널 열기 전 상태로 되돌린 다음 닫는다.
  function closeSettingsPanel() {
    if (_previewDebounce) { clearTimeout(_previewDebounce); _previewDebounce = null; }
    if (_lineSettingsSnapshot) {
      lineSettings = _lineSettingsSnapshot;
      redrawAllTVLines();
    }
    _lineSettingsSnapshot = null;
    document.getElementById('kta-line-settings')?.remove();
    document.removeEventListener('click', handlePanelOutsideClick, true);
  }

  function handlePanelOutsideClick(e) {
    const panel = document.getElementById('kta-line-settings');
    if (!panel) { document.removeEventListener('click', handlePanelOutsideClick, true); return; }
    const fabBtn = document.getElementById('kta-line-fab');
    if (panel.contains(e.target) || e.target === fabBtn || fabBtn?.contains(e.target)) return;
    closeSettingsPanel();
  }

  // ── 추세선 좌표 클릭 샘플링(1단계: 드래그 없이 클릭 2회로 좌표 채움) ──
  function getChartIframeDoc() {
    try {
      const iframe = document.querySelector('#tv_chart_container iframe');
      return iframe?.contentDocument || null;
    } catch (e) { return null; }
  }

  function startTrendPick(editId) {
    if (!_chart) return;
    // [2026-08-23] 1초봉은 결손(빈 캔들) 비율이 너무 높아 추세 알람이 사실상 무의미(형 확인) — 아예 시작을 막음.
    let curTf = null;
    try { curTf = _chart.resolution(); } catch (e) {}
    if (curTf === '1S') {
      injectDrawBannerStyleOnce();
      showDrawBlocked('1초봉에서는 추세선 알람을 만들 수 없어요 · 차트 시간대를 바꿔주세요');
      return;
    }
    stopTrendPick();
    _picking = true;
    _pickMode = 'trend';
    _pickStep = 1;
    _pickA1 = null;
    _pickA1Px = null;
    _pickCross = null;
    _magnetHit = null;
    _inDeadZone = false;
    _pickEditId = editId || null;
    injectDrawBannerStyleOnce();
    showDrawBanner(1);
    // crossHairMoved 구독은 setupEvents()에서 상시 하나만 유지(중복 구독 버그 방지, 위 주석 참고) —
    // 여기선 별도 구독 안 걸고 그 상시 구독이 채워주는 _pickCross를 그대로 읽기만 한다.
    document.addEventListener('click', handleTrendPickClick, true);
    document.addEventListener('keydown', handleTrendPickEscape, true);
    const idoc = getChartIframeDoc();
    if (idoc) {
      idoc.addEventListener('click', handleTrendPickClick, true);
      idoc.addEventListener('keydown', handleTrendPickEscape, true);
      // 데이터 없는 구간 실시간 감지용 — iframe 문서에만 건다(e.clientX 좌표계가 그 문서 기준이라야 함).
      idoc.addEventListener('mousemove', handlePickRawMouseMove, true);
    }
  }

  // [2026-08-23] 가격 알람(수평선) 좌표 찍기 — 추세선과 같은 픽 인프라를 재사용하되 1클릭으로
  // 바로 끝남(가격알람은 점 1개, 시각은 의미 없음). editId 있으면 기존 알람 재배치, 없으면 신규 생성
  // (형 요청 1번, 오푸스 설계 project_kalert_price_alarm_click_create_20260823 그대로 구현).
  function startPriceAlarmPick(editId) {
    if (!_chart) return;
    stopTrendPick();
    _picking = true;
    _pickMode = 'price';
    _pickStep = 1;
    _pickA1 = null;
    _pickA1Px = null;
    _pickCross = null;
    _magnetHit = null;
    _inDeadZone = false;
    _pickEditId = editId || null;
    injectDrawBannerStyleOnce();
    if (editId) {
      showDrawBanner(1, { msg: '가격 알람을 다시 놓을 위치를 클릭하세요' });
    } else {
      // "직접 입력"은 기존 팝업 숫자입력 흐름으로 빠지는 탈출구(quickAdd와 동일 경로) — 시안 그대로.
      showDrawBanner(1, {
        msg: '알람을 놓을 가격을 클릭하세요',
        linkText: '직접 입력',
        onLink: () => { stopTrendPick(); window.dispatchEvent(new CustomEvent('kta-open-price-popup')); },
      });
    }
    document.addEventListener('click', handleTrendPickClick, true);
    document.addEventListener('keydown', handleTrendPickEscape, true);
    const idoc = getChartIframeDoc();
    if (idoc) {
      idoc.addEventListener('click', handleTrendPickClick, true);
      idoc.addEventListener('keydown', handleTrendPickEscape, true);
      idoc.addEventListener('mousemove', handlePickRawMouseMove, true);
    }
  }

  // 클릭 리스너만 정리(좌표 확정 직후 호출) — 배너/Esc는 finishPickCleanup이 담당.
  // crossHairMoved 구독은 상시 구독(setupEvents)이라 여기서 해지 안 함.
  function releasePickListeners() {
    document.removeEventListener('click', handleTrendPickClick, true);
    const idoc = getChartIframeDoc();
    if (idoc) {
      idoc.removeEventListener('click', handleTrendPickClick, true);
      idoc.removeEventListener('mousemove', handlePickRawMouseMove, true);
    }
  }

  // 상태 완전 초기화 + 배너 제거(취소/저장 완료 양쪽에서 공용으로 씀).
  function finishPickCleanup() {
    document.removeEventListener('keydown', handleTrendPickEscape, true);
    const idoc = getChartIframeDoc();
    if (idoc) idoc.removeEventListener('keydown', handleTrendPickEscape, true);
    _picking = false;
    _pickMode = 'trend';
    _pickStep = 0;
    _pickA1 = null;
    _pickA1Px = null;
    _pickEditId = null;
    _magnetHit = null;
    _inDeadZone = false;
    removeMagnetPreview();
    removeDrawBanner();
    // 가격알람 생성폼이 뜬 채로 Esc/심볼변경 등 다른 경로로 정리될 수 있어서 리스너 누수 방지.
    if (_priceCreateListener) { window.removeEventListener('kta-price-created', _priceCreateListener); _priceCreateListener = null; }
  }

  // 전체 취소(Esc, 심볼변경, 차트이탈 등 어디서든 호출 가능) — 픽 도중이든 확인폼 단계든 안전하게 정리.
  function stopTrendPick() {
    releasePickListeners();
    finishPickCleanup();
  }

  // 클릭 위치를 최상위 페이지 기준 픽셀좌표로 환산 — 차트가 iframe 안에 있으면 iframe의
  // getBoundingClientRect() 오프셋을 더해줘야 최상위 document 기준 fixed 배너를 정확히 앉힐 수 있음.
  function clickPagePos(e) {
    const idoc = getChartIframeDoc();
    if (idoc && e.target && e.target.ownerDocument === idoc) {
      const iframeEl = document.querySelector('#tv_chart_container iframe');
      const rect = iframeEl ? iframeEl.getBoundingClientRect() : { left: 0, top: 0 };
      return { x: rect.left + e.clientX, y: rect.top + e.clientY };
    }
    return { x: e.clientX, y: e.clientY };
  }

  // [2026-08-23] 상장 직후 코인처럼 실제 캔들 데이터가 없는 구간(상장 이전 시점)을 클릭했을 때
  // 걸러내려고 처음엔 Number.isFinite로 막았는데, coordinateToTime()이 데이터 범위 밖에서도
  // NaN이 아니라 선형 외삽한 "그럴듯한 가짜 시간값"을 그대로 돌려주는 걸 확인해서(형이 3.2.0.11
  // 재테스트로 재현) 그 체크로는 못 걸렀음. 대신 series.data().first()/.last()로 실제 존재하는
  // 첫/마지막 캔들의 진짜 시간을 직접 얻어서 그 범위 밖 클릭을 걸러낸다.
  function chartDataTimeBounds(chart) {
    try {
      const d = chart.getSeries().data();
      const first = d.first();
      const last = d.last();
      if (!first || !last || !Array.isArray(first.value) || !Array.isArray(last.value)) return null;
      const firstSec = Math.round(first.value[0]);
      const lastSec = Math.round(last.value[0]);
      if (!Number.isFinite(firstSec) || !Number.isFinite(lastSec)) return null;
      return { firstSec, lastSec };
    } catch (e) { return null; }
  }

  // [2026-08-23] msg 기본값은 죽은구간 거부 문구 그대로, 가격알람 동률거절 등 다른 사유는 호출부에서 넘김.
  function showPickRejectToast(pagePos, msg) {
    const el = document.createElement('div');
    el.id = 'kta-pick-toast';
    el.textContent = msg || '⚠️ 캔들 데이터가 없는 구간이에요 · 실제 캔들이 있는 곳을 클릭해주세요';
    el.style.cssText = `position:fixed;z-index:2147483647;left:${pagePos.x}px;top:${pagePos.y - 34}px;` +
      `transform:translate(-50%,-100%);background:linear-gradient(180deg,#2451c9,#003597);color:#fff;` +
      `padding:7px 12px;border-radius:10px;font:700 12px/1.3 'Pretendard',system-ui,sans-serif;` +
      `white-space:nowrap;box-shadow:0 10px 24px -8px rgba(0,53,151,.6);pointer-events:none;`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1600);
  }

  // crossHairMoved와 별개인 순수 DOM mousemove — 데이터 없는 구간 진입을 실시간으로 직접 감지.
  // 반드시 iframe 문서 자체에서 벌어지는 이벤트만 본다(e.clientX가 그 문서 기준 좌표라야 함,
  // 최상위 document에서 온 이벤트는 iframe 밖이라 좌표계가 안 맞음 — 애초에 등록도 iframe에만 함).
  function handlePickRawMouseMove(e) {
    if (!_picking || !_chart) return;
    let t = null;
    try { t = _chart.getTimeScale().coordinateToTime(e.clientX); } catch (err) {}
    const dead = (t == null || !Number.isFinite(t));
    if (dead && !_inDeadZone) {
      // 방금 죽은 구간에 진입 — 얼어붙은 자석 미리보기가 그대로 남지 않게 정리.
      _magnetHit = null;
      removeMagnetPreview();
    }
    _inDeadZone = dead;
  }

  // [2026-08-23 재수정] _inDeadZone은 별도 mousemove 이벤트 스트림이 채우는 캐시값이라, 클릭
  // 시점과 정확히 같은 좌표를 봤다는 보장이 없음(빠르게 스와이프해서 바로 클릭하면 마지막으로
  // 기록된 mousemove가 실제 클릭 좌표보다 한두 프레임 뒤처질 수 있음, 형이 MBL/XCN/오닉스 등
  // 실제 캔들 데이터 위를 클릭했는데도 죽은구간으로 오판되는 걸로 재현). click 이벤트 자신의
  // e.clientX로 그 순간 직접 재계산해서 캐시된 _inDeadZone 대신 그 값을 신뢰한다 —
  // FOLD류(진짜 상장 이전 빈 구간)는 여전히 정확히 걸러지고, 오탐만 없어짐.
  function handleTrendPickClick(e) {
    // preventDefault/stopPropagation 호출 금지 — 차트 본연의 팬/줌 동작을 깨뜨림.
    if (!_picking) return;
    const px = clickPagePos(e);

    // [2026-08-23] 가격 알람은 시간축 죽은구간 체크(coordinateToTime 기반)를 아예 안 씀 — 실측
    // (project_kalert_price_alarm_click_create_20260823, F5) 결과 마지막 봉 오른쪽 여백은
    // coordinateToTime만 null이지 crossHairMoved는 정상 발화하고 price도 y 따라 정확히 바뀜.
    // 대신 크로스헤어 자체의 신선도를 offsetX/offsetY로 직접 검증(같은 좌표계임은 Wave-3에서 실측
    // 확인) — 죽은구간(가격축 위 등, crossHairMoved 자체가 안 옴)에서는 어긋나서 걸러짐.
    // [2026-08-24 수정] offsetY만 보던 걸 offsetX도 같이 보게 확장 — 오푸스 최종검토에서 발견:
    // 클릭 리스너가 최상위 document에도 걸려있어서(배너 클릭 가로채기용) 세로만 보면, 차트 밖
    // (주문창/호가창 등)의 클릭이 우연히 같은 세로 좌표라는 이유만으로 통과할 여지가 있었음 —
    // 추세모드는 이미 X·Y 둘 다 봄(같은 세션에 수정), 가격모드도 동일하게 맞춤.
    if (_pickMode === 'price') {
      // [2026-08-25] 죽은구간(상장 이전) 폴백 — 가격 알람은 정의상 시간축을 안 쓰므로, 캔들이
      // 없는 왼쪽 빈 구간에서도 만들 수 있어야 한다(형 실기 제보 증상②: 그 구간을 클릭하면
      // "캔들 데이터가 없는 구간이에요" 토스트로 거절됨). 거기선 crossHairMoved가 안 와서
      // _pickCross가 얼어붙고 아래 신선도 체크가 무조건 실패하는 게 원인이라, 크로스헤어를
      // 건너뛰고 클릭 이벤트 자신의 y로 가격을 직접 계산한다. 자석은 애초에 붙을 봉이 없는
      // 구간이라 적용 대상이 아님(추측 스냅 금지 원칙 그대로).
      const dzCross = deadZonePriceCross(e, _chart);
      if (dzCross) {
        // [2026-08-25 오푸스 설계] 가격 알람은 시간축이 없어서 자석 대상도 아니고 크로스헤어
        // 원시값도 아니라 클릭 y로 직접 계산한 실수값이라, 틱 스냅이 특히 더 필요한 경로.
        finishPriceAlarmPick({ p: roundToTick(dzCross.price, currentKrwSym(), 'round') }, px);
        return;
      }
      if (!_pickCross || !Number.isFinite(_pickCross.price) ||
          !Number.isFinite(_pickCross.offsetX) || !Number.isFinite(_pickCross.offsetY)) return; // 마우스 한 번도 안 움직임 — 조용히 무시
      if (!Number.isFinite(e.clientX) || !Number.isFinite(e.clientY) ||
          Math.abs(e.clientX - _pickCross.offsetX) > 3 || Math.abs(e.clientY - _pickCross.offsetY) > 3) {
        showPickRejectToast(px);
        return;
      }
      // [2026-08-25 오푸스 설계] 가격 알람 좌표는 자석 켜짐/꺼짐 둘 다 유효 호가로 반올림한다.
      // 자석이 최근 봉에 붙었으면 이미 틱 정합이라 no-op이지만, 2025-07-31 호가단위 개편 이전
      // 옛날 봉에 붙으면 오늘 기준 무효 호가가 될 수 있어서(실측: 개편전 일봉 85% 불일치) 자석
      // 결과도 똑같이 반올림한다 — 추세선과 달리 가격알람은 "그 봉을 정확히 지나야 하는 기하학적
      // 점"이 아니라 "주문 넣을 가격" 그 자체이므로 값을 미세조정해도 의미가 안 깨진다.
      const raw = (_magnetHit ? _magnetHit.price : _pickCross.price);
      const price = roundToTick(raw, currentKrwSym(), 'round');
      finishPriceAlarmPick({ p: price }, px);
      return;
    }

    // [2026-08-24] coordinateToTime(e.clientX) 재계산으로 죽은구간을 걸러내던 방식이, 활발하게
    // 움직이는 코인(ENA 등)에서 실제로 존재하는 봉 위인데도 null을 반환해 오탐 거절하는 사례가
    // 실측됨(형이 15분봉에서 자석이 "고가"로 정확히 스냅했는데도 클릭이 거절되는 걸 재현, ENA/KRW).
    // 라이브로 sweep해서 확인해보니 마지막 봉 시간을 살짝 넘는 픽셀에서 crossHairMoved는 근처 실제
    // 봉으로 스냅된 time을 정상 반환하는데(자석이 이걸로 정확히 스냅함) coordinateToTime의 연속
    // 픽셀→시간 매핑은 그 픽셀을 여백으로 판단해 null을 주는 어긋남이 원인 — 실시간 갱신으로 여백
    // 경계가 계속 흔들리는 활발한 코인일수록 자주 발생. coordinateToTime에 더 이상 의존하지 않고
    // 가격모드(F5)와 동일한 방식으로 크로스헤어 자신의 좌표 신선도(offsetX/offsetY)로 직접 검증한다.
    // 진짜 죽은구간(상장 이전 등, crossHairMoved 자체가 거의 안 쏨)에서는 _pickCross가 마지막으로
    // 발화했던 자리에 얼어붙어 있어서 실제 클릭 좌표와 크게 어긋나 여전히 정확히 걸러짐(FOLD 실측
    // 재확인 — 죽은구간을 스윕해도 crossHairMoved가 거의 발화하지 않아 offsetX가 클릭 지점과 안 맞음).
    if (!_pickCross || !Number.isFinite(_pickCross.time) || !Number.isFinite(_pickCross.price) ||
        !Number.isFinite(_pickCross.offsetX) || !Number.isFinite(_pickCross.offsetY)) return; // 마우스 한 번도 안 움직임 — 조용히 무시.
    if (!Number.isFinite(e.clientX) || !Number.isFinite(e.clientY) ||
        Math.abs(e.clientX - _pickCross.offsetX) > 3 || Math.abs(e.clientY - _pickCross.offsetY) > 3) {
      showPickRejectToast(px);
      return;
    }
    // 아래 검증은 위 신선도체크로 이미 거의 다 걸러지지만, 만일을 위한 2차 방어선으로 그대로 둔다.
    const bounds = chartDataTimeBounds(_chart);
    if (bounds && (_pickCross.time < bounds.firstSec || _pickCross.time > bounds.lastSec + 1)) {
      showPickRejectToast(px);
      return;
    }
    // 자석이 켜져있고 스냅된 값이 있으면 그 값을 쓴다(t는 원래 크로스헤어값 그대로 — 이미 봉에 스냅됨).
    // [2026-08-25 오푸스 설계] 자석 스냅 결과(봉의 실제 OHLC)는 반올림하지 않고 원본 그대로 쓴다 —
    // 추세선 앵커는 "그 꼬리에 정확히 닿는 기하학적 점"이 의미라서 값을 밀면 선이 그 봉을 안
    // 지나가게 되고, 어제 넣은 호버 툴팁(trendPointLevel, 위 약 490행)의 "고가/저가" 라벨도 봉
    // OHLC와 정확한 등호(===) 대조라 조용히 깨진다. 자석 없이 자유클릭한 값만 유효 호가로 반올림.
    const point = { t: Math.round(_pickCross.time), p: (_magnetHit ? _magnetHit.price : roundToTick(_pickCross.price, currentKrwSym(), 'round')) };
    if (_pickStep === 1) {
      _pickA1 = point;
      _pickA1Px = px;
      _pickStep = 2;
      showDrawBanner(2);
    } else if (_pickStep === 2) {
      finishTrendPick(_pickA1, point, _pickA1Px, px);
    }
  }

  // [2026-08-23] 가격 알람 좌표 찍기 완료 — editId 있으면 재배치, 없으면 신규 생성(형 요청 1번).
  // [2026-08-24 수정] 원래는 재배치(editId)를 추세선 editId 경로와 같은 패턴("메모/조건 안 묻고
  // 바로 저장")으로 짜서 동률 사전체크·content.js 응답 대기를 전부 건너뛰고 무조건 즉시 "완료"를
  // 찍었는데, 오푸스 최종검토에서 확정: 그러면 dir 재판정이 아예 안 일어나서 "다시찍자마자 바로
  // 발동"하는 사고가 남음(project_kalert_price_alarm_click_create_20260823 참고). 신규생성과
  // 동일한 2중 방어(값싼 사전체크 + content.js 응답 대기)를 재배치에도 그대로 적용.
  function finishPriceAlarmPick(point, px) {
    const editId = _pickEditId;
    releasePickListeners();
    _pickStep = 0;
    _magnetHit = null;
    _inDeadZone = false;
    removeMagnetPreview();
    // [2026-08-23] 동률(=현재가) 사전 방어 — 마지막 봉 종가를 값싼 근사치로 써서(실측 F1: 실시간가와
    // 거의 항상 동일) 자석이 마지막봉 종가에 붙은 뻔한 케이스는 왕복 없이 즉시 거절. 그 값이 정말
    // 최신인지는 보장 못 하므로 최종 판정은 content.js가 저장 직전 실시간가로 한 번 더 함(§ 2중 방어).
    // 재배치·신규생성 둘 다 동일하게 적용.
    let lastClose = null;
    try { lastClose = _chart.getSeries().data().last()?.value[4]; } catch (err) {}
    if (Number.isFinite(lastClose) && point.p === lastClose) {
      finishPickCleanup();
      showPickRejectToast(px, '⚠️ 현재가와 같은 가격이에요 · 조금 위나 아래를 클릭해주세요');
      return;
    }
    if (editId) {
      const onRepriced = ev => {
        window.removeEventListener('kta-price-repriced', onRepriced);
        const d = ev.detail || {};
        if (!d.ok || d.id !== editId) {
          showPickRejectToast(px, '⚠️ 현재가와 같은 가격이에요 · 조금 위나 아래를 클릭해주세요');
          return;
        }
        showDrawDone(px);
      };
      window.addEventListener('kta-price-repriced', onRepriced);
      window.dispatchEvent(new CustomEvent('kta-price-quick-reprice', { detail: { id: editId, price: point.p } }));
      return;
    }
    // [2026-08-25] 신규 가격알람의 "봉마다 반복" 기준봉 = 지금 보고 있는 차트 해상도.
    // 이걸 같이 안 실어보내면 content.js가 "마지막으로 골랐던 값"만 물려받아, 1분봉 차트에서 만들어도
    // repeatTf가 15분(직전에 쓰던 값)으로 저장된다(오푸스 최종검토 진단). 해상도를 못 읽으면 아예 키를
    // 안 실어서 content.js가 기존 폴백(priceLastRepeatTf → 15분)으로 안전하게 후퇴하게 둔다.
    const liveTf = currentResolution();
    window.dispatchEvent(new CustomEvent('kta-price-quick-create', {
      detail: { price: point.p, repeatTf: PRICE_REPEAT_TFS_LOCAL.includes(liveTf) ? liveTf : undefined }
    }));
    showPriceCreateForm(point.p, px);
  }

  // [2026-08-23] 생성 직후 메모 미니폼 — 가격은 이미 확정(chart_lines가 계산), 방향은 content.js가
  // 저장 직전 실시간가로 최종 판정해서 kta-price-created로 돌려줄 때까지 "판정 중" 표시.
  // 동시에 여러 개 뜰 수 없음(픽은 1개 세션만 진행되므로) — 리스너는 모듈 전역 하나로 관리해
  // Esc/✕ 등 어느 경로로 닫혀도 finishPickCleanup에서 확실히 정리됨.
  let _priceCreateListener = null;
  function showPriceCreateForm(price, px) {
    removeDrawBanner();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    const priceText = Number(price).toLocaleString();
    banner.innerHTML = `<span class="step">✓</span>` +
      `<span class="pricechip">${priceText}원 <span class="dir pending">판정 중</span></span>` +
      `<input type="text" id="kta-pricecreate-memo" placeholder="비고(선택) · 엔터로 저장" autocomplete="off" disabled/>` +
      `<span class="save" data-act="save">저장</span>` +
      `<span class="cancel" data-act="delete" title="방금 만든 알람을 지웁니다">삭제</span>` +
      `<span class="cancel" data-act="close" title="닫기 · 알람은 그대로 유지됩니다">✕</span>`;
    document.body.appendChild(banner);
    positionBannerAt(banner, px);

    let createdId = null;
    const onCreated = ev => {
      if (_priceCreateListener === onCreated) { window.removeEventListener('kta-price-created', onCreated); _priceCreateListener = null; }
      const d = ev.detail || {};
      if (!d.ok) {
        finishPickCleanup();
        showPickRejectToast(px, '⚠️ 현재가와 같은 가격이에요 · 조금 위나 아래를 클릭해주세요');
        return;
      }
      createdId = d.id;
      const dirEl = banner.querySelector('.pricechip .dir');
      dirEl.classList.remove('pending');
      dirEl.classList.add(d.dir === 'above' ? 'above' : 'below');
      dirEl.textContent = d.dir === 'above' ? '↑ 이상' : '↓ 이하';
      const input = banner.querySelector('#kta-pricecreate-memo');
      input.disabled = false;
      setTimeout(() => input.focus(), 30);
    };
    if (_priceCreateListener) window.removeEventListener('kta-price-created', _priceCreateListener);
    _priceCreateListener = onCreated;
    window.addEventListener('kta-price-created', onCreated);

    const input = banner.querySelector('#kta-pricecreate-memo');
    const submit = () => {
      if (!createdId) return;
      window.dispatchEvent(new CustomEvent('kta-update-memo', { detail: { id: createdId, memo: input.value.trim() } }));
      finishPickCleanup();
    };
    input.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); submit(); } });
    banner.querySelector('[data-act="save"]').addEventListener('click', submit);
    banner.querySelector('[data-act="delete"]').addEventListener('click', () => {
      if (createdId) window.dispatchEvent(new CustomEvent('kta-alarm-delete', { detail: { id: createdId } }));
      finishPickCleanup();
    });
    banner.querySelector('[data-act="close"]').addEventListener('click', () => finishPickCleanup());
  }

  function finishTrendPick(a1, a2, px1, px2) {
    let scale = 'linear';
    let tf = null;
    try {
      const mode = _chart.getSeries().priceScale().getMode();
      scale = mode === 1 ? 'log' : 'linear';
    } catch (e) {}
    try { tf = _chart.resolution(); } catch (e) {}
    const editId = _pickEditId;

    // 좌표는 확정됐으니 크로스헤어/클릭 리스너는 이제 필요 없음. Esc 취소는 폼 단계에서도 계속 유효해야 하므로 남겨둠.
    releasePickListeners();
    _pickStep = 0;
    _magnetHit = null;
    _inDeadZone = false;
    removeMagnetPreview();

    const mid = (px1 && px2) ? { x: (px1.x + px2.x) / 2, y: (px1.y + px2.y) / 2 } : null;

    if (editId) {
      // 좌표 재설정(기존 알람 수정) — 메모/조건 다시 안 묻고 바로 저장, 짧은 완료 피드백만.
      window.dispatchEvent(new CustomEvent('kta-trend-quick-save', { detail: { a1, a2, scale, tf, editId } }));
      showDrawDone(mid);
      return;
    }
    showDrawConfirmForm(a1, a2, scale, tf, mid);
  }

  function handleTrendPickEscape(e) {
    if (!_picking) return;
    if (e.key === 'Escape' || e.keyCode === 27) stopTrendPick();
  }

  function injectDrawBannerStyleOnce() {
    if (document.getElementById('kta-draw-banner-style')) return;
    const style = document.createElement('style');
    style.id = 'kta-draw-banner-style';
    style.textContent = `
#kta-draw-banner{position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;
  display:flex;align-items:center;gap:10px;background:linear-gradient(180deg,#2451c9,#003597);
  color:#fff;padding:9px 16px;border-radius:12px;font:700 13px/1.4 'Pretendard',system-ui,sans-serif;
  box-shadow:0 14px 30px -10px rgba(0,53,151,.6), inset 0 1px 0 rgba(255,255,255,.28);white-space:nowrap;}
/* [2026-08-23] 안내배너를 끌어서 옮길 수 있음을 알려주는 커서 — 드래그 로직이 붙는 step 배너에만 부여. */
#kta-draw-banner.draggable{cursor:grab;user-select:none;}
#kta-draw-banner.draggable:active{cursor:grabbing;}
#kta-draw-banner .step{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;
  border-radius:50%;background:rgba(255,255,255,.22);font-size:12px;flex:none;}
#kta-draw-banner .cancel{cursor:pointer;margin-left:6px;opacity:.85;font-weight:800;}
#kta-draw-banner .cancel:hover{opacity:1;}
#kta-draw-banner .magnet-toggle{cursor:pointer;display:flex;align-items:center;justify-content:center;
  width:22px;height:22px;border-radius:7px;opacity:.55;flex:none;background:rgba(255,255,255,.12);}
#kta-draw-banner .magnet-toggle:hover{opacity:.8;}
#kta-draw-banner .magnet-toggle.on{opacity:1;background:rgba(255,255,255,.28);box-shadow:inset 0 1px 0 rgba(255,255,255,.3);}
#kta-draw-banner input{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.3);border-radius:8px;
  color:#fff;padding:5px 9px;font:600 12.5px 'Pretendard',system-ui,sans-serif;outline:none;width:160px;}
#kta-draw-banner input::placeholder{color:rgba(255,255,255,.65);}
#kta-draw-banner input:focus{border-color:#fff;background:rgba(255,255,255,.22);}
#kta-draw-banner .save{cursor:pointer;font-weight:800;background:rgba(255,255,255,.2);padding:4px 10px;border-radius:7px;}
#kta-draw-banner .save:hover{background:rgba(255,255,255,.3);}
/* [2026-08-23] 가격 알람 차트클릭 생성 — 오푸스 설계 시안(kalert_price_click_mockup.html) 값 그대로. */
#kta-draw-banner .pricechip{display:inline-flex;align-items:center;gap:6px;
  background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.28);border-radius:8px;
  padding:4px 9px;font:800 12.5px 'Pretendard',system-ui,sans-serif;color:#fff;letter-spacing:-.2px;flex:none;}
#kta-draw-banner .pricechip .dir{font-size:11px;font-weight:900;padding:1px 6px;border-radius:5px;line-height:1.45;}
#kta-draw-banner .pricechip .dir.above{background:#ef5350;color:#fff;}
#kta-draw-banner .pricechip .dir.below{background:#26a69a;color:#fff;}
#kta-draw-banner .pricechip .dir.pending{background:rgba(255,255,255,.25);color:rgba(255,255,255,.9);}
#kta-draw-banner .linkish{cursor:pointer;opacity:.8;font-weight:700;font-size:12px;text-decoration:underline;text-underline-offset:2px;}
#kta-draw-banner .linkish:hover{opacity:1;}
/* [2026-08-25] 온차트 더블클릭 편집 배너 2행 — 추세선은 연장/축/반복 3개, 가격은 반복 1개.
   (예전 클래스명 .qe-trend에서 개명 — 이제 가격 알람도 2행을 쓰기 때문) */
#kta-draw-banner.qe-stack{flex-direction:column;align-items:stretch;gap:8px;}
#kta-draw-banner .qe-row{display:flex;align-items:center;gap:10px;white-space:nowrap;}
#kta-draw-banner .qe-opts{gap:12px;}
#kta-draw-banner .qe-opt{display:inline-flex;align-items:center;gap:5px;}
#kta-draw-banner .qe-lab{font:800 11px 'Pretendard',system-ui,sans-serif;opacity:.72;letter-spacing:-.2px;}
#kta-draw-banner .qe-sel{appearance:none;-webkit-appearance:none;
  background-color:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.3);border-radius:8px;
  color:#fff;padding:4px 22px 4px 9px;font:700 12px 'Pretendard',system-ui,sans-serif;
  outline:none;cursor:pointer;transition:border-color .18s,background-color .18s;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='3' stroke-linecap='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 7px center;background-size:9px;}
#kta-draw-banner .qe-sel:hover{background-color:rgba(255,255,255,.2);}
#kta-draw-banner .qe-sel:focus{border-color:#fff;background-color:rgba(255,255,255,.22);}
/* 드롭다운 목록은 OS 네이티브 렌더라 배너 그라디언트가 안 먹는다 — 흰 배경으로 안 튀게 명시 지정. */
#kta-draw-banner .qe-sel option{background:#0b2a6b;color:#fff;}
`;
    document.head.appendChild(style);
  }

  function showDrawBanner(step, opts) {
    removeDrawBanner();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    banner.classList.add('draggable');
    const msg = (opts && opts.msg) ? opts.msg : (step === 1 ? '차트에서 첫 번째 지점을 클릭하세요' : '두 번째 지점을 클릭하세요');
    const magnetOn = !!lineSettings.magnetEnabled;
    const magnetTitle = magnetOn ? '자석 켜짐 · 클릭해서 끄기' : '자석 꺼짐 · 클릭해서 켜기';
    // [2026-08-23] 가격알람 차트클릭 생성 진입 배너에만 "직접 입력" 탈출구 링크 — 기존 팝업
    // 숫자입력 흐름으로 빠지고 싶을 때(오푸스 설계 시안 그대로).
    const linkHTML = (opts && opts.linkText) ? `<span class="linkish">${opts.linkText}</span>` : '';
    banner.innerHTML = `<span class="step">${step}</span><span>${msg}</span>` +
      `<span class="magnet-toggle${magnetOn ? ' on' : ''}" title="${magnetTitle}">${ICO_MAGNET}</span>` +
      linkHTML +
      `<span class="cancel">✕ 취소(Esc)</span>`;
    document.body.appendChild(banner);
    if (lineSettings.pickBannerPos) positionBannerAt(banner, lineSettings.pickBannerPos);
    banner.querySelector('.cancel').addEventListener('click', () => stopTrendPick());
    banner.querySelector('.magnet-toggle').addEventListener('click', e => {
      e.stopPropagation();
      lineSettings.magnetEnabled = !lineSettings.magnetEnabled;
      saveChartSettings();
      if (!lineSettings.magnetEnabled) { _magnetHit = null; removeMagnetPreview(); }
      showDrawBanner(step, opts); // 상태만 갱신해서 다시 그림(위치는 pickBannerPos로 유지됨, opts도 그대로 전달)
    });
    if (opts && opts.linkText && opts.onLink) {
      banner.querySelector('.linkish').addEventListener('click', e => {
        e.stopPropagation();
        opts.onLink();
      });
    }
    makeBannerDraggable(banner);
  }

  // 안내배너를 마우스로 끌어서 옮길 수 있게 함 — 놓은 자리를 lineSettings.pickBannerPos로 저장해서
  // 다음번 픽 시작 때도 그 자리에서 뜨게 한다. 클릭(취소버튼)과 드래그를 구분하려고 이동거리 임계값을 둠.
  function makeBannerDraggable(banner) {
    let dragging = false, moved = false, startX = 0, startY = 0, origLeft = 0, origTop = 0, w = 0, h = 0;
    const onDown = e => {
      if (e.target.closest('.cancel') || e.target.closest('.save') || e.target.closest('.magnet-toggle') || e.target.closest('.linkish') || e.target.tagName === 'INPUT') return;
      const rect = banner.getBoundingClientRect();
      dragging = true; moved = false;
      startX = e.clientX; startY = e.clientY;
      origLeft = rect.left; origTop = rect.top; w = rect.width; h = rect.height;
      e.preventDefault();
    };
    const onMove = e => {
      if (!dragging) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (!moved && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) moved = true;
      if (!moved) return;
      banner.style.left = (origLeft + dx + w / 2) + 'px';
      banner.style.top = (origTop + dy + h / 2) + 'px';
      banner.style.transform = 'translate(-50%, -50%)';
    };
    const onUp = () => {
      if (dragging && moved) {
        const rect = banner.getBoundingClientRect();
        lineSettings.pickBannerPos = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
        saveChartSettings();
      }
      dragging = false;
    };
    banner.addEventListener('mousedown', onDown);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    banner._dragCleanup = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  }

  // 배너를 화면상 임의 좌표(찍은 두 지점의 중간)에 앉힘 — 기본값(top:16px 가운데)을 인라인 스타일로 덮어씀.
  // 배너 크기를 아직 모르니 대략치로 clamp해서 화면 밖으로 안 나가게만 방어.
  // measure=true면 어림값(halfW/halfH) 대신 실제 렌더된 크기로 다시 클램프한다 — 추세선 배너가
  // 2줄로 늘어나면 어림값(150×24)보다 커져서 화면 오른쪽/아래 가장자리에서 잘릴 수 있어서(오푸스 설계).
  function positionBannerAt(banner, mid, measure) {
    if (!mid) return;
    const halfW = 150, halfH = 24, pad = 10;
    const x = Math.min(Math.max(mid.x, halfW + pad), window.innerWidth - halfW - pad);
    const y = Math.min(Math.max(mid.y, halfH + pad), window.innerHeight - halfH - pad);
    banner.style.left = x + 'px';
    banner.style.top = y + 'px';
    banner.style.transform = 'translate(-50%, -50%)';
    if (measure) {
      const r = banner.getBoundingClientRect();
      const rHalfW = r.width / 2, rHalfH = r.height / 2;
      const rx = Math.min(Math.max(mid.x, rHalfW + pad), window.innerWidth - rHalfW - pad);
      const ry = Math.min(Math.max(mid.y, rHalfH + pad), window.innerHeight - rHalfH - pad);
      banner.style.left = rx + 'px';
      banner.style.top = ry + 'px';
    }
  }

  // 좌표 2개 확정 직후(신규 생성) — 배너를 메모입력 미니폼으로 전환. 엔터/추가버튼으로 즉시 저장.
  function showDrawConfirmForm(a1, a2, scale, tf, mid) {
    removeDrawBanner();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    banner.innerHTML = `<span class="step">✓</span><input type="text" id="kta-draw-memo" placeholder="비고(선택) · 엔터로 저장" autocomplete="off"/><span class="save">추가</span><span class="cancel">✕ 취소(Esc)</span>`;
    document.body.appendChild(banner);
    positionBannerAt(banner, mid);
    const input = banner.querySelector('#kta-draw-memo');
    const submit = () => {
      const memo = input.value.trim();
      window.dispatchEvent(new CustomEvent('kta-trend-quick-save', { detail: { a1, a2, scale, tf, memo } }));
      finishPickCleanup();
    };
    input.addEventListener('keydown', ev => {
      if (ev.key === 'Enter') { ev.preventDefault(); submit(); }
    });
    banner.querySelector('.save').addEventListener('click', submit);
    banner.querySelector('.cancel').addEventListener('click', () => stopTrendPick());
    setTimeout(() => input.focus(), 30);
  }

  // 시작 자체를 막을 때(예: 1초봉) 보여주는 경고 배너 — 짧게 보여주고 자동으로 사라짐.
  function showDrawBlocked(msg) {
    removeDrawBanner();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    banner.innerHTML = `<span class="step">⚠️</span><span>${msg}</span>`;
    document.body.appendChild(banner);
    setTimeout(() => banner.remove(), 2400);
  }

  // 좌표 재설정(수정) 저장 완료 — 짧게 보여주고 자동으로 사라짐.
  function showDrawDone(mid) {
    finishPickCleanup();
    const banner = document.createElement('div');
    banner.id = 'kta-draw-banner';
    banner.innerHTML = `<span class="step">✓</span><span>좌표가 적용됐어요</span>`;
    document.body.appendChild(banner);
    positionBannerAt(banner, mid);
    setTimeout(() => banner.remove(), 1200);
  }

  function removeDrawBanner() {
    const banner = document.getElementById('kta-draw-banner');
    if (banner) { banner._dragCleanup?.(); banner.remove(); }
  }

  window.addEventListener('kta-start-trend-pick', e => startTrendPick(e && e.detail && e.detail.editId));
  window.addEventListener('kta-start-price-pick', e => startPriceAlarmPick(e && e.detail && e.detail.editId));

  window.addEventListener('kta-alarms', e => {
    const alarms = e.detail || [];
    latestAlarms = alarms;
    syncFab();
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  });

  function saveChartSettings() {
    window.dispatchEvent(new CustomEvent('kta-save-line-settings', { detail: { ...lineSettings, panelTheme } }));
  }

  window.addEventListener('kta-line-settings', e => {
    const d = e.detail || {};
    Object.assign(lineSettings, d);
    if (d.panelTheme) panelTheme = d.panelTheme;
  });

  window.addEventListener('kta-alarm-settings', e => { alarmSettings = e.detail || {}; });

  // popup.js reactivateLabel과 문구를 반드시 똑같이 맞춘다(형이 두 화면에서 다른 문구를 보면 혼란).
  function reactivateLabel() {
    switch (alarmSettings.reactivate) {
      case 'instant': return '즉시';
      case '30min': return '30분 후';
      case '1hour': return '1시간 후';
      case 'custom': return `${alarmSettings.reactivateMinutes || 60}분 후`;
      default: return null; // 아직 캐시가 안 채워졌으면 괄호 없이 표시(합격기준 참고)
    }
  }

  window.addEventListener('kta-update-memo', e => {
    const { id, memo } = e.detail || {};
    const idx = latestAlarms.findIndex(a => a.id === id);
    if (idx >= 0) latestAlarms[idx].memo = memo;
    const entry = _shapeMap.get(id);
    if (entry) {
      try { _chart?.removeEntity(entry.eid); } catch(e) {}
      _shapeMap.delete(id);
    }
    drawTVLines();
  });

  // [2026-08-25] 온차트 배너의 연장/축/반복 즉시 낙관적 갱신. extend/scale은 trendSig(524줄 근처)에
  // 이미 포함돼있어서 latestAlarms만 고쳐두면 drawTVLines가 시그니처 불일치를 감지해 알아서
  // removeEntity 후 새 좌표로 다시 그린다 — kta-update-memo처럼 수동으로 지울 필요 없음.
  // repeat은 그리기와 무관해서(재렌더해도 모양 그대로) latestAlarms만 갱신하고 재렌더는 생략.
  // content.js의 저장이 실패해도 ~storage echo(kta-alarms) 재도착 때 원래 값으로 되돌아와 자가복구된다.
  window.addEventListener('kta-trend-edit-opt', e => {
    const { id, field, value } = e.detail || {};
    if (!['extend', 'scale', 'repeat'].includes(field)) return;
    const a = latestAlarms.find(x => x.id === id);
    if (!a) return;
    a[field] = value;
    if (field === 'extend' || field === 'scale') drawTVLines();
  });
})();

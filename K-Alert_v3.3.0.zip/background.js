importScripts("kta_report_secret.js");importScripts("kta_storage_keys.js");const CURRENT_VERSION=(()=>{try{return chrome.runtime.getManifest().version||""}catch(t){return""}})()
;const HISTORY_KEYS_ALL=self.KTA_KEYS.HISTORY_KEYS_ALL;const SETTINGS_KEY="upbit_alarm_settings_v1";const PUSH_COOLDOWN_KEY="kta_push_cooldown_v1";const NAV_STATS_KEY="kta_nav_stats_v1"
;const VERSION_CHECK_URL="https://alert.krisb-infra.com/version.json";const UPDATE_PAGE_URL="https://alert.krisb-infra.com/";const UPDATE_CHECKED_AT_KEY="kta_update_checked_at_v1"
;const UPDATE_MIN_INTERVAL_MS=60*1e3;function updateBadge(){chrome.storage.local.get(HISTORY_KEYS_ALL.concat(["pendingUpdate"]),t=>{const e=self.KTA_KEYS.HISTORY_KEYS.upbit
;const n=self.KTA_KEYS.HISTORY_KEYS.bithumb;const a=e=>(t[e]||[]).filter(t=>t.unread).length;let o=a(e)+a(n);const r=t[self.KTA_KEYS.HISTORY_KEY_LEGACY]||[]
;if(t[e]===undefined)o+=r.filter(t=>t.unread&&t.exchange!=="bithumb").length;if(t[n]===undefined)o+=r.filter(t=>t.unread&&t.exchange==="bithumb").length;if(o>0){chrome.action.setBadgeText({
text:String(o)});chrome.action.setBadgeBackgroundColor({color:"#ef5350"})}else if(t.pendingUpdate){chrome.action.setBadgeText({text:"UP"});chrome.action.setBadgeBackgroundColor({color:"#ef5350"})
}else{chrome.action.setBadgeText({text:""})}})}function isNewerVersion(t,e){const n=String(t).split(".").map(t=>parseInt(t,10)||0);const a=String(e).split(".").map(t=>parseInt(t,10)||0)
;const o=Math.max(n.length,a.length);for(let t=0;t<o;t++){const e=n[t]||0,o=a[t]||0;if(e>o)return true;if(e<o)return false}return false}let _updateCheckInFlight=null;function checkForUpdate(t){
const e=t||{};const n=e.force?0:typeof e.minInterval==="number"?e.minInterval:UPDATE_MIN_INTERVAL_MS;if(_updateCheckInFlight)return _updateCheckInFlight;const a=(async()=>{if(n>0){let t=0;try{
const e=await chrome.storage.local.get(UPDATE_CHECKED_AT_KEY);t=e[UPDATE_CHECKED_AT_KEY]||0}catch(t){}if(t&&Date.now()-t<n)return{ok:true,skipped:true}}try{
const t=await fetch(VERSION_CHECK_URL+"?t="+Date.now(),{cache:"no-store"});if(!t.ok)throw new Error("http_"+t.status);const e=await t.json();const n=e.version||"0";await chrome.storage.local.set({
[UPDATE_CHECKED_AT_KEY]:Date.now()});if(CURRENT_VERSION&&isNewerVersion(n,CURRENT_VERSION)){await chrome.storage.local.set({pendingUpdate:{version:n,page:e.page||UPDATE_PAGE_URL,
changelog:e.changelog||""}})}else{await chrome.storage.local.remove("pendingUpdate")}updateBadge();return{ok:true,latest:n,current:CURRENT_VERSION}}catch(t){return{ok:false,
error:String(t&&t.message||t)}}})();_updateCheckInFlight=a;a.then(()=>{_updateCheckInFlight=null},()=>{_updateCheckInFlight=null});return a}chrome.storage.onChanged.addListener((t,e)=>{
if(e!=="local")return;if(HISTORY_KEYS_ALL.some(e=>t[e])||t["pendingUpdate"])updateBadge()});const UPBIT_URLS=[{urlPrefix:"https://upbit.com/"},{urlPrefix:"https://www.upbit.com/"}]
;const BITHUMB_URLS=[{urlPrefix:"https://www.bithumb.com/"}];const REPORT_HELPER_FILES=["kta_storage_keys.js","kta_dom_probes.js","kta_report_client.js"];const PING_TIMEOUT_MS=500
;function injectTab(t,e){let n=false;const a=()=>{if(n)return;n=true;chrome.scripting.executeScript({target:{tabId:t},files:REPORT_HELPER_FILES.concat([e])}).catch(()=>{})}
;setTimeout(a,PING_TIMEOUT_MS);try{chrome.tabs.sendMessage(t,{action:"ktaPing",script:e},t=>{const o=chrome.runtime.lastError;if(!o&&t&&t.ok===true&&t.script===e){n=true;return}a()})}catch(t){a()}}
const REPORT_URL="https://auth.krisb-infra.com/report";const REPORT_SECRET=self.KTA_REPORT_SECRET;async function sendErrorReport(t){const e=await fetch(REPORT_URL,{method:"POST",headers:{
"Content-Type":"application/json","x-kmemo-secret":REPORT_SECRET},body:JSON.stringify(t)});let n=null;try{n=await e.json()}catch(t){n=null}const a=e.ok&&!!(n&&n.ok);chrome.storage.local.set({
kt_report_last_v1:{ts:Date.now(),ok:a,id:n&&n.id||"",code:t&&t.code||""}});return{ok:a,id:n&&n.id}}function injectAllTabs(){chrome.tabs.query({url:["https://upbit.com/*","https://www.upbit.com/*"]
},t=>{(t||[]).forEach(t=>injectTab(t.id,"content.js"))});chrome.tabs.query({url:["https://www.bithumb.com/*"]},t=>{(t||[]).forEach(t=>injectTab(t.id,"content.js"))})}
chrome.webNavigation.onCompleted.addListener(t=>{if(t.frameId===0)injectTab(t.tabId,"content.js")},{url:UPBIT_URLS});chrome.webNavigation.onCompleted.addListener(t=>{
if(t.frameId===0)injectTab(t.tabId,"content.js")},{url:BITHUMB_URLS});chrome.runtime.onStartup.addListener(()=>{injectAllTabs();checkForUpdate({force:true})})
;chrome.runtime.onInstalled.addListener(()=>{injectAllTabs();checkForUpdate({force:true})});chrome.tabs.onActivated.addListener(({tabId:t})=>{chrome.tabs.get(t,e=>{if(!e.url)return
;if(e.url.startsWith("https://upbit.com/")||e.url.startsWith("https://www.upbit.com/")){injectTab(t,"content.js")}else if(e.url.startsWith("https://www.bithumb.com/")){injectTab(t,"content.js")}})})
;const _inFlight=new Map;function cacheGet(t){return new Promise(e=>{try{chrome.storage.session.get(t,n=>e(n[t]||null))}catch(t){e(null)}})}function cacheSet(t,e){try{chrome.storage.session.set({[t]:e
})}catch(t){}}async function cachedFetch(t,e,n){const a=await cacheGet(t);if(a&&Date.now()-a.ts<e)return a.data;if(_inFlight.has(t))return _inFlight.get(t);const o=(async()=>{const a=await cacheGet(t)
;if(a&&Date.now()-a.ts<e)return a.data;const o=await n();cacheSet(t,{ts:Date.now(),data:o});return o})();_inFlight.set(t,o);try{return await o}finally{_inFlight.delete(t)}}const CANDLE_BUCKET={
tokens:8,max:8,refillPerSec:4,lastRefill:Date.now()};let candleBackoffUntil=0;let candleBackoffMs=0;let candleSuccessStreak=0;function refillCandleBucket(){const t=Date.now()
;CANDLE_BUCKET.tokens=Math.min(CANDLE_BUCKET.max,CANDLE_BUCKET.tokens+(t-CANDLE_BUCKET.lastRefill)/1e3*CANDLE_BUCKET.refillPerSec);CANDLE_BUCKET.lastRefill=t}function takeCandleToken(){
refillCandleBucket();if(CANDLE_BUCKET.tokens>=1){CANDLE_BUCKET.tokens-=1;return true}return false}function onCandleSuccess(){candleSuccessStreak++;if(candleBackoffMs>0&&candleSuccessStreak>=2){
candleBackoffMs=0;candleBackoffUntil=0}}function onCandle429(){candleSuccessStreak=0;candleBackoffMs=candleBackoffMs?Math.min(candleBackoffMs*2,12e4):5e3;candleBackoffUntil=Date.now()+candleBackoffMs}
function rateLimitedError(t){return Object.assign(new Error("rate_limited"),{rateLimited:true,retryAfter:t})}function apiHost(t){return t==="bithumb"?"https://api.bithumb.com":"https://api.upbit.com"}
function candlePath(t){if(t==="1D")return"days";if(t==="1W")return"weeks";if(t==="1M")return"months";if(t==="12M")return"years";if(t==="1S")return"seconds";return`minutes/${t}`}
async function fetchCandlesInternal(t,e,n,a,o){if(Date.now()<candleBackoffUntil)throw rateLimitedError(candleBackoffUntil);if(!takeCandleToken())throw rateLimitedError(Date.now()+250)
;let r=`${apiHost(o)}/v1/candles/${candlePath(e)}?market=${t}&count=${n}`;if(a)r+=`&to=${encodeURIComponent(a)}`;const s=await fetch(r);if(s.status===429){onCandle429()
;throw rateLimitedError(candleBackoffUntil)}if(!s.ok)throw new Error("http_"+s.status);const c=await s.json();onCandleSuccess();return c}
const OKX_INST_URL="https://www.okx.com/api/v5/public/instruments";let _okxFailUntil=0;async function okxTickInternal(t){if(Date.now()<_okxFailUntil)throw new Error("okx_backoff")
;const e=async(t,e)=>{const n=new AbortController;const a=setTimeout(()=>n.abort(),6e3);try{const a=await fetch(`${OKX_INST_URL}?instType=${t}&instId=${encodeURIComponent(e)}`,{cache:"no-store",
credentials:"omit",signal:n.signal});if(!a.ok)throw new Error("okx_http_"+a.status);const o=await a.json();const r=o&&Array.isArray(o.data)?o.data[0]:null;const s=r?parseFloat(r.tickSz):NaN
;return s>0&&Number.isFinite(s)?s:null}finally{clearTimeout(a)}};try{let n=`${t}-USDT-SWAP`;let a=await e("SWAP",n);if(!a){n=`${t}-USDT`;a=await e("SPOT",n)}return a?{tick:a,inst:n}:{tick:null,
inst:null}}catch(t){_okxFailUntil=Date.now()+12e4;throw t}}async function usdtKrwInternal(){const t=await fetch("https://api.upbit.com/v1/ticker?markets=KRW-USDT",{cache:"no-store"})
;if(!t.ok)throw new Error("fx_http_"+t.status);const e=await t.json();const n=e&&e[0]?Number(e[0].trade_price):NaN;if(!(n>0))throw new Error("fx_bad");return n}
const OKX_CANDLE_BARS=new Set(["1m","3m","5m","15m","30m","1H","2H","4H","6Hutc","12Hutc","1Dutc","1Wutc","1Mutc"]);const OKX_CANDLE_MAX=3e3;const _okxCandles=new Map;const _okxCandleBusy=new Map
;let _okxCandleFailUntil=0;async function okxGetJson(t){const e=new AbortController;const n=setTimeout(()=>e.abort(),8e3);try{const n=await fetch(t,{cache:"no-store",credentials:"omit",signal:e.signal
});if(!n.ok)throw new Error("okx_http_"+n.status);return await n.json()}finally{clearTimeout(n)}}function okxRowsInto(t,e){let n=0;for(const a of e||[]){if(!Array.isArray(a)||a.length<8)continue
;const e=Number(a[0]),o=[e/1e3,+a[1],+a[2],+a[3],+a[4],+a[5],+a[7]];if(!Number.isFinite(e)||!o.every(Number.isFinite))continue;t.rows.set(e,o);n++;if(!(t.oldestMs<=e))t.oldestMs=e}return n}
async function okxCandlesInternal(t,e,n){const a=`${t}-USDT-SWAP`,o=a+"|"+e;let r=_okxCandles.get(o);if(!r){r={rows:new Map,recentAt:0,oldestMs:Infinity,noOlder:false};_okxCandles.set(o,r)
;while(_okxCandles.size>12)_okxCandles.delete(_okxCandles.keys().next().value)}const s="https://www.okx.com/api/v5/market/";if(Date.now()-r.recentAt>15e3){
const t=await okxGetJson(`${s}candles?instId=${encodeURIComponent(a)}&bar=${e}&limit=300`);if(!t||t.code!=="0"||!Array.isArray(t.data)||!t.data.length){
if(t&&(t.code==="51001"||t.code==="0"&&Array.isArray(t.data)&&!t.data.length))return{ok:false,listed:false,why:"no_swap"};throw new Error("okx_bad_"+(t&&t.code))}okxRowsInto(r,t.data)
;r.recentAt=Date.now()}let c=0;while(!r.noOlder&&r.oldestMs>n*1e3&&c<30&&r.rows.size<OKX_CANDLE_MAX+400){await new Promise(t=>setTimeout(t,120))
;const t=await okxGetJson(`${s}history-candles?instId=${encodeURIComponent(a)}&bar=${e}&after=${r.oldestMs}&limit=100`)
;if(!t||t.code!=="0"||!Array.isArray(t.data))throw new Error("okx_bad_"+(t&&t.code));if(!okxRowsInto(r,t.data))r.noOlder=true;c++}if(!r.noOlder&&r.oldestMs>n*1e3)return{ok:false,why:"too_many_bars"}
;const i=[...r.rows.values()].sort((t,e)=>t[0]-e[0]);const l=i.filter(t=>t[0]>=n);if(l.length>OKX_CANDLE_MAX)return{ok:false,why:"too_many_bars"};return{ok:true,rows:l,
lastClose:i.length?i[i.length-1][4]:null,from:n}}chrome.runtime.onMessage.addListener((t,e,n)=>{if(t&&t.action==="okxCandles"){
const e=typeof t.sym==="string"&&/^[A-Z0-9]{1,15}$/.test(t.sym)?t.sym:null;const a=typeof t.bar==="string"&&OKX_CANDLE_BARS.has(t.bar)?t.bar:null;const o=Number(t.from)
;if(!e||!a||!Number.isInteger(o)||o<1e9||o>4e9){n({ok:false,why:"bad_req"});return}if(Date.now()<_okxCandleFailUntil){n({ok:false,why:"okx_backoff"});return}const r=`${e}|${a}|${o}`
;let s=_okxCandleBusy.get(r);if(!s){s=okxCandlesInternal(e,a,o).catch(()=>{_okxCandleFailUntil=Date.now()+6e4;return{ok:false,why:"okx_fail"}});_okxCandleBusy.set(r,s)
;s.finally(()=>_okxCandleBusy.delete(r))}s.then(t=>n(t));return true}if(t&&t.action==="okxTick"){const e=typeof t.sym==="string"&&/^[A-Z0-9]{1,15}$/.test(t.sym)?t.sym:null;if(!e){n({ok:false,
why:"bad_sym"});return}(async()=>{let t;try{t=await cachedFetch(`kta_cache_okxtick:${e}`,864e5,()=>okxTickInternal(e))}catch(t){n({ok:false,why:"okx_fail"});return}if(!t||!t.tick){n({ok:false,
listed:false,why:"not_listed"});return}let a;try{a=await cachedFetch("kta_cache_usdtkrw",3e5,usdtKrwInternal)}catch(t){n({ok:false,why:"fx_fail"});return}n({ok:true,tickUsdt:t.tick,usdtKrw:a,
inst:t.inst})})();return true}if(t&&t.action==="ktaReport"){sendErrorReport(t.payload||{}).then(n).catch(e=>{chrome.storage.local.set({kt_report_last_v1:{ts:Date.now(),ok:false,id:"",
code:t.payload&&t.payload.code||""}});n({ok:false,error:String(e&&e.message||e)})});return true}if(t&&t.action==="ktaNavStat"){const e=t.exchange==="bithumb"?"bithumb":"upbit"
;const n=String(t.result||"unknown").slice(0,32);chrome.storage.local.get(NAV_STATS_KEY,t=>{const a=t[NAV_STATS_KEY]||{since:Date.now(),upbit:{},bithumb:{}};if(!a.upbit)a.upbit={}
;if(!a.bithumb)a.bithumb={};if(!a.since)a.since=Date.now();a[e][n]=(a[e][n]||0)+1;chrome.storage.local.set({[NAV_STATS_KEY]:a})});return}if(t.action==="checkForUpdate"){checkForUpdate({
force:!!t.force,minInterval:t.minInterval}).then(t=>n(t||{ok:false})).catch(()=>n({ok:false}));return true}if(t.action==="fetchCandles"&&t.market&&t.tf){
const e=Math.min(200,Math.max(1,parseInt(t.count)||2));const a=t.to||"";const o=Math.max(1e3,t.maxAgeMs||15e3);const r=t.exchange==="bithumb"?"bithumb":"upbit"
;const s=`kta_cache_candle:${r}:${t.market}:${t.tf}:${e}:${a}`;cachedFetch(s,o,()=>fetchCandlesInternal(t.market,t.tf,e,a,r)).then(t=>n({ok:true,candles:t})).catch(t=>n({ok:false,error:t.message,
rateLimited:!!t.rateLimited,retryAfter:t.retryAfter||0}));return true}if(t.action==="fetchPrices"&&t.codes&&t.codes.length){
fetch(`${apiHost(t.exchange)}/v1/ticker?markets=${t.codes.join(",")}`).then(t=>t.json()).then(t=>{const e={};t.forEach(t=>{e[t.market]=t.trade_price});n({ok:true,prices:e})}).catch(t=>n({ok:false,
error:t.message}));return true}if(t.action==="fetchMarkets"){fetch("https://api.upbit.com/v1/market/all?isDetails=false").then(t=>t.json()).then(t=>{
const e=t.filter(t=>t.market.startsWith("KRW-")).map(t=>({code:t.market,sym:t.market.replace("KRW-",""),kor:t.korean_name,eng:t.english_name}));n({ok:true,markets:e})}).catch(t=>n({ok:false,
error:t.message}));return true}if(t.action==="quickAdd"){chrome.storage.local.set({quickAddSym:t.sym},()=>{chrome.action.openPopup().catch(()=>{})});return}if(t.action==="sendPush"){
chrome.storage.local.get([SETTINGS_KEY,PUSH_COOLDOWN_KEY],e=>{const a=e[SETTINGS_KEY]||{};if(!a.ntfyEnabled||!a.ntfyTopic){n({ok:false});return}const o=a.ntfyCooldown??30
;const r=e[PUSH_COOLDOWN_KEY]||{};const s=t.alarm;if(o>0&&Date.now()-(r[s.id]||0)<o*60*1e3){n({ok:false});return}r[s.id]=Date.now();chrome.storage.local.set({[PUSH_COOLDOWN_KEY]:r})
;const c=t.exchange==="bithumb"?"빗썸":"업비트";const i=s.dir==="above"?"이상":"이하"
;const l=`${s.label} ${Number(s.price).toLocaleString()}원 ${i} 도달!\n현재가: ${Number(t.currentPrice).toLocaleString()}원${s.memo?"\n메모: "+s.memo:""}`;fetch("https://ntfy.sh/",{method:"POST",headers:{
"Content-Type":"application/json"},body:JSON.stringify({topic:a.ntfyTopic,title:`🔔 ${c} 가격 알람`,message:l,priority:4,tags:["bell"]})}).then(()=>n({ok:true})).catch(t=>n({ok:false,error:t.message}))})
;return true}if(t.action==="ntfyTest"){fetch("https://ntfy.sh/",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic:t.topic,title:"🔔 Kris Trader Alarm 테스트",
message:"Push 알림이 정상 수신되었어요!",priority:4,tags:["bell"]})}).then(t=>n({ok:true,status:t.status})).catch(t=>n({ok:false,error:t.message}));return true}if(t.action==="fetchBithumbPrices"){
fetch("https://api.bithumb.com/public/ticker/ALL_KRW").then(t=>t.json()).then(t=>{const e={};if(t.status==="0000"){Object.entries(t.data).forEach(([t,n])=>{
if(t!=="date")e[t]=parseFloat(n.closing_price)})}n({ok:true,prices:e})}).catch(t=>n({ok:false,error:t.message}));return true}});
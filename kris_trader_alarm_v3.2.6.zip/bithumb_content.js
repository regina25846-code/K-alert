// ⚠️ [2026-09-04] 이 파일은 **은퇴했다.** 빗썸도 업비트와 같은 content.js 가 담당한다
//    (manifest.json 과 background.js 의 주입 대상이 전부 content.js 로 바뀌었다).
//    그래야 반복 3모드 · 봉 워터마크 · 추세선 · 온차트 알람선이 두 거래소에서 똑같이 돈다.
//    파일을 지우지 않고 남겨두는 이유: 포장/검사 스크립트들이 이 이름을 참조하고 있어서다.
//    혹시 놓친 경로가 이 파일을 주입하더라도 **두 개가 같이 돌아 알람이 두 번 울리는 일은 없도록**
//    맨 앞에서 스스로 빠진다(아래 한 줄).
(function () {
  'use strict';

  // content.js 가 이미 이 페이지에 있으면(세대 번호가 박혀 있으면) 이 파일은 아무것도 하지 않는다.
  if (window.__ktaGen) return;

  if (window.__btPollTimer) { clearInterval(window.__btPollTimer); window.__btPollTimer = null; }

  window.addEventListener('error', function (e) {
    if (e.message && e.message.includes('Extension context invalidated')) e.preventDefault();
  });

  const STORAGE_KEY = 'bithumb_alarms_v1';
  const SETTINGS_KEY = 'upbit_alarm_settings_v1';
  // [2026-09-04] 알람 기록 거래소별 분리 — content.js 의 같은 자리 주석 참고.
  const HISTORY_KEY = 'kta_alarm_history_bithumb_v1';
  const HISTORY_MAX = 50;
  const POLL_INTERVAL = 2000;

  let alarms = [];
  let currentSettings = { sound: 'fanfare', volume: 70, reactivate: 'custom', reactivateMinutes: 1 };

  function isCtxValid() {
    try { return !!chrome.runtime.id; } catch { return false; }
  }
  function isActive(a) { return !a.fired && !a.disabled; }

  // ── [2026-09-02] 오류 자동감지 신고 (kta_report_client.js / kta_dom_probes.js) — 기본 꺼짐, 팝업 토글로만 켜짐 ──
  // 빗썸 쪽 K-Alert 는 DOM 의존이 거의 없어(URL 심볼 파싱 + 가격 API) 프로브가 비어있고 드리프트 감시는 돌지 않는다.
  if (window.__ktaBtReporter) { try { window.__ktaBtReporter.stop(); } catch (e) {} window.__ktaBtReporter = null; }
  const REP = (function () {
    try {
      if (!window.__ktReport || !window.__ktProbes || !window.__ktProbes.bithumb) return null;
      const r = window.__ktReport.createReporter({
        product: 'kalert', exchange: 'bithumb',
        version: chrome.runtime.getManifest().version,
        probes: window.__ktProbes.bithumb.probes,
        skeletonRoots: window.__ktProbes.bithumb.skeletonRoots,
        isPageReady: () => location.pathname.includes('/trade/'),
        getMarket: () => { const m = location.pathname.match(/\/order\/([A-Z0-9]+-[A-Z]+)/i); return m ? m[1] : ''; },
        transport: payload => {
          try { chrome.runtime.sendMessage({ action: 'ktaReport', payload }, () => { void chrome.runtime.lastError; }); } catch (e) {}
        },
      });
      window.__ktaBtReporter = r;
      return r;
    } catch (e) { return null; }
  })();
  function rep(code, extra) { try { if (REP) REP.fail(code, extra || {}); } catch (e) {} }
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      // [2026-09-04] 생존 확인 핑 — background.js 의 injectTab 이 주입 전에 물어본다.
      // 이게 없으면 빗썸 탭은 매번 핑 타임아웃(500ms)을 기다렸다가 주입돼서 오히려 느려진다.
      if (msg && msg.action === 'ktaPing') {
        sendResponse && sendResponse({ ok: true, script: 'bithumb_content.js' });
        return;
      }
      if (msg && msg.action === 'ktaReportNow') {
        if (REP) { try { REP.manualReport(); } catch (e) {} }
        sendResponse && sendResponse({ ok: !!REP });
      }
    });
  } catch (e) {}

  function loadSettings() {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      currentSettings = { sound: 'fanfare', reactivate: 'custom', reactivateMinutes: 1, ...(data[SETTINGS_KEY] || {}) };
    });
  }

  function loadAlarms() {
    chrome.storage.local.get(STORAGE_KEY, data => {
      alarms = data[STORAGE_KEY] || [];
      if (alarms.some(isActive)) startPolling();
    });
  }

  function disableAlarm(id) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = true; a.fired = false; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function enableAlarm(id) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = false; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function getReactivateMs() {
    switch (currentSettings.reactivate) {
      case '30min': return 30 * 60 * 1000;
      case '1hour': return 60 * 60 * 1000;
      case 'custom': return Math.max(1, currentSettings.reactivateMinutes || 60) * 60 * 1000;
      default: return 0;
    }
  }

  function playAlarmSound() {
    if (currentSettings.sound === 'none') return;
    fetch(chrome.runtime.getURL(`sounds/${currentSettings.sound}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(currentSettings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
  }

  function fetchPrices() {
    if (!isCtxValid()) {
      if (window.__btPollTimer) { clearInterval(window.__btPollTimer); window.__btPollTimer = null; }
      return;
    }
    const syms = [...new Set(alarms.filter(isActive).map(a => a.sym))];
    if (!syms.length) {
      if (window.__btPollTimer) { clearInterval(window.__btPollTimer); window.__btPollTimer = null; }
      return;
    }
    try {
      chrome.runtime.sendMessage({ action: 'fetchBithumbPrices' }, res => {
        try {
          if (chrome.runtime.lastError || !res || !res.ok) return;
          syms.forEach(sym => {
            if (res.prices[sym] !== undefined) checkAlarms(sym, res.prices[sym]);
          });
        } catch {}
      });
    } catch {
      if (window.__btPollTimer) { clearInterval(window.__btPollTimer); window.__btPollTimer = null; }
    }
  }

  function startPolling() {
    if (window.__btPollTimer) clearInterval(window.__btPollTimer);
    fetchPrices();
    window.__btPollTimer = setInterval(fetchPrices, POLL_INTERVAL);
  }

  function checkAlarms(sym, price) {
    alarms.forEach(alarm => {
      if (!isActive(alarm) || alarm.sym !== sym) return;
      const triggered =
        (alarm.dir === 'above' && price >= alarm.price) ||
        (alarm.dir === 'below' && price <= alarm.price);
      if (triggered) {
        alarm.disabled = true;
        alarm.fired = false;
        disableAlarm(alarm.id);
        fireAlarm(alarm, price);
      }
    });
  }

  function showToast(msg, memo, url) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);
      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));
      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;
      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;
      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);
      transition:transform .35s cubic-bezier(.2,1,.4,1);
      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;
      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;
    `;
    const msgEl = document.createElement('div');
    msgEl.textContent = msg;
    toast.appendChild(msgEl);
    if (memo) {
      const memoEl = document.createElement('div');
      memoEl.textContent = memo;
      memoEl.style.cssText = 'margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;';
      toast.appendChild(memoEl);
    }
    document.body.appendChild(toast);
    requestAnimationFrame(() => { toast.style.transform = 'translateX(-50%) translateY(0)'; });
    const dismiss = () => {
      toast.style.transform = 'translateX(-50%) translateY(-80px)';
      setTimeout(() => toast.remove(), 400);
    };
    toast.addEventListener('click', () => {
      if (url) window.location.href = url;
      dismiss();
    });
    setTimeout(dismiss, 7000);
  }

  function saveAlarmHistory(alarm, currentPrice) {
    chrome.storage.local.get(HISTORY_KEY, data => {
      const history = data[HISTORY_KEY] || [];
      history.unshift({ id: Date.now(), exchange: 'bithumb', label: alarm.label, sym: alarm.sym, price: alarm.price, dir: alarm.dir, currentPrice, memo: alarm.memo || '', firedAt: Date.now(), unread: true });
      if (history.length > HISTORY_MAX) history.length = HISTORY_MAX;
      chrome.storage.local.set({ [HISTORY_KEY]: history });
    });
  }

  function fireAlarm(alarm, currentPrice) {
    saveAlarmHistory(alarm, currentPrice);
    if (isCtxValid()) chrome.runtime.sendMessage({ action: 'sendPush', alarm, currentPrice, exchange: 'bithumb' }, () => {});
    const dirText = alarm.dir === 'above' ? '이상' : '이하';
    const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(currentPrice).toLocaleString()}원`;
    const url = `https://www.bithumb.com/react/trade/order/${alarm.sym}-KRW`;
    showToast(`🔔 ${body}`, alarm.memo || '', url);
    if (Notification.permission === 'granted') {
      new Notification('🔔 빗썸 가격 알람', { body });
    }
    playAlarmSound();
    const delay = getReactivateMs();
    setTimeout(() => enableAlarm(alarm.id), delay);
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY]) {
      alarms = changes[STORAGE_KEY].newValue || [];
      if (alarms.some(isActive)) startPolling();
      else if (window.__btPollTimer) { clearInterval(window.__btPollTimer); window.__btPollTimer = null; }
    }
    if (changes[SETTINGS_KEY]) {
      currentSettings = { sound: 'fanfare', reactivate: 'custom', reactivateMinutes: 1, ...(changes[SETTINGS_KEY].newValue || {}) };
    }
  });

  if (Notification.permission === 'default') Notification.requestPermission();
  loadSettings();
  loadAlarms();

  // ── 빠른 추가 + 버튼 ──────────────────────────────────────────────
  function getBithumbSym() {
    const m = location.pathname.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i)
           || location.pathname.match(/\/react\/trade\/order\/([A-Z0-9]+)-KRW/i);
    return m ? m[1].toUpperCase() : null;
  }

  function injectQuickAddBtn(sym) {
    if (document.getElementById('kta-quick-add-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'kta-quick-add-btn';
    btn.textContent = '+';
    btn.title = `${sym} 알람 추가`;
    // 위치(bottom:80px / right:20px)는 그대로.
    // [2026-08-07] 색을 앱 accent(로즈) 고정에서 **거래소 색**으로 교체.
    // 이 파일은 빗썸 전용 content script라 빗썸 주황으로 고정한다.
    // 값은 시안(ktraderkey_kalert_mockup_artifact.html)의 --bt1/--bt2 다크셋 그대로.
    Object.assign(btn.style, {
      position: 'fixed', bottom: '80px', right: '20px',
      width: '46px', height: '46px', borderRadius: '50%',
      background: 'linear-gradient(160deg,#fb923c,#ea580c)', color: '#fff', fontSize: '21px',
      fontWeight: 'bold', border: 'none', cursor: 'pointer',
      zIndex: '999999',
      boxShadow: '0 10px 24px -6px #ea580c, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(251,146,60,.16)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'Pretendard',system-ui,sans-serif", transition: '.18s'
    });
    btn.addEventListener('click', () => {
      if (!isCtxValid()) return;
      chrome.runtime.sendMessage({ action: 'quickAdd', sym });
    });
    document.body.appendChild(btn);
  }

  function initQuickAddBtn() {
    chrome.storage.local.get('upbit_alarm_settings_v1', data => {
      const s = data['upbit_alarm_settings_v1'] || {};
      if (s.quickAddBtn === false) return;
      const sym = getBithumbSym();
      if (sym) injectQuickAddBtn(sym);
      // 거래 페이지 경로인데 심볼 정규식이 안 맞으면 빗썸이 URL 규칙을 바꾼 것
      else if (location.pathname.includes('/trade/')) rep('sym_parse_failed', { step: 'getBithumbSym' });
    });
  }

  initQuickAddBtn();

  let _lastHref = location.href;
  setInterval(() => {
    if (location.href !== _lastHref) {
      _lastHref = location.href;
      document.getElementById('kta-quick-add-btn')?.remove();
      initQuickAddBtn();
    }
  }, 500);
  window.addEventListener('popstate', () => { document.getElementById('kta-quick-add-btn')?.remove(); initQuickAddBtn(); });
})();

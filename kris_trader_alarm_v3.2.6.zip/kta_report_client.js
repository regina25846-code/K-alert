'use strict';
// ── 오류 자동감지 신고 클라이언트 (K-TraderKey / K-Alert 공용, 2026-09-02 신설) ──
//
// 역할: content script가 "셀렉터를 못 찾았다 / 단축키가 안 먹었다" 같은 실패를 rep(code)로
// 알려오면 (1) 같은 지문이 짧은 시간 안에 반복될 때만 (2) 화면 구조 뼈대(개인정보 없음)와 함께
// (3) background.js를 거쳐 맥미니 인증서버 POST /report 로 보낸다. 별개로 5분마다 거래소 DOM
// 프로브 서명을 비교해서 구조가 바뀌면 dom_drift 신고를 낸다(LLM/네트워크 호출 없음).
//
// ⚠️ 설계 원칙(형 확정, 2026-09-02):
//   - 기본값 꺼짐(kt_report_enabled=false). 팝업에서 켠 사용자(형)만 동작. 꺼져있으면 카운트도 안 함.
//   - 주문 경로를 절대 막지 않는다 — 여기 함수는 전부 fire-and-forget, 호출측에서 await 금지.
//   - DOM 원문을 보내지 않는다. 화이트리스트 루트 안의 태그/클래스/data-testid/role만 뼈대로 뽑고,
//     텍스트는 사전 등록 라벨과 정확히 일치할 때만 남긴다. input value/href/style/aria-label/data-*는
//     코드에서 아예 읽지 않는다(수집 대상을 열거하는 화이트리스트 방식이 1차 방어선, 정규식 스크러버는 심층방어).
//   - 이 파일은 kris_trader_ext/report_client.js 와 워크스페이스 루트 kta_report_client.js 가
//     바이트 단위로 같아야 한다(check_ext_report_gate.py #7). 제품 구분은 createReporter 옵션으로만.
//   - 순수함수(스크럽/직렬화/판정)는 node 에서 그대로 테스트된다(test_ext_report_sanitizer.js).
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else if (root && !root.__ktReport) root.__ktReport = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  const CLIENT_VERSION = 1;

  // 서버(kris_memo_auth_server.js)와 바이트 단위로 동일해야 하는 블록 — 마커 사이를 스크립트가 대조한다.
  // KT_SCRUB_PATTERNS_BEGIN
  const SCRUB_PATTERNS = [
    { name: 'email',      re: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g },
    { name: 'jwt',        re: /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}(?:\.[A-Za-z0-9_-]{8,})?/g },
    { name: 'phone',      re: /(?<!\d)0\d{1,2}[-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)/g },
    { name: 'account',    re: /(?<!\d)\d{2,6}-\d{2,6}-\d{2,8}(?:-\d{2,8})?(?!\d)/g },
    { name: 'currency',   re: /(?<![\d,])\d{1,3}(?:,\d{3})+(?:\.\d+)?/g },
    { name: 'longdigits', re: /(?<!\d)\d{8,}(?!\d)/g },
    { name: 'hex32',      re: /(?<![A-Za-z0-9])[A-Fa-f0-9]{32,}(?![A-Za-z0-9])/g },
    { name: 'token40',    re: /(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{40,}={0,2}(?![A-Za-z0-9+/_-])/g, textOnly: true },
  ];
  // KT_SCRUB_PATTERNS_END

  const REDACTED = '[redacted]';

  // 자유 텍스트(오류 메시지 등)용 — 전 패턴 적용
  function scrubText(s) {
    let out = String(s == null ? '' : s);
    let replaced = 0;
    for (const p of SCRUB_PATTERNS) {
      out = out.replace(p.re, () => { replaced++; return REDACTED; });
    }
    return { text: out, replaced };
  }

  // 직렬화된 JSON 전체용 — token40 은 클래스명(빗썸 CSS Modules 해시가 40자 넘음)을 오탐하므로 제외
  function scrubJsonString(s) {
    let out = String(s == null ? '' : s);
    let replaced = 0;
    for (const p of SCRUB_PATTERNS) {
      if (p.textOnly) continue;
      out = out.replace(p.re, () => { replaced++; return REDACTED; });
    }
    return { text: out, replaced };
  }

  // ── DOM 뼈대 직렬화 ──────────────────────────────────────────────────────
  const ALLOWED_ATTRS = ['id', 'class', 'data-testid', 'role', 'aria-selected', 'type', 'disabled'];
  const ATTR_SHORT = { id: 'i', class: 'c', 'data-testid': 'd', role: 'r', 'aria-selected': 's', type: 'y', disabled: 'z' };
  const LABEL_WHITELIST = [
    '매수', '매도', '지정가', '시장가', '예약', '지정', '시장',
    '10%', '25%', '50%', '75%', '100%', '최대',
    '매수 확인', '매도 확인', '주문 확인', '확인', '취소', '주문취소', '일괄취소', '주문 취소', '아니오',
    '미체결', '체결', '미체결 주문', '체결 주문', '거래내역',
    '원화', '보유', '관심', '연장', '로그인',
  ];
  const LABEL_SET = new Set(LABEL_WHITELIST);
  const LIMITS = { maxDepth: 12, maxNodes: 1500, maxBytes: 65536 };

  function normText(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }

  function pickAttrs(src) {
    const out = {};
    if (!src) return out;
    for (const k of ALLOWED_ATTRS) {
      if (src[k] != null) out[k] = String(src[k]);
    }
    return out;
  }

  // 실제 DOM Element 와 평문 트리({tag, attrs, text, children}) 둘 다 같은 모양으로 읽는다.
  // Element 에서는 getAttribute(허용목록)와 childNodes 만 읽는다 — .value/.innerHTML/.href 등은 절대 접근 안 함.
  function readNode(n) {
    if (n && typeof n.tag === 'string') {
      return { tag: n.tag.toLowerCase(), attrs: pickAttrs(n.attrs), text: n.text || '', children: Array.isArray(n.children) ? n.children : [] };
    }
    const attrs = {};
    for (const a of ALLOWED_ATTRS) {
      let v = null;
      try { v = typeof n.getAttribute === 'function' ? n.getAttribute(a) : null; } catch (e) { v = null; }
      if (v != null) attrs[a] = String(v);
    }
    const children = [];
    let text = '';
    const cn = (n && n.childNodes) || [];
    for (let i = 0; i < cn.length; i++) {
      const c = cn[i];
      if (!c) continue;
      if (c.nodeType === 3) text += c.nodeValue || '';
      else if (c.nodeType === 1) children.push(c);
    }
    return { tag: String((n && n.tagName) || '').toLowerCase(), attrs, text, children };
  }

  function serializeTree(rootNode, limits) {
    const L = Object.assign({}, LIMITS, limits || {});
    const out = [];
    let count = 0;
    let truncated = false;
    (function walk(n, depth) {
      if (truncated) return;
      if (count >= L.maxNodes) { truncated = true; return; }
      let r;
      try { r = readNode(n); } catch (e) { return; }
      count++;
      const rec = { t: r.tag, d: depth };
      for (const k of ALLOWED_ATTRS) {
        if (r.attrs[k] != null) rec[ATTR_SHORT[k]] = r.attrs[k].slice(0, 200);
      }
      const txt = normText(r.text);
      if (txt) rec.x = LABEL_SET.has(txt) ? txt : '#t' + txt.length;
      out.push(rec);
      if (depth >= L.maxDepth) { if (r.children.length) rec.m = r.children.length; return; }
      for (const c of r.children) walk(c, depth + 1);
    })(rootNode, 0);
    let json = JSON.stringify(out);
    while (json.length > L.maxBytes && out.length > 1) {
      out.length = Math.max(1, Math.floor(out.length * 0.8));
      truncated = true;
      json = JSON.stringify(out);
    }
    return { nodes: out, truncated };
  }

  // ── 프로브(셀렉터 생존 확인) ──────────────────────────────────────────────
  // probe: { key, css, mode: 'exists'|'count'|'classSig'|'label', label?, volatile? }
  //   volatile=true 인 프로브는 신고 본문엔 들어가지만 드리프트 서명 계산에선 빠진다(탭 상태 등에 따라 바뀌는 것).
  function runProbes(probes, doc) {
    const results = [];
    for (const p of (probes || [])) {
      const r = { k: p.key, n: -1 };
      try {
        const list = doc.querySelectorAll(p.css);
        if (p.mode === 'label') {
          const want = normText(p.label);
          let n = 0;
          for (let i = 0; i < list.length; i++) {
            if (normText(list[i].textContent) === want) n++;
          }
          r.n = n;
        } else {
          r.n = list.length;
          if (p.mode === 'classSig' && list.length) {
            let c = null;
            try { c = list[0].getAttribute('class'); } catch (e) { c = null; }
            r.c = String(c || '').slice(0, 200);
          }
        }
      } catch (e) { r.n = -1; r.e = 1; }
      results.push(r);
    }
    return results;
  }

  function hashString(s) {
    // FNV-1a 32bit ×2(seed 분리) — 로컬 비교용, 암호학적 용도 아님
    let h1 = 0x811c9dc5, h2 = 0x01000193;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      h1 ^= c; h1 = Math.imul(h1, 0x01000193) >>> 0;
      h2 ^= c; h2 = Math.imul(h2, 0x811c9dc5) >>> 0;
    }
    return h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
  }

  function probeSignature(probes, results) {
    const vol = new Set((probes || []).filter(p => p.volatile).map(p => p.key));
    const parts = [];
    for (const r of results) {
      if (vol.has(r.k)) continue;
      const p = (probes || []).find(x => x.key === r.k) || {};
      const v = p.mode === 'count' ? r.n : (r.n > 0 ? 1 : r.n);
      parts.push([r.k, v, r.c || '']);
    }
    return hashString(JSON.stringify(parts));
  }

  // ── 판정 ────────────────────────────────────────────────────────────────
  const POLICY = {
    threshold: 3,          // 같은 지문 3회 (머프 규칙)
    thresholdLow: 5,       // severity:low 는 5회
    windowMs: 10 * 60 * 1000,
    cooldownMs: 6 * 60 * 60 * 1000,
    dailyCap: 10,
    driftConfirm: 2,       // 드리프트는 2회 연속(10분) 확인 후 신고
    driftIntervalMs: 5 * 60 * 1000,
    historyKeep: 60 * 60 * 1000,
  };

  function dayKey(now) { return new Date(now).toISOString().slice(0, 10); }

  function fingerprintOf(product, exchange, code, key, version) {
    return [product, exchange, code, key || '', version].join('|').replace(/[^A-Za-z0-9_|.:-]/g, '_').slice(0, 200);
  }

  // history: { events: {fp: [ts]}, lastSent: {fp: ts}, daily: {day, n} }  — 순수함수, 새 객체 반환
  function shouldReport(fp, history, now, opts) {
    const P = Object.assign({}, POLICY, (opts && opts.policy) || {});
    const severity = (opts && opts.severity) || 'high';
    const h = {
      events: Object.assign({}, (history && history.events) || {}),
      lastSent: Object.assign({}, (history && history.lastSent) || {}),
      daily: Object.assign({ day: dayKey(now), n: 0 }, (history && history.daily) || {}),
    };
    if (h.daily.day !== dayKey(now)) h.daily = { day: dayKey(now), n: 0 };
    // 오래된 이벤트 정리
    for (const k of Object.keys(h.events)) {
      h.events[k] = h.events[k].filter(t => now - t < P.historyKeep);
      if (!h.events[k].length) delete h.events[k];
    }
    const list = (h.events[fp] || []).concat([now]);
    h.events[fp] = list;
    const inWindow = list.filter(t => now - t <= P.windowMs).length;
    const need = severity === 'low' ? P.thresholdLow : P.threshold;
    if (opts && opts.countOnly) return { report: false, reason: 'count_only', count: inWindow, history: h };
    if (inWindow < need) return { report: false, reason: 'below_threshold', count: inWindow, history: h };
    const last = h.lastSent[fp] || 0;
    if (last && now - last < P.cooldownMs) return { report: false, reason: 'cooldown', count: inWindow, history: h };
    if (h.daily.n >= P.dailyCap) return { report: false, reason: 'daily_cap', count: inWindow, history: h };
    h.lastSent[fp] = now;
    h.daily.n += 1;
    return { report: true, reason: 'threshold', count: inWindow, history: h };
  }

  // state: { baseline, pendingSig, pendingCount } — 순수함수
  function driftDecide(state, sig, opts) {
    const P = Object.assign({}, POLICY, (opts && opts.policy) || {});
    const s = Object.assign({ baseline: null, pendingSig: null, pendingCount: 0 }, state || {});
    if (!s.baseline) return { report: false, state: { baseline: sig, pendingSig: null, pendingCount: 0 } };
    if (sig === s.baseline) return { report: false, state: { baseline: s.baseline, pendingSig: null, pendingCount: 0 } };
    if (s.pendingSig === sig) {
      const n = s.pendingCount + 1;
      if (n >= P.driftConfirm) return { report: true, state: { baseline: sig, pendingSig: null, pendingCount: 0 } };
      return { report: false, state: { baseline: s.baseline, pendingSig: sig, pendingCount: n } };
    }
    return { report: false, state: { baseline: s.baseline, pendingSig: sig, pendingCount: 1 } };
  }

  const EXCLUDE_RE = [/Extension context invalidated/i, /ctx_invalid/i, /rate_limited/i, /(?<!\d)429(?!\d)/];
  function isExcludedError(message, online) {
    if (online === false) return true;
    const m = String(message == null ? '' : message);
    return EXCLUDE_RE.some(re => re.test(m));
  }

  function extFramesFrom(stack) {
    const out = [];
    const lines = String(stack || '').split('\n');
    for (const ln of lines) {
      const m = ln.match(/chrome-extension:\/\/[a-z]+\/([A-Za-z0-9_./-]+):(\d+)/);
      if (m) out.push(m[1] + ':' + m[2]);
      if (out.length >= 5) break;
    }
    return out;
  }

  function chromeMajorOf(ua) {
    const m = String(ua || '').match(/Chrome\/(\d+)/);
    return m ? parseInt(m[1], 10) : 0;
  }

  // ── 페이로드 조립 (스크럽 포함) ───────────────────────────────────────────
  function buildPayload(input) {
    const i = input || {};
    const err = i.error ? {
      message: scrubText(String(i.error.message || '').slice(0, 200)).text,
      extFrames: Array.isArray(i.error.extFrames) ? i.error.extFrames.slice(0, 5) : [],
    } : undefined;
    const base = {
      schema: 1,
      client: CLIENT_VERSION,
      kind: i.kind || 'error',
      product: i.product,
      version: String(i.version || ''),
      exchange: i.exchange || 'unknown',
      code: String(i.code || '').replace(/[^a-z0-9_]/g, '_').slice(0, 64),
      severity: i.severity || 'high',
      count: i.count || 1,
      windowSec: Math.round(POLICY.windowMs / 1000),
      command: String(i.command || '').slice(0, 40),
      step: String(i.step || '').slice(0, 60),
      path: scrubText(String(i.path || '').split('?')[0].split('#')[0].slice(0, 120)).text,
      market: String(i.market || '').replace(/[^A-Z0-9-]/gi, '').slice(0, 20),
      chromeMajor: i.chromeMajor || 0,
      installId: String(i.installId || '').slice(0, 12),
      ts: i.ts || new Date().toISOString(),
      fingerprint: i.fingerprint || '',
      error: err,
      probes: i.probes || [],
      skeleton: i.skeleton || [],
      recent: i.recent || {},
      truncated: !!i.truncated,
    };
    let json = JSON.stringify(base);
    const scrubbed = scrubJsonString(json);
    let obj;
    try { obj = JSON.parse(scrubbed.text); } catch (e) { obj = Object.assign({}, base, { skeleton: [], probes: [], error: undefined }); }
    obj.scrub = { replaced: scrubbed.replaced };
    return obj;
  }

  // ── 브라우저 글루 ─────────────────────────────────────────────────────────
  function createReporter(o) {
    const opt = o || {};
    const doc = opt.doc || (typeof document !== 'undefined' ? document : null);
    const win = opt.win || (typeof window !== 'undefined' ? window : null);
    const storage = opt.storage || (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local ? chrome.storage.local : null);
    const KEY_ENABLED = 'kt_report_enabled';
    const KEY_HIST = 'kt_report_hist_v1';
    const KEY_DRIFT = 'kt_report_drift_v1';
    const KEY_INSTALL = 'kt_report_install_v1';
    const P = Object.assign({}, POLICY, opt.policy || {});
    let enabled = false;
    let hist = null;
    let driftState = null;
    let installId = '';
    let timer = null;
    let stopped = false;
    let loaded = false;
    const queue = [];

    function sget(keys) {
      return new Promise(resolve => {
        try { storage.get(keys, d => resolve(d || {})); } catch (e) { resolve({}); }
      });
    }
    function sset(obj) {
      try { storage.set(obj, () => { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
    }

    function load() {
      if (!storage) { loaded = true; return Promise.resolve(); }
      return sget([KEY_ENABLED, KEY_HIST, KEY_DRIFT, KEY_INSTALL]).then(d => {
        enabled = d[KEY_ENABLED] === true;
        hist = d[KEY_HIST] || null;
        driftState = (d[KEY_DRIFT] && d[KEY_DRIFT][opt.exchange]) || null;
        installId = d[KEY_INSTALL] || '';
        if (!installId) {
          let id = '';
          try { id = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : ''; } catch (e) {}
          if (!id) id = Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
          installId = hashString(id).slice(0, 12);
          sset({ [KEY_INSTALL]: installId });
        }
        loaded = true;
        while (queue.length) { const q = queue.shift(); try { q(); } catch (e) {} }
        if (enabled) startDrift();
      });
    }

    try {
      if (storage && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== 'local' || !changes[KEY_ENABLED]) return;
          enabled = changes[KEY_ENABLED].newValue === true;
          if (enabled) startDrift(); else stopDrift();
        });
      }
    } catch (e) {}

    function pageReady() {
      try { return opt.isPageReady ? !!opt.isPageReady() : true; } catch (e) { return false; }
    }

    function collectSkeleton() {
      const roots = opt.skeletonRoots || [];
      const out = [];
      let truncated = false;
      let budget = LIMITS.maxNodes;
      for (const css of roots) {
        let el = null;
        try { el = doc.querySelector(css); } catch (e) { el = null; }
        if (!el) { out.push({ root: css, found: false }); continue; }
        const r = serializeTree(el, { maxNodes: Math.max(50, budget) });
        budget -= r.nodes.length;
        truncated = truncated || r.truncated;
        out.push({ root: css, found: true, nodes: r.nodes });
        if (budget <= 0) { truncated = true; break; }
      }
      return { skeleton: out, truncated };
    }

    function recentCounts(now) {
      const out = {};
      const ev = (hist && hist.events) || {};
      for (const fp of Object.keys(ev)) {
        const n = ev[fp].filter(t => now - t <= P.windowMs).length;
        if (n) out[fp.split('|')[2] || fp] = n;
      }
      return out;
    }

    function pagePath() { try { return win.location.pathname; } catch (e) { return ''; } }
    function marketOf() { try { return opt.getMarket ? String(opt.getMarket() || '') : ''; } catch (e) { return ''; } }

    function sendNow(kind, code, extra, count) {
      const now = Date.now();
      let sk = { skeleton: [], truncated: false };
      try { sk = collectSkeleton(); } catch (e) {}
      let probes = [];
      try { probes = runProbes(opt.probes || [], doc); } catch (e) {}
      const payload = buildPayload({
        kind, product: opt.product, version: opt.version, exchange: opt.exchange, code,
        severity: (extra && extra.severity) || 'high', count,
        command: extra && extra.command, step: extra && extra.step,
        path: pagePath(), market: marketOf(),
        chromeMajor: chromeMajorOf(typeof navigator !== 'undefined' ? navigator.userAgent : ''),
        installId, ts: new Date(now).toISOString(),
        fingerprint: fingerprintOf(opt.product, opt.exchange, code, extra && extra.key, opt.version),
        error: extra && (extra.message || extra.stack) ? { message: extra.message, extFrames: extFramesFrom(extra.stack) } : undefined,
        probes, skeleton: sk.skeleton, recent: recentCounts(now), truncated: sk.truncated,
      });
      try { opt.transport && opt.transport(payload); } catch (e) {}
      return payload;
    }

    // 실패 1건 기록 — 호출측은 절대 await 하지 않는다(동기 반환, 내부는 전부 조용히 실패)
    function fail(code, extra) {
      if (stopped) return;
      if (!loaded) { queue.push(() => fail(code, extra)); return; }
      if (!enabled) return;
      if (!pageReady()) return;
      const x = extra || {};
      if ((x.message || x.stack) && isExcludedError(x.message || x.stack, typeof navigator !== 'undefined' ? navigator.onLine : true)) return;
      const now = Date.now();
      const fp = fingerprintOf(opt.product, opt.exchange, code, x.key, opt.version);
      const r = shouldReport(fp, hist, now, { severity: x.severity, countOnly: !!x.countOnly, policy: P });
      hist = r.history;
      sset({ [KEY_HIST]: hist });
      if (r.report) sendNow('error', code, x, r.count);
    }

    function manualReport() {
      const run = () => { try { sendNow('manual', 'manual_report', { severity: 'low', step: 'popup' }, 1); } catch (e) {} };
      if (!loaded) queue.push(run); else run();
    }

    function driftCheck() {
      if (stopped || !enabled || !pageReady()) return;
      const probes = opt.probes || [];
      if (!probes.length) return;
      let results;
      try { results = runProbes(probes, doc); } catch (e) { return; }
      const sig = probeSignature(probes, results);
      const d = driftDecide(driftState, sig, { policy: P });
      driftState = d.state;
      sget([KEY_DRIFT]).then(cur => {
        const all = Object.assign({}, cur[KEY_DRIFT] || {});
        all[opt.exchange] = driftState;
        sset({ [KEY_DRIFT]: all });
      });
      if (d.report) sendNow('drift', 'dom_drift', { severity: 'low', step: 'driftCheck', key: sig }, 1);
    }

    function startDrift() {
      if (timer || stopped || !win) return;
      if (!(opt.probes || []).length) return;
      timer = win.setInterval(driftCheck, P.driftIntervalMs);
      win.setTimeout(driftCheck, 5000);
    }
    function stopDrift() { if (timer && win) { win.clearInterval(timer); timer = null; } }
    function stop() { stopped = true; stopDrift(); }

    load();
    return { fail, manualReport, driftCheck, start: startDrift, stop, isEnabled: () => enabled };
  }

  return {
    CLIENT_VERSION, SCRUB_PATTERNS, ALLOWED_ATTRS, LABEL_WHITELIST, LIMITS, POLICY,
    scrubText, scrubJsonString, readNode, serializeTree, runProbes, probeSignature, hashString,
    fingerprintOf, shouldReport, driftDecide, isExcludedError, extFramesFrom, chromeMajorOf,
    buildPayload, createReporter,
  };
});

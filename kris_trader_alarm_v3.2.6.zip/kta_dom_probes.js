'use strict';
// ── K-Alert DOM 프로브 테이블 (2026-09-02 신설, 데이터 전용) ──
// content.js(업비트) · bithumb_content.js · chart_lines.js 가 의존하는 DOM 지점. 형식/규칙은
// kris_trader_ext/dom_probes.js 와 같다(check_ext_probe_sync.py 가 셀렉터 리터럴을 기계 대조).
// K-Alert 는 주문폼을 안 만지므로 프로브가 작다 — 차트 컨테이너/iframe/헤더가 핵심.
(function (root) {
  if (root.__ktProbes) return;
  root.__ktProbes = {
    upbit: {
      probes: [
        { key: 'chart',        css: '#tv_chart_container',            mode: 'exists' },
        { key: 'chartIframe',  css: '#tv_chart_container iframe',     mode: 'exists' },
        { key: 'header',       css: 'header',                         mode: 'exists' },
        { key: 'headerLink',   css: 'header a',                       mode: 'exists' },
        { key: 'lblLogin',     css: 'header a, header button',        mode: 'label', label: '로그인', volatile: true },
        // [2026-09-04] 알람 → 코인 이동이 "코인 목록 줄을 실제로 클릭"하는 방식(SPA)으로 바뀌면서
        // 생긴 새 의존점. 업비트가 이 마크업을 바꾸면 이동이 통째 새로고침으로 조용히 되돌아가므로
        // (배치가 다시 풀린다) 드리프트 감시에 반드시 넣어둔다. 등급은 dom_reference.md 기준 A.
        { key: 'coinList',     css: 'section.ty02',                   mode: 'exists' },
        { key: 'coinListRow',  css: 'section.ty02 td.tit em',         mode: 'exists' },
      ],
      skeletonRoots: ['#tv_chart_container', 'header'],
    },
    // [2026-09-04] 빗썸도 업비트와 같은 content.js / chart_lines.js 를 쓰게 되면서 의존점이 생겼다.
    // 빗썸 클래스는 `컴포넌트-module_의미부__해시` 꼴이고 **재배포마다 맨 끝 해시만 바뀌므로**
    // 부분일치([class*=])로 짚는다(dom_reference.md 5-2절 실측 근거).
    bithumb: {
      probes: [
        { key: 'chart',        css: '#coin-chart',                     mode: 'exists' },
        { key: 'chartIframe',  css: '#coin-chart iframe',              mode: 'exists' },
        { key: 'header',       css: 'header',                          mode: 'exists' },
        // 알람 → 코인 이동이 목록 줄 클릭(화면 유지)으로 도는 데 필요한 지점.
        // 깨지면 이동이 조용히 통째 새로고침으로 되돌아간다.
        { key: 'coinList',     css: '[class*="coin-list__scroll"]',    mode: 'exists' },
        { key: 'coinListRow',  css: 'li[class*="coin-list-row"]',      mode: 'exists' },
        { key: 'coinRowLink',  css: '[class*="coin-list-row__link"]',  mode: 'exists' },
      ],
      skeletonRoots: ['#coin-chart', 'header'],
    },
  };
})(typeof window !== 'undefined' ? window : globalThis);

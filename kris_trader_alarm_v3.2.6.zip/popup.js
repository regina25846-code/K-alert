'use strict';

const UPBIT_STORAGE_KEY = 'upbit_alarms_v2';
const BITHUMB_STORAGE_KEY = 'bithumb_alarms_v1';
const SETTINGS_KEY = 'upbit_alarm_settings_v1';
// [2026-09-04] 알람 기록 거래소별 분리. 옛 키(섞여 있던 것)는 지우지 않고, 새 키가 아예 없을 때
// 한 번만 거래소별로 갈라서 옮긴다(migrateHistory). 옛 키를 남겨두는 이유는 되돌릴 여지 + 옛
// 버전 콘텐츠 스크립트가 아직 살아있는 탭에서 쓰던 기록을 잃지 않기 위해서다.
const HISTORY_KEY_LEGACY = 'kta_alarm_history_v1';
const HISTORY_KEYS = { upbit: 'kta_alarm_history_upbit_v1', bithumb: 'kta_alarm_history_bithumb_v1' };
const HISTORY_MAX = 50;
// 기록 화면에서 지금 보고 있는 거래소. 메인 화면의 currentExchange 와 **일부러 분리**한다 —
// 형이 업비트 화면을 보면서 빗썸 기록만 훑고 싶을 수 있기 때문. 팝업을 열 때만 메인 쪽을 따라간다.
let historyExchange = 'upbit';
let historyCache = { upbit: [], bithumb: [] };

// content.js와 동일한 순수함수 사본 — 추세선 알람의 현재 시각 기준 가격 계산.
function trendPriceAt(a, nowSec) {
  let A = a.a1, B = a.a2;
  if (!A || !B) return null;
  if (B.t < A.t) { const tmp = A; A = B; B = tmp; }
  const t1 = A.t, p1 = A.p, t2 = B.t, p2 = B.p;
  if (![t1, t2, p1, p2, nowSec].every(Number.isFinite)) return null;
  if (t2 === t1) return null;
  const k = (nowSec - t1) / (t2 - t1);
  const ext = a.extend || 'right';
  if (ext === 'none' && (k < 0 || k > 1)) return null;
  if (ext === 'right' && k < 0) return null;
  if (a.scale === 'log') {
    if (p1 <= 0 || p2 <= 0) return null;
    return p1 * Math.pow(p2 / p1, k);
  }
  return p1 + (p2 - p1) * k;
}

function fmtDateShort(t) {
  if (!Number.isFinite(t)) return '';
  return new Date(t * 1000).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric' });
}
function fmtDateFull(t) {
  if (!Number.isFinite(t)) return '';
  return new Date(t * 1000).toLocaleString('ko-KR', { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
// TradingView resolution 문자열 → 한글 봉 이름.
const TF_KOR = {
  '1S': '1초봉', '1': '1분봉', '3': '3분봉', '5': '5분봉', '10': '10분봉', '15': '15분봉', '30': '30분봉',
  '60': '1시간봉', '240': '4시간봉', '1D': '일봉', '1W': '주봉', '1M': '월봉'
};
function tfToKor(tf) { return TF_KOR[tf] || (tf ? tf + '봉' : ''); }

// 설정 화면의 "알람 재활성화" 값을 사람이 읽을 문구로 — 추세 반복방식 드롭다운에 그대로 보여줌(형 요청).
function reactivateLabel(s) {
  switch (s.reactivate) {
    case 'instant': return '즉시';
    case '30min': return '30분 후';
    case '1hour': return '1시간 후';
    case 'custom': return `${s.reactivateMinutes || 60}분 후`;
    default: return '즉시';
  }
}

// 추세선 기울기로 상승/하락/수평 자동 판정 — a1/a2 순서 무관하게 시간순 정렬 후 비교.
function trendDirLabel(a) {
  let A = a.a1, B = a.a2;
  if (!A || !B) return '';
  if (B.t < A.t) { const tmp = A; A = B; B = tmp; }
  let slope;
  if (a.scale === 'log') {
    if (A.p <= 0 || B.p <= 0) return '';
    slope = Math.log(B.p / A.p);
  } else {
    slope = B.p - A.p;
  }
  const ratio = A.p !== 0 ? Math.abs(slope / A.p) : 0;
  if (ratio < 0.0005) return '수평추세';
  return slope > 0 ? '상승추세' : '하락추세';
}

// 목록에 짧게 보여줄 라벨 — "15분봉 하락추세" 형태. 상세정보는 title 툴팁으로 뺌.
function trendSummary(a) {
  const parts = [tfToKor(a.tf), trendDirLabel(a)].filter(Boolean);
  return parts.join(' ') || '추세선';
}

function trendSummaryDetail(a) {
  const extText = { right: '오른쪽 연장', both: '양쪽 연장', none: '선분만' }[a.extend] || '';
  const parts = [fmtDateFull(a.a1.t), '→', fmtDateFull(a.a2.t)];
  if (extText) parts.push('· ' + extText);
  if (a.scale === 'log') parts.push('· 로그축');
  const nowSec = Math.floor(Date.now() / 1000);
  const ref = trendPriceAt(a, nowSec);
  if (ref != null) parts.push('· 현재 ' + Math.round(ref).toLocaleString() + '원');
  return parts.join(' ');
}

const DEFAULT_SETTINGS = {
  sound: 'fanfare',
  volume: 70,
  reactivate: 'custom',
  reactivateMinutes: 1,
  linkTarget: 'current',
  theme: 'light',
  quickAddBtn: true,
  ntfyEnabled: false,
  ntfyTopic: '',
  ntfyCooldown: 30,
  trendSameAsPrice: true,
  trendSound: 'ding3',
  trendLastExtend: 'right',
  trendLastScale: 'linear',
  trendLastRepeat: 'perBar',
  // [2026-08-25] 가격(수평) 알람 반복 옵션의 "마지막으로 고른 값". ⚠️ 기본이 추세선(perBar)과
  // 정반대인 이유는 content.js 상단 PRICE_REPEAT_FALLBACK 주석 참고 — 예전 가격 알람 동작이
  // interval과 정확히 같아서, 하위호환을 지키려면 폴백이 반드시 'interval'이어야 한다.
  priceLastRepeat: 'interval',
  priceLastRepeatTf: '15'
};

// 가격 알람 반복 옵션 허용값 — content.js의 PRICE_REPEAT_MODES / PRICE_REPEAT_TFS와 같은 목록.
const PRICE_REPEAT_MODES = ['perBar', 'once', 'interval'];
const PRICE_REPEAT_TFS = ['1', '3', '5', '10', '15', '30', '60', '240', '1D', '1W', '1M'];
function priceRepeatOf(a) { return PRICE_REPEAT_MODES.includes(a.repeat) ? a.repeat : 'interval'; }
function priceRepeatTfOf(a, s) {
  if (PRICE_REPEAT_TFS.includes(a.repeatTf)) return a.repeatTf;
  if (s && PRICE_REPEAT_TFS.includes(s.priceLastRepeatTf)) return s.priceLastRepeatTf;
  return '15';
}

let currentExchange = 'upbit';
let upbitAlarms = [];
let bithumbAlarms = [];
let upbitMarkets = [];
let bithumbMarkets = [];
let upbitPrices = {};
let bithumbPrices = {};
let settings = { ...DEFAULT_SETTINGS };
let manageMode = false;
let acIdx = -1;
let collapsedGroups = { upbit: new Set(), bithumb: new Set() };
let editingId = null;
let currentPageSym = null;

function isActive(a) { return !a.fired && !a.disabled; }
function getAlarms() { return currentExchange === 'upbit' ? upbitAlarms : bithumbAlarms; }
function setAlarms(arr) { if (currentExchange === 'upbit') upbitAlarms = arr; else bithumbAlarms = arr; }
function getMarkets() { return currentExchange === 'upbit' ? upbitMarkets : bithumbMarkets; }
function getPrices() { return currentExchange === 'upbit' ? upbitPrices : bithumbPrices; }
function getStorageKey() { return currentExchange === 'upbit' ? UPBIT_STORAGE_KEY : BITHUMB_STORAGE_KEY; }
function getCollapsed() { return collapsedGroups[currentExchange]; }
function getGroupKey(a) { return currentExchange === 'upbit' ? a.code : a.sym; }
function getCoinUrl(a) {
  return currentExchange === 'upbit'
    ? `https://upbit.com/exchange?code=CRIX.UPBIT.${a.code}`
    : `https://www.bithumb.com/react/trade/order/${a.sym}-KRW`;
}

// [2026-09-04] 코인으로 이동 — 업비트 탭이 이미 열려 있으면 페이지를 통째로 다시 여는 대신
// 콘텐츠 스크립트에 맡겨 "코인 목록에서 그 줄을 클릭"하는 방식(SPA)으로 이동시킨다.
// 그래야 K-TraderKey 가 바꿔놓은 화면 배치가 유지된다(형 요청).
// ⚠️ SPA 이동이 실패했을 때의 폴백(통째 이동)은 콘텐츠 스크립트가 스스로 한다 — 팝업은 응답을
//    기다리는 동안 닫힐 수 있어서 여기에 폴백을 두면 이동 자체가 사라질 수 있기 때문이다.
//    여기 폴백은 "메시지가 배달조차 안 됐다"(콘텐츠 스크립트 없음/구버전)는 경우만 담당한다.
function openCoinUrl(url, opts) {
  const o = opts || {};
  if (!url) return;
  if (settings.linkTarget !== 'current') { chrome.tabs.create({ url }); return; }
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const t = tabs[0];
    if (!t || !t.id) { chrome.tabs.create({ url }); return; }
    // [2026-09-04] 빗썸도 같은 콘텐츠 스크립트를 쓰게 되어 같은 경로를 탄다.
    const onUpbit = /^https:\/\/(www\.)?upbit\.com\//.test(t.url || '');
    const onBithumb = /^https:\/\/www\.bithumb\.com\//.test(t.url || '');
    const sameSite = (o.exchange === 'upbit' && onUpbit) || (o.exchange === 'bithumb' && onBithumb);
    if (o.sym && sameSite) {
      try {
        chrome.tabs.sendMessage(t.id, { action: 'ktaGoCoin', sym: o.sym }, res => {
          // ⚠️ `res.ok` 로 판단하면 안 된다. 콘텐츠 스크립트는 이제 화면을 유지한 이동에만 ok:true 를
          //    주고, 스스로 통째 새로고침으로 떨어졌을 때는 ok:false 에 사유를 담아 돌려준다.
          //    그때 여기서 또 이동시키면 **두 번 이동**한다. 답이 왔다는 것 자체가 "저쪽이 처리했다"는
          //    뜻이므로, 여기 폴백은 답이 아예 안 온 경우(구버전/스크립트 없음)만 담당한다.
          if (chrome.runtime.lastError || !res) chrome.tabs.update(t.id, { url });
        });
        return;
      } catch (e) { /* 아래 예전 경로로 떨어진다 */ }
    }
    chrome.tabs.update(t.id, { url });
  });
}

// [2026-09-04] 목록·기록을 innerHTML 로 통째로 그리기 때문에, 사람이 쓴 글(메모)이나 거래소가
// 준 이름을 그대로 끼워넣으면 HTML 로 해석된다. 실제 피해는 메모에 큰따옴표(") 하나만 들어가도
// `value="..."` 가 거기서 끊겨 편집 입력칸의 값이 잘리는 것이고, 주입된 요소가 토글/삭제 버튼을
// 덮을 수도 있다. MV3 기본 CSP 가 인라인 핸들러를 막아 코드 실행까지는 안 가지만(실측 확인),
// 그 방어선 하나에만 기대지 않는다. `&` 를 반드시 먼저 바꿔야 이중 치환이 안 생긴다.
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ── Theme ─────────────────────────────────────────────────────────────
function applyTheme(t) {
  document.body.classList.toggle('light', t === 'light');
  const btn = document.getElementById('btn-theme');
  // 표시만 교체 (이모지 → SVG 스프라이트). 동작/저장 로직은 그대로.
  if (btn) btn.innerHTML = `<svg class="ico"><use href="#${t === 'light' ? 'i-moon' : 'i-sun'}"/></svg>`;
}

// ── Storage ──────────────────────────────────────────────────────────
function loadAllAlarms() {
  return new Promise(resolve => {
    chrome.storage.local.get([UPBIT_STORAGE_KEY, BITHUMB_STORAGE_KEY], data => {
      upbitAlarms = data[UPBIT_STORAGE_KEY] || [];
      bithumbAlarms = data[BITHUMB_STORAGE_KEY] || [];
      resolve();
    });
  });
}

function saveAlarms() {
  chrome.storage.local.set({ [getStorageKey()]: getAlarms() });
}

function loadSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      settings = { ...DEFAULT_SETTINGS, ...(data[SETTINGS_KEY] || {}) };
      resolve();
    });
  });
}

function saveSettings(s) {
  chrome.storage.local.set({ [SETTINGS_KEY]: s });
}

// ── API ──────────────────────────────────────────────────────────────
async function fetchUpbitPrices() {
  const codes = [...new Set(upbitAlarms.map(a => a.code))];
  if (!codes.length) return;
  try {
    const r = await fetch(`https://api.upbit.com/v1/ticker?markets=${codes.join(',')}`);
    const data = await r.json();
    data.forEach(d => { upbitPrices[d.market] = d.trade_price; });
  } catch {}
}

async function fetchUpbitMarkets() {
  try {
    const r = await fetch('https://api.upbit.com/v1/market/all?isDetails=false');
    const data = await r.json();
    upbitMarkets = data
      .filter(m => m.market.startsWith('KRW-'))
      .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
  } catch {}
}

async function loadBithumbData() {
  try {
    const [tickerRes, marketRes] = await Promise.all([
      fetch('https://api.bithumb.com/public/ticker/ALL_KRW'),
      fetch('https://api.bithumb.com/v1/market/all').catch(() => null)
    ]);
    const data = await tickerRes.json();
    if (data.status !== '0000') return;
    const korMap = {};
    upbitMarkets.forEach(m => { korMap[m.sym] = m.kor; });
    if (marketRes && marketRes.ok) {
      const mData = await marketRes.json();
      mData.filter(m => m.market.startsWith('KRW-')).forEach(m => {
        const sym = m.market.replace('KRW-', '');
        if (!korMap[sym]) korMap[sym] = m.korean_name;
      });
    }
    bithumbMarkets = [];
    Object.entries(data.data).forEach(([sym, info]) => {
      if (sym === 'date') return;
      bithumbMarkets.push({ sym, kor: korMap[sym] || '' });
      bithumbPrices[sym] = parseFloat(info.closing_price);
    });
    bithumbMarkets.sort((a, b) => a.sym.localeCompare(b.sym));
  } catch {}
}

async function fetchPrices() {
  if (!upbitMarkets.length) await fetchUpbitMarkets();
  await Promise.all([fetchUpbitPrices(), loadBithumbData()]);
}

async function prefetchCoinPrice(sym) {
  if (currentExchange === 'upbit') {
    const key = `KRW-${sym}`;
    if (upbitPrices[key]) return;
    try {
      const r = await fetch(`https://api.upbit.com/v1/ticker?markets=${key}`);
      const d = await r.json();
      if (d[0]) upbitPrices[key] = d[0].trade_price;
    } catch {}
  } else {
    if (bithumbPrices[sym]) return;
    try {
      const r = await fetch(`https://api.bithumb.com/public/ticker/${sym}_KRW`);
      const d = await r.json();
      if (d.status === '0000') bithumbPrices[sym] = parseFloat(d.data.closing_price);
    } catch {}
  }
}

// ── Sound ─────────────────────────────────────────────────────────────
function previewSound(soundName) {
  if (soundName === 'none') return;
  fetch(chrome.runtime.getURL(`sounds/${soundName}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(settings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
}

// ── Render ───────────────────────────────────────────────────────────
function render() {
  const alarms = getAlarms();
  const prices = getPrices();
  const collapsed = getCollapsed();
  const listEl = document.getElementById('alarm-list');
  const emptyEl = document.getElementById('empty-state');
  const footerEl = document.getElementById('manage-footer');

  document.querySelectorAll('.exch-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.exch === currentExchange);
  });

  if (!alarms.length) {
    listEl.innerHTML = '';
    emptyEl.style.display = 'block';
    footerEl.style.display = 'none';
    return;
  }
  emptyEl.style.display = 'none';
  footerEl.style.display = manageMode ? 'flex' : 'none';

  const groupMap = new Map();
  alarms.forEach(a => {
    const key = getGroupKey(a);
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key).push(a);
  });

  const groupEntries = [...groupMap.entries()];
  if (currentPageSym) {
    groupEntries.sort(([keyA], [keyB]) => {
      const aMatch = (currentExchange === 'upbit' ? keyA.replace('KRW-', '') : keyA).toUpperCase() === currentPageSym;
      const bMatch = (currentExchange === 'upbit' ? keyB.replace('KRW-', '') : keyB).toUpperCase() === currentPageSym;
      return aMatch === bMatch ? 0 : aMatch ? -1 : 1;
    });
  }

  listEl.innerHTML = groupEntries.map(([key, grpAlarms]) => {
    const sym = currentExchange === 'upbit' ? key.replace('KRW-', '') : key;
    const isCurrentPage = currentPageSym && sym.toUpperCase() === currentPageSym;
    const kor = grpAlarms[0].kor || '';
    const curPrice = prices[key];
    const isCollapsed = collapsed.has(key);

    const itemsHtml = grpAlarms.map(a => {
      const isTrend = a.type === 'trend';
      const dirText = a.dir === 'above' ? '↑ 이상' : '↓ 이하';
      const active = isActive(a);

      if (manageMode) {
        return `<div class="alarm-item">
          <input type="checkbox" class="chk-box alarm-chk" data-id="${a.id}"/>
          ${isTrend ? '' : `<span class="alarm-dir" data-dir="${a.dir}">${dirText}</span>`}
          <span class="alarm-price">${isTrend ? trendSummary(a) : Number(a.price).toLocaleString() + '원'}</span>
        </div>`;
      }

      if (isTrend) {
        if (editingId === a.id) {
          // 가격알람처럼 한 번 클릭하면 열리는 편집폼 — 메모(엔터저장)/연장방향/가격축까지 여기서 수정,
          // 좌표 자체를 바꾸고 싶을 때만 별도 버튼으로 차트 다시찍기 진입.
          return `<div class="alarm-item editing" data-id="${a.id}">
            <div class="alarm-main">
              <span class="alarm-price trend-label">${trendSummary(a)}</span>
              <div class="alarm-actions">
                <button class="btn-trend-repick" data-id="${a.id}">좌표 다시 찍기</button>
                <button class="trend-edit-save" data-id="${a.id}">저장</button>
                <button class="btn-edit-cancel">취소</button>
              </div>
            </div>
            <div class="alarm-main">
              <select class="edit-dir trend-edit-extend" data-id="${a.id}">
                <option value="right" ${a.extend === 'right' ? 'selected' : ''}>오른쪽 연장</option>
                <option value="both" ${a.extend === 'both' ? 'selected' : ''}>양쪽 연장</option>
                <option value="none" ${a.extend === 'none' ? 'selected' : ''}>선분만</option>
              </select>
              <select class="edit-dir trend-edit-scale" data-id="${a.id}">
                <option value="linear" ${a.scale !== 'log' ? 'selected' : ''}>일반축</option>
                <option value="log" ${a.scale === 'log' ? 'selected' : ''}>로그축</option>
              </select>
            </div>
            <div class="alarm-main">
              <select class="edit-dir trend-edit-repeat" data-id="${a.id}">
                <option value="perBar" ${(!a.repeat || a.repeat === 'perBar') ? 'selected' : ''}>봉마다 반복</option>
                <option value="once" ${a.repeat === 'once' ? 'selected' : ''}>한 번만 울림</option>
                <option value="interval" ${a.repeat === 'interval' ? 'selected' : ''}>재활성화 설정(${reactivateLabel(settings)})</option>
              </select>
            </div>
            <input type="text" class="edit-memo trend-edit-memo" data-id="${a.id}" placeholder="비고 (선택) · 엔터로 저장" value="${escapeHtml(a.memo)}"/>
          </div>`;
        }
        // 평소엔 요약 표시만 — 가격알람과 동일하게 한 번 클릭하면 위 편집폼이 열림.
        return `<div class="alarm-item alarm-item-trend" data-id="${a.id}">
          <span class="alarm-price trend-label" title="${trendSummaryDetail(a)}">${trendSummary(a)}</span>
          <span class="alarm-memo-text">${escapeHtml(a.memo)}</span>
          <div class="alarm-actions">
            <label class="toggle" title="${active ? '비활성화' : '다시 활성화'}">
              <input type="checkbox" class="toggle-chk" data-id="${a.id}" ${active ? 'checked' : ''}/>
              <span class="toggle-slider"></span>
            </label>
            <button class="btn-del" data-id="${a.id}"><svg class="ico" style="pointer-events:none"><use href="#i-x"/></svg></button>
          </div>
        </div>`;
      }

      if (editingId === a.id) {
        // [2026-08-25] 가격 알람 반복 옵션 — 추세선 편집폼(위)의 반복 select와 문구/순서를 맞췄다.
        // 연장/축은 수평선에 개념 자체가 없으니 넣지 않는다(형 확정).
        // [2026-09-04] 예전엔 업비트에서만 띄웠다 — 빗썸 발동부(옛 bithumb_content.js)에 반복 처리가
        // 아예 없어서, 고를 수는 있는데 아무 일도 안 일어나는 거짓 UI가 되기 때문이었다.
        // 이제 빗썸도 같은 content.js 가 발동시키므로 두 거래소 모두에서 띄운다.
        // 반복 select 와 좌표 다시 찍기 버튼은 계속 하나로 묶어둔다("select 없이 버튼만" 상태 방지).
        // [2026-08-26] 형이 캡쳐로 지정한 최종 배치: 저장/취소 줄 바로 아래, 반복 select(왼쪽)+
        // 좌표 다시 찍기 버튼(오른쪽)을 같은 줄에 나란히 — 버튼을 단독 줄로 뺐던 이전 판(줄 폭을 꽉
        // 채우던 .repick-row)은 폐기하고 다시 병합. 버튼 자체 스타일(.btn-price-repick)은 그대로 두고
        // 배치만 .repeat-repick-row(flex, 버튼은 margin-left:auto로 우측 정렬)로 조정 — 저장/취소가
        // 있는 첫 줄의 .alarm-actions와 동일한 정렬 원리라 두 줄의 우측 끝이 시각적으로 맞는다.
        const repeatRow = `
          <div class="alarm-main repeat-repick-row">
            <select class="edit-repeat price-edit-repeat" data-id="${a.id}"
                    title="봉마다 반복은 저장된 봉 길이 기준이에요. 차트 위에서 알람선을 더블클릭하면 지금 보고 있는 봉 길이로 바꿀 수 있어요.">
              <option value="perBar" ${priceRepeatOf(a) === 'perBar' ? 'selected' : ''}>봉마다 반복(${tfToKor(priceRepeatTfOf(a, settings))})</option>
              <option value="once" ${priceRepeatOf(a) === 'once' ? 'selected' : ''}>한 번만 울림</option>
              <option value="interval" ${priceRepeatOf(a) === 'interval' ? 'selected' : ''}>재활성화 설정(${reactivateLabel(settings)})</option>
            </select>
            <button class="btn-price-repick" data-id="${a.id}">좌표 다시 찍기</button>
          </div>`;
        return `<div class="alarm-item editing">
          <div class="alarm-main">
            <select class="edit-dir" data-id="${a.id}">
              <option value="above" ${a.dir === 'above' ? 'selected' : ''}>↑ 이상</option>
              <option value="below" ${a.dir === 'below' ? 'selected' : ''}>↓ 이하</option>
            </select>
            <input type="number" class="edit-price" data-id="${a.id}" value="${a.price}"/>
            <div class="alarm-actions">
              <button class="btn-edit-save" data-id="${a.id}">저장</button>
              <button class="btn-edit-cancel">취소</button>
            </div>
          </div>${repeatRow}
          <input type="text" class="edit-memo" placeholder="비고 (선택)" value="${escapeHtml(a.memo)}"/>
        </div>`;
      }

      return `<div class="alarm-item">
        <span class="alarm-dir editable" data-dir="${a.dir}" data-id="${a.id}">${dirText}</span>
        <span class="alarm-price editable" data-id="${a.id}">${Number(a.price).toLocaleString()}원</span>
        <span class="alarm-memo-text">${escapeHtml(a.memo)}</span>
        <div class="alarm-actions">
          <label class="toggle" title="${active ? '비활성화' : '다시 활성화'}">
            <input type="checkbox" class="toggle-chk" data-id="${a.id}" ${active ? 'checked' : ''}/>
            <span class="toggle-slider"></span>
          </label>
          <button class="btn-del" data-id="${a.id}"><svg class="ico" style="pointer-events:none"><use href="#i-x"/></svg></button>
        </div>
      </div>`;
    }).join('');

    const groupChk = manageMode
      ? `<input type="checkbox" class="chk-box group-chk" data-key="${key}"/>`
      : '';

    return `<div class="group${isCurrentPage ? ' group-current' : ''}" data-key="${key}">
      <div class="group-hdr">
        ${groupChk}
        ${isCurrentPage ? '<span class="badge-current"><svg class="ico"><use href="#i-pin"/></svg></span>' : ''}
        <span class="group-sym coin-link" data-key="${key}">${sym}</span>
        ${kor ? `<span class="group-kor">${escapeHtml(kor)}</span>` : ''}
        <span class="group-cur">${curPrice ? '현재: ' + Number(curPrice).toLocaleString() + '원' : ''}</span>
        <span class="group-chevron">${isCollapsed ? '›' : '⌄'}</span>
      </div>
      <div class="group-body${isCollapsed ? ' collapsed' : ''}">${itemsHtml}</div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.coin-link').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const key = el.dataset.key;
      const alarm = getAlarms().find(a => getGroupKey(a) === key);
      const url = alarm ? getCoinUrl(alarm) : '';
      if (!url) return;
      openCoinUrl(url, { exchange: currentExchange, sym: alarm && alarm.sym });
    });
  });

  listEl.querySelectorAll('.group-hdr').forEach(hdr => {
    hdr.addEventListener('click', e => {
      if (e.target.closest('.chk-box') || e.target.closest('.coin-link')) return;
      const key = hdr.closest('.group').dataset.key;
      const c = getCollapsed();
      if (c.has(key)) c.delete(key); else c.add(key);
      render();
    });
  });

  if (!manageMode) {
    listEl.querySelectorAll('.toggle-chk').forEach(chk => {
      chk.addEventListener('change', e => {
        e.stopPropagation();
        const alarm = getAlarms().find(a => a.id === +chk.dataset.id);
        if (!alarm) return;
        if (chk.checked) { alarm.fired = false; alarm.disabled = false; }
        else { alarm.disabled = true; }
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.btn-del').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        setAlarms(getAlarms().filter(a => a.id !== +btn.dataset.id));
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.editable').forEach(el => {
      el.addEventListener('click', e => {
        e.stopPropagation();
        editingId = +el.dataset.id;
        render();
        const inp = listEl.querySelector('.edit-price');
        if (inp) { inp.focus(); inp.select(); }
      });
    });
    listEl.querySelectorAll('.btn-edit-save').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = +btn.dataset.id;
        const alarm = getAlarms().find(a => a.id === id);
        if (alarm) {
          const dirEl = listEl.querySelector(`.edit-dir[data-id="${id}"]`);
          const priceEl = listEl.querySelector(`.edit-price[data-id="${id}"]`);
          const memoEl = listEl.querySelector('.edit-memo');
          const repeatEl = listEl.querySelector(`.price-edit-repeat[data-id="${id}"]`);
          const newPrice = parseFloat(priceEl?.value);
          if (!isNaN(newPrice) && newPrice > 0) {
            const priceChanged = alarm.price !== newPrice;
            alarm.dir = dirEl?.value || alarm.dir;
            alarm.price = newPrice;
            alarm.fired = false;
            // 기준가가 바뀌면 "처음부터 다시"라서 봉마다 반복의 봉 워터마크도 리셋(온차트 좌표
            // 다시찍기와 같은 처리). 반복 필드가 없던 기존 알람은 이 값을 읽는 코드가 없어 무영향.
            if (priceChanged) alarm.lastFiredBarT = null;
          }
          alarm.memo = memoEl?.value.trim() || '';
          // [2026-08-25] 반복방식 저장. select가 아예 없으면(빗썸) 손대지 않아서 기존 동작 그대로.
          if (repeatEl && PRICE_REPEAT_MODES.includes(repeatEl.value)) {
            alarm.repeat = repeatEl.value;
            if (repeatEl.value === 'perBar') alarm.repeatTf = priceRepeatTfOf(alarm, settings);
            settings.priceLastRepeat = alarm.repeat;
            saveSettings(settings);
          }
        }
        editingId = null;
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.btn-edit-cancel').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        editingId = null;
        render();
      });
    });
    listEl.querySelectorAll('.alarm-item-trend').forEach(el => {
      el.addEventListener('click', e => {
        // 토글/삭제 버튼 클릭까지 편집폼을 열어버리면 안 되니 그 안쪽 클릭은 무시(가격알람과 동일 패턴).
        if (e.target.closest('.toggle') || e.target.closest('.btn-del')) return;
        e.stopPropagation();
        editingId = +el.dataset.id;
        render();
        const inp = listEl.querySelector('.trend-edit-memo');
        if (inp) { inp.focus(); inp.select(); }
      });
    });
    function saveTrendEditFields(id) {
      const alarm = getAlarms().find(a => a.id === id);
      if (!alarm) return;
      const memoEl = listEl.querySelector(`.trend-edit-memo[data-id="${id}"]`);
      const extEl = listEl.querySelector(`.trend-edit-extend[data-id="${id}"]`);
      const scaleEl = listEl.querySelector(`.trend-edit-scale[data-id="${id}"]`);
      const repeatEl = listEl.querySelector(`.trend-edit-repeat[data-id="${id}"]`);
      if (memoEl) alarm.memo = memoEl.value.trim();
      if (extEl) alarm.extend = extEl.value;
      if (scaleEl) alarm.scale = scaleEl.value;
      if (repeatEl) alarm.repeat = repeatEl.value;
      // 연장방향/가격축/반복방식은 다음 알람 생성·수정에도 마지막 설정값이 기본으로 이어지도록 저장(형 요청).
      if (extEl || scaleEl) {
        settings.trendLastExtend = alarm.extend;
        settings.trendLastScale = alarm.scale;
      }
      if (repeatEl) settings.trendLastRepeat = alarm.repeat;
      if (extEl || scaleEl || repeatEl) saveSettings(settings);
      editingId = null;
      saveAlarms();
      render();
    }
    listEl.querySelectorAll('.trend-edit-save').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        saveTrendEditFields(+btn.dataset.id);
      });
    });
    listEl.querySelectorAll('.trend-edit-memo').forEach(inp => {
      inp.addEventListener('keydown', e => {
        e.stopPropagation();
        if (e.key === 'Enter') {
          saveTrendEditFields(+inp.dataset.id);
        } else if (e.key === 'Escape') {
          editingId = null;
          render();
        }
      });
    });
    listEl.querySelectorAll('.btn-trend-repick').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = +btn.dataset.id;
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'startTrendPick', editId: id }, () => window.close());
          else window.close();
        });
      });
    });
    // 가격 알람 편집폼의 "좌표 다시 찍기" — 추세선 repick과 완전히 동일한 패턴(다른 액션명만 사용).
    // [2026-09-04] 두 거래소 모두에서 렌더링된다(빗썸도 같은 차트 엔진을 쓰게 됨) — 거래소 분기 불필요.
    listEl.querySelectorAll('.btn-price-repick').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = +btn.dataset.id;
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'startPriceAlarmPick', editId: id }, () => window.close());
          else window.close();
        });
      });
    });
    listEl.querySelectorAll('.edit-price').forEach(priceEl => {
      priceEl.addEventListener('input', () => {
        const targetPrice = parseFloat(priceEl.value);
        if (!targetPrice || targetPrice <= 0) return;
        const id = +priceEl.dataset.id;
        const alarm = getAlarms().find(a => a.id === id);
        if (!alarm) return;
        const key = currentExchange === 'upbit' ? `KRW-${alarm.sym}` : alarm.sym;
        const curPrice = getPrices()[key];
        if (!curPrice) return;
        const dirEl = listEl.querySelector(`.edit-dir[data-id="${id}"]`);
        if (dirEl) dirEl.value = targetPrice >= curPrice ? 'above' : 'below';
      });
    });
  } else {
    listEl.querySelectorAll('.group-chk').forEach(gChk => {
      gChk.addEventListener('change', e => {
        e.stopPropagation();
        listEl.querySelectorAll('.alarm-chk').forEach(c => {
          const alarm = getAlarms().find(a => a.id === +c.dataset.id);
          if (alarm && getGroupKey(alarm) === gChk.dataset.key) c.checked = gChk.checked;
        });
        syncSelectAll();
      });
    });
    listEl.querySelectorAll('.alarm-chk').forEach(c => c.addEventListener('change', syncSelectAll));
  }
}

function syncSelectAll() {
  const all = document.querySelectorAll('.alarm-chk');
  const checked = document.querySelectorAll('.alarm-chk:checked');
  const chkAll = document.getElementById('chk-all');
  if (chkAll) chkAll.checked = all.length > 0 && all.length === checked.length;
}

// ── Chosung ───────────────────────────────────────────────────────────
const CHOSUNG = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
function getChosung(ch) {
  const c = ch.charCodeAt(0) - 0xAC00;
  return (c >= 0 && c <= 11171) ? CHOSUNG[Math.floor(c / 588)] : ch;
}
function toChosung(str) { return [...str].map(getChosung).join(''); }
function isAllChosung(str) { return /^[ㄱ-ㅎ]+$/.test(str); }
function isKoreanInput(str) { return /^[ㄱ-ㅎㅏ-ㅣ가-힣]+$/.test(str); }

// ── 영타→한타 변환 (두벌식) ──────────────────────────────────────────
const ENG_TO_KOR = {
  q:'ㅂ',w:'ㅈ',e:'ㄷ',r:'ㄱ',t:'ㅅ',y:'ㅛ',u:'ㅕ',i:'ㅑ',o:'ㅐ',p:'ㅔ',
  a:'ㅁ',s:'ㄴ',d:'ㅇ',f:'ㄹ',g:'ㅎ',h:'ㅗ',j:'ㅓ',k:'ㅏ',l:'ㅣ',
  z:'ㅋ',x:'ㅌ',c:'ㅊ',v:'ㅍ',b:'ㅠ',n:'ㅜ',m:'ㅡ'
};

// 두벌식 자모 → 완성형 한글 조합
const CHO  = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const JUNG = ['ㅏ','ㅐ','ㅑ','ㅒ','ㅓ','ㅔ','ㅕ','ㅖ','ㅗ','ㅘ','ㅙ','ㅚ','ㅛ','ㅜ','ㅝ','ㅞ','ㅟ','ㅠ','ㅡ','ㅢ','ㅣ'];
const JONG = ['','ㄱ','ㄲ','ㄳ','ㄴ','ㄵ','ㄶ','ㄷ','ㄹ','ㄺ','ㄻ','ㄼ','ㄽ','ㄾ','ㄿ','ㅀ','ㅁ','ㅂ','ㅄ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const JONG_TO_CHO = {'ㄱ':0,'ㄲ':1,'ㄴ':2,'ㄷ':3,'ㄹ':5,'ㅁ':6,'ㅂ':7,'ㅅ':9,'ㅆ':10,'ㅇ':11,'ㅈ':12,'ㅊ':14,'ㅋ':15,'ㅌ':16,'ㅍ':17,'ㅎ':18};

function composeJamo(jamo) {
  let result = '';
  let cho = -1, jung = -1, jong = -1;
  const flush = () => {
    if (cho < 0) return;
    if (jung < 0) { result += CHO[cho]; cho = -1; return; }
    result += String.fromCharCode(0xAC00 + (cho * 21 + jung) * 28 + jong + 1);
    cho = -1; jung = -1; jong = -1;
  };
  for (const ch of jamo) {
    const ci = CHO.indexOf(ch), vi = JUNG.indexOf(ch), ji = JONG.indexOf(ch);
    if (vi >= 0) { // 모음
      if (cho >= 0 && jung < 0) { jung = vi; }
      else if (cho >= 0 && jung >= 0 && jong >= 0) {
        // 종성을 초성으로 분리
        const prevJong = jong; jong = -1;
        flush();
        cho = JONG_TO_CHO[JONG[prevJong + 1]] ?? -1;
        jung = vi;
      } else { flush(); result += ch; }
    } else if (ci >= 0) { // 자음 (초성 후보)
      if (cho >= 0 && jung >= 0 && jong < 0) {
        // 종성 시도
        const ji2 = JONG.indexOf(ch, 1);
        if (ji2 > 0) { jong = ji2 - 1; } else flush();
        if (jong < 0) { cho = ci; }
      } else { flush(); cho = ci; }
    } else { flush(); result += ch; }
  }
  flush();
  return result;
}

function engToKorStr(str) {
  const jamo = str.toLowerCase().split('').map(c => ENG_TO_KOR[c] || c).join('');
  return composeJamo(jamo);
}

// ── Autocomplete ─────────────────────────────────────────────────────
function showAC(query) {
  const ac = document.getElementById('ac-list');
  const markets = getMarkets();
  if (!query || !markets.length) { ac.style.display = 'none'; acIdx = -1; return; }
  const q = query.toUpperCase();
  const csQuery = isAllChosung(query) ? query : null;
  const isKo = isKoreanInput(query);
  const isEng = !isKo && /^[a-zA-Z]+$/.test(query);
  const converted = isEng ? engToKorStr(query) : null;       // 완성형 한글

  const filtered = markets.filter(m => {
    if (isKo) return (m.kor && m.kor.includes(query)) || (csQuery && m.kor && toChosung(m.kor).includes(csQuery));
    if (m.sym.includes(q)) return true;
    if (converted && m.kor && m.kor.includes(converted)) return true;
    return false;
  });
  filtered.sort((a, b) => {
    const aExact = a.sym === q, bExact = b.sym === q;
    if (aExact !== bExact) return aExact ? -1 : 1;
    const aStarts = a.sym.startsWith(q), bStarts = b.sym.startsWith(q);
    if (aStarts !== bStarts) return aStarts ? -1 : 1;
    return a.sym.localeCompare(b.sym);
  });
  const matched = filtered.slice(0, 20);
  if (!matched.length) { ac.style.display = 'none'; acIdx = -1; return; }
  acIdx = -1;
  ac.innerHTML = matched.map(m =>
    `<div class="ac-item" data-sym="${m.sym}">
      <span class="ac-sym">${escapeHtml(m.sym)}</span>${m.kor ? `<span class="ac-kor">${escapeHtml(m.kor)}</span>` : ''}
    </div>`
  ).join('');
  ac.querySelectorAll('.ac-item').forEach(el => {
    el.addEventListener('mousedown', e => { e.preventDefault(); selectAC(el.dataset.sym); });
  });
  ac.style.display = 'block';
}

function hideAC() {
  const ac = document.getElementById('ac-list');
  if (ac) ac.style.display = 'none';
  acIdx = -1;
}

function selectAC(sym) {
  document.getElementById('coin-input').value = sym;
  hideAC();
  document.getElementById('price-input').focus();
  prefetchCoinPrice(sym);
}

function moveAC(dir) {
  const ac = document.getElementById('ac-list');
  if (!ac || ac.style.display === 'none') return;
  const items = ac.querySelectorAll('.ac-item');
  if (!items.length) return;
  if (acIdx >= 0) items[acIdx].classList.remove('active');
  acIdx = Math.max(0, Math.min(acIdx + dir, items.length - 1));
  items[acIdx].classList.add('active');
  items[acIdx].scrollIntoView({ block: 'nearest' });
}

// ── Views ─────────────────────────────────────────────────────────────
function showView(id) {
  ['view-main','view-add','view-settings','view-history'].forEach(v => {
    document.getElementById(v).style.display = v === id ? 'flex' : 'none';
  });
}

// ── 추세선(익스텐디드 라인) 알람 추가 폼 ──────────────────────────────
// 좌표 찍기는 업비트 차트(chart_lines.js)에서만 동작 — 빗썸 탭에선 비활성화.
// [2026-09-04] 빗썸도 업비트와 같은 엔진(content.js + chart_lines.js)을 쓰게 되어 추세선 알람이
// 열렸다. 예전엔 빗썸 발동부(옛 bithumb_content.js)에 추세선 처리가 아예 없어서 막아뒀던 것.
function isTrendAvailable() { return true; }

function updateTrendAvailability() {
  const trendLabel = document.getElementById('type-trend-label');
  const trendInput = trendLabel?.querySelector('input');
  if (!trendLabel || !trendInput) return;
  const avail = isTrendAvailable();
  trendInput.disabled = !avail;
  trendLabel.style.opacity = avail ? '' : '.45';
  trendLabel.style.cursor = avail ? '' : 'not-allowed';
  trendLabel.title = avail ? '' : '지금은 추세선 알람을 만들 수 없어요';
  if (!avail && trendInput.checked) setAddType('price');
}

function setAddType(type) {
  const priceInputEl = document.getElementById('type-price-label')?.querySelector('input');
  const trendInputEl = document.getElementById('type-trend-label')?.querySelector('input');
  if (priceInputEl) priceInputEl.checked = type === 'price';
  if (trendInputEl) trendInputEl.checked = type === 'trend';
  const priceFields = document.getElementById('price-fields');
  const trendFields = document.getElementById('trend-fields');
  if (priceFields) priceFields.style.display = type === 'price' ? '' : 'none';
  if (trendFields) trendFields.style.display = type === 'trend' ? '' : 'none';
  // 추세선은 차트에서 좌표를 찍는 방식이라 코인/조건/비고 입력칸이 필요 없음 — 숨겨서 공간 확보.
  const isTrend = type === 'trend';
  ['coin-field', 'dir-field', 'memo-field'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = isTrend ? 'none' : '';
  });
}

function resetTrendForm() {
  const status = document.getElementById('draw-status');
  if (status) { status.textContent = '버튼을 누르면 팝업이 닫히고 차트에서 두 지점을 클릭하는 걸로 바로 넘어가요. 비고는 그때 입력해요.'; status.classList.remove('filled'); }
}

// ── Settings UI ───────────────────────────────────────────────────────
// ── History ───────────────────────────────────────────────────────────
// 옛 키 하나에 섞여 있던 기록을 거래소별로 한 번만 갈라 옮긴다.
// **새 키가 "아예 없을 때"(undefined)만** 돈다 — 빈 배열([])은 "이미 옮겼고 기록이 없다"는 뜻이라
// 다시 옮기지 않는다. 이 구분이 없으면 팝업을 열 때마다 옛 기록이 다시 얹혀 중복된다.
function migrateHistory(data) {
  const out = {
    upbit: data[HISTORY_KEYS.upbit],
    bithumb: data[HISTORY_KEYS.bithumb],
  };
  const needUp = out.upbit === undefined;
  const needBt = out.bithumb === undefined;
  if (!needUp && !needBt) return { hist: out, write: null };
  const legacy = data[HISTORY_KEY_LEGACY] || [];
  const write = {};
  if (needUp) {
    out.upbit = legacy.filter(h => h.exchange !== 'bithumb').slice(0, HISTORY_MAX);
    write[HISTORY_KEYS.upbit] = out.upbit;
  }
  if (needBt) {
    out.bithumb = legacy.filter(h => h.exchange === 'bithumb').slice(0, HISTORY_MAX);
    write[HISTORY_KEYS.bithumb] = out.bithumb;
  }
  return { hist: out, write };
}

function loadHistory() {
  chrome.storage.local.get([HISTORY_KEYS.upbit, HISTORY_KEYS.bithumb, HISTORY_KEY_LEGACY], data => {
    const { hist, write } = migrateHistory(data);
    historyCache = { upbit: hist.upbit || [], bithumb: hist.bithumb || [] };
    if (write) chrome.storage.local.set(write);
    // 읽음 표시는 **지금 보고 있는 거래소만** 처리한다 — 안 본 쪽 안읽음 표시를 지우면 안 된다.
    const shown = historyCache[historyExchange] || [];
    if (shown.some(h => h.unread)) {
      shown.forEach(h => { h.unread = false; });
      chrome.storage.local.set({ [HISTORY_KEYS[historyExchange]]: shown });
    }
    renderHistoryView();
  });
}

// 기록 화면의 업비트/빗썸 전환 버튼 + 삭제 버튼 이름을 지금 보는 거래소에 맞춘다.
function renderHistoryView() {
  document.querySelectorAll('#history-exch-bar .exch-tab').forEach(b => {
    b.classList.toggle('active', b.dataset.histExch === historyExchange);
  });
  const lbl = document.getElementById('clear-history-label');
  // "전체 삭제"라고만 적혀 있으면 두 거래소를 다 지우는 걸로 오해한다 — 지워지는 대상을 이름에 박는다.
  if (lbl) lbl.textContent = historyExchange === 'upbit' ? '업비트 기록 삭제' : '빗썸 기록 삭제';
  renderHistory(historyCache[historyExchange] || []);
}

function renderHistory(history) {
  const listEl = document.getElementById('history-list');
  const emptyEl = document.getElementById('history-empty');
  if (!history.length) {
    listEl.innerHTML = '';
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';
  const now = Date.now();
  listEl.innerHTML = history.map((h, i) => {
    const dirText = h.dir === 'above' ? '이상 도달' : '이하 도달';
    const diff = now - h.firedAt;
    let timeStr;
    if (diff < 60000) timeStr = '방금';
    else if (diff < 3600000) timeStr = `${Math.floor(diff / 60000)}분 전`;
    else if (diff < 86400000) timeStr = new Date(h.firedAt).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
    else timeStr = new Date(h.firedAt).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    return `<div class="history-item${h.unread ? ' unread' : ''}" data-idx="${i}" style="cursor:pointer;">
      <div class="history-top">
        <span class="history-exchange ${h.exchange}">${h.exchange === 'upbit' ? '업비트' : '빗썸'}</span>
        <span class="history-label">${escapeHtml(h.label)}</span>
        <span class="history-time">${timeStr}</span>
      </div>
      <div class="history-detail">${Number(h.price).toLocaleString()}원 ${dirText} · 현재가 ${Number(h.currentPrice).toLocaleString()}원</div>
      ${h.memo ? `<div class="history-memo">${escapeHtml(h.memo)}</div>` : ''}
    </div>`;
  }).join('');
  listEl.querySelectorAll('.history-item[data-idx]').forEach(el => {
    el.addEventListener('click', () => {
      const h = history[parseInt(el.dataset.idx)];
      const url = h.exchange === 'bithumb'
        ? `https://www.bithumb.com/react/trade/order/${h.sym}-KRW`
        : `https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${h.sym}`;
      openCoinUrl(url, { exchange: h.exchange === 'bithumb' ? 'bithumb' : 'upbit', sym: h.sym });
    });
  });
}

// [2026-09-04] 알람 → 코인 이동 결과. "화면 유지"가 원했던 결과이고, "새로고침"으로 떨어진 횟수와
// 그 사유를 같이 보여준다(PND-0104 후속 — 예전엔 실패해도 성공으로 보고돼 아무도 몰랐다).
const NAV_STATS_KEY = 'kta_nav_stats_v1';
const NAV_REASON_KOR = {
  'spa': '화면 유지하고 이동',
  'same': '이미 그 코인이라 그대로',
  'reload-not-found': '새로고침 (목록에서 못 찾음)',
  'reload-click-timeout': '새로고침 (눌렀는데 안 넘어감)',
  'reload-not-trade-page': '새로고침 (거래 화면이 아니었음)',
  'reload-no-list': '새로고침 (코인 목록을 못 찾음)',
  'reload-click-error': '새로고침 (누르기 실패)',
  'reload-scroll-error': '새로고침 (목록 훑기 실패)',
  'reload-bad-args': '새로고침 (코인 이름이 이상함)',
};
function renderNavStats() {
  const el = document.getElementById('nav-stats');
  if (!el) return;
  chrome.storage.local.get(NAV_STATS_KEY, data => {
    const st = data[NAV_STATS_KEY];
    if (!st) { el.textContent = '아직 알람에서 코인으로 이동한 적이 없어요'; return; }
    const lines = [];
    ['upbit', 'bithumb'].forEach(ex => {
      const rows = st[ex] || {};
      const keys = Object.keys(rows);
      if (!keys.length) return;
      const total = keys.reduce((s, k) => s + rows[k], 0);
      lines.push(`${ex === 'upbit' ? '업비트' : '빗썸'} — 모두 ${total}번`);
      keys.sort((a, b) => rows[b] - rows[a]).forEach(k => {
        lines.push(`   ${NAV_REASON_KOR[k] || k} ${rows[k]}번`);
      });
    });
    el.textContent = lines.length ? lines.join('\n') : '아직 알람에서 코인으로 이동한 적이 없어요';
  });
}

function loadSettingsUI() {
  document.getElementById('sound-select').value = settings.sound;
  const vol = settings.volume ?? 70;
  document.getElementById('vol-slider').value = vol;
  document.getElementById('vol-pct').textContent = vol + '%';
  const trendSameChk = document.getElementById('chk-trend-same-sound');
  if (trendSameChk) {
    trendSameChk.checked = settings.trendSameAsPrice !== false;
    document.getElementById('trend-sound-row').style.display = trendSameChk.checked ? 'none' : '';
    document.getElementById('trend-sound-select').value = settings.trendSound || 'ding3';
  }
  const val = settings.reactivate;
  document.querySelectorAll('input[name=reactivate]').forEach(r => { r.checked = r.value === val; });
  document.getElementById('custom-minutes').value = settings.reactivateMinutes || 60;
  renderNavStats();
  document.querySelectorAll('input[name=linkTarget]').forEach(r => {
    r.checked = r.value === (settings.linkTarget || 'current');
  });
  const qab = document.getElementById('chk-quick-add');
  if (qab) qab.checked = settings.quickAddBtn !== false;
  const ntfyChk = document.getElementById('chk-ntfy');
  if (ntfyChk) {
    ntfyChk.checked = settings.ntfyEnabled || false;
    document.getElementById('ntfy-config').style.display = ntfyChk.checked ? 'flex' : 'none';
    document.getElementById('ntfy-topic').value = settings.ntfyTopic || '';
    document.querySelectorAll('input[name=ntfyCooldown]').forEach(r => {
      r.checked = r.value === String(settings.ntfyCooldown ?? 30);
    });
  }
}

// ── Exchange switch ───────────────────────────────────────────────────
function switchExchange(exch) {
  if (currentExchange === exch) return;
  currentExchange = exch;
  manageMode = false;
  editingId = null;
  document.getElementById('btn-manage').textContent = '관리';
  document.getElementById('btn-new').style.display = '';
  document.getElementById('btn-theme').style.display = '';
  document.getElementById('btn-history').style.display = '';
  document.getElementById('btn-settings').style.display = '';
  updateTrendAvailability();
  render();
}

// ── Init ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await Promise.all([loadAllAlarms(), loadSettings()]);
  applyTheme(settings.theme || 'dark');

  // ── 업데이트 배너 ────────────────────────────────────────────────
  // [2026-08-27] 팝업을 열 때마다 최신 버전을 새로 확인한다.
  // 예전엔 onStartup/onInstalled에서만 체크해서, chrome://extensions 리로드(⟳)로
  // 버전을 갱신한 사용자는 브라우저를 완전히 재시작하기 전까진 알림을 못 받았음.
  const updBanner = document.getElementById('update-banner');
  let updBannerBound = false;
  function renderUpdateBanner(pending) {
    if (!updBanner) return;
    if (!pending) { updBanner.style.display = 'none'; return; }
    updBanner.style.display = 'block';
    if (!updBannerBound) {
      updBannerBound = true;
      // 클릭 시점에 storage를 다시 읽어서, 배너 표시 후 갱신된 주소를 항상 따라간다.
      updBanner.addEventListener('click', () => {
        chrome.storage.local.get('pendingUpdate', d => {
          chrome.tabs.create({ url: (d.pendingUpdate && d.pendingUpdate.page) || 'https://alert.krisb-infra.com/' });
        });
      });
    }
  }

  // 1) 저장돼있던 값으로 즉시 그린다(깜빡임 방지).
  chrome.storage.local.get('pendingUpdate', data => renderUpdateBanner(data.pendingUpdate));
  // 2) 백그라운드에 새 체크를 요청하고(서비스워커가 자고 있어도 이 메시지가 깨움), 끝나면 다시 그린다.
  //    네트워크 실패/서비스워커 미응답은 조용히 무시 — 1)에서 그린 상태가 그대로 남는다.
  try {
    chrome.runtime.sendMessage({ action: 'checkForUpdate' }, () => {
      void chrome.runtime.lastError;
      chrome.storage.local.get('pendingUpdate', data => renderUpdateBanner(data.pendingUpdate));
    });
  } catch (e) {}

  document.querySelector('.popup-logo').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://alert.krisb-infra.com/manual.html' });
  });

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0]?.url || '';
    if (url.includes('bithumb.com')) currentExchange = 'bithumb';
    else currentExchange = 'upbit';
    const upbitMatch   = url.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i);
    const bithumbMatch = url.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i);
    currentPageSym = (upbitMatch?.[1] || bithumbMatch?.[1] || '').toUpperCase() || null;
    updateTrendAvailability();
    render();
  });

  function applyQuickAdd(sym) {
    setAddType('price');
    resetTrendForm();
    showView('view-add');
    setTimeout(() => {
      const input = document.getElementById('coin-input');
      input.value = sym;
      input.dispatchEvent(new Event('input'));
      setTimeout(() => {
        const exact = document.querySelector(`.ac-item[data-sym="${sym.toUpperCase()}"]`);
        const target = exact || document.querySelector('.ac-item');
        if (target) target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      }, 150);
    }, 100);
  }

  chrome.storage.local.get('quickAddSym', data => {
    if (data.quickAddSym) {
      chrome.storage.local.remove('quickAddSym');
      applyQuickAdd(data.quickAddSym);
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.quickAddSym?.newValue) {
      chrome.storage.local.remove('quickAddSym');
      applyQuickAdd(changes.quickAddSym.newValue);
    }
  });

  fetchUpbitMarkets();
  fetchPrices().then(render);

  document.querySelectorAll('.exch-tab').forEach(btn => {
    btn.addEventListener('click', () => switchExchange(btn.dataset.exch));
  });

  document.getElementById('btn-theme').addEventListener('click', () => {
    settings.theme = settings.theme === 'light' ? 'dark' : 'light';
    applyTheme(settings.theme);
    saveSettings(settings);
  });

  document.getElementById('btn-manage').addEventListener('click', () => {
    manageMode = !manageMode;
    document.getElementById('btn-manage').textContent = manageMode ? '완료' : '관리';
    document.getElementById('btn-new').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-theme').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-history').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-settings').style.display = manageMode ? 'none' : '';
    render();
  });

  document.getElementById('btn-new').addEventListener('click', () => {
    const exchName = currentExchange === 'upbit' ? '업비트' : '빗썸';
    document.getElementById('add-title').textContent = `알람 추가 — ${exchName}`;
    const ph = currentExchange === 'upbit' ? 'BTC, 비트코인...' : 'BTC, ETH...';
    document.getElementById('coin-input').placeholder = ph;
    setAddType('price');
    resetTrendForm();
    updateTrendAvailability();
    showView('view-add');
    setTimeout(() => document.getElementById('coin-input').focus(), 50);
  });
  document.getElementById('btn-back').addEventListener('click', () => { showView('view-main'); render(); });

  document.querySelectorAll('input[name=atype]').forEach(r => {
    r.addEventListener('change', () => { if (r.checked) setAddType(r.value); });
  });

  document.getElementById('btn-draw').addEventListener('click', () => {
    // 좌표는 차트에서 바로 찍고 chart_lines.js의 인라인 미니폼에서 메모까지 저장 — 팝업은 그냥 닫힘.
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'startTrendPick' }, () => window.close());
      else window.close();
    });
  });

  // [2026-08-23] 가격 알람도 추세선과 동일하게 차트클릭 생성이 기본 — 형 요청 1번.
  document.getElementById('btn-price-draw').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: 'startPriceAlarmPick' }, () => window.close());
      else window.close();
    });
  });

  document.getElementById('btn-settings').addEventListener('click', () => {
    loadSettingsUI();
    showView('view-settings');
  });
  document.getElementById('btn-reset-nav-stats')?.addEventListener('click', () => {
    chrome.storage.local.remove(NAV_STATS_KEY, () => renderNavStats());
  });

  document.getElementById('btn-settings-back').addEventListener('click', () => showView('view-main'));

  document.getElementById('btn-history').addEventListener('click', () => {
    // 팝업을 열 때는 지금 보고 있는 거래소 기록부터 보여준다(그 뒤엔 형이 탭으로 직접 고른다).
    historyExchange = currentExchange === 'bithumb' ? 'bithumb' : 'upbit';
    loadHistory();
    showView('view-history');
  });
  document.getElementById('btn-history-back').addEventListener('click', () => showView('view-main'));
  // 지금 보고 있는 거래소의 기록만 지운다(버튼 이름도 그 거래소로 바뀌어 있다).
  document.getElementById('btn-clear-history').addEventListener('click', () => {
    const key = HISTORY_KEYS[historyExchange];
    // remove 가 아니라 빈 배열로 set 하는 이유: remove 하면 그 키가 다시 "없음(undefined)"이 돼서
    // migrateHistory 가 옛 기록을 도로 끌어온다(지웠는데 되살아나는 버그).
    chrome.storage.local.set({ [key]: [] }, () => {
      historyCache[historyExchange] = [];
      renderHistoryView();
    });
  });

  document.querySelectorAll('#history-exch-bar .exch-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const ex = btn.dataset.histExch;
      if (!ex || ex === historyExchange) return;
      historyExchange = ex;
      loadHistory(); // 바꾼 쪽의 안읽음 표시를 그때 처리해야 해서 다시 읽는다
    });
  });

  document.getElementById('btn-preview').addEventListener('click', () => {
    previewSound(document.getElementById('sound-select').value);
  });

  document.getElementById('btn-preview-trend')?.addEventListener('click', () => {
    previewSound(document.getElementById('trend-sound-select').value);
  });

  document.getElementById('chk-trend-same-sound')?.addEventListener('change', function () {
    document.getElementById('trend-sound-row').style.display = this.checked ? 'none' : '';
  });

  document.getElementById('vol-slider').addEventListener('input', function () {
    document.getElementById('vol-pct').textContent = this.value + '%';
    settings.volume = parseInt(this.value);
    saveSettings(settings);
  });

  document.getElementById('btn-save-settings').addEventListener('click', () => {
    const s = {
      sound: document.getElementById('sound-select').value,
      volume: parseInt(document.getElementById('vol-slider').value) ?? 70,
      reactivate: document.querySelector('input[name=reactivate]:checked')?.value || 'instant',
      reactivateMinutes: parseInt(document.getElementById('custom-minutes').value) || 60,
      linkTarget: document.querySelector('input[name=linkTarget]:checked')?.value || 'current',
      theme: settings.theme || 'light',
      quickAddBtn: document.getElementById('chk-quick-add')?.checked ?? true,
      ntfyEnabled: document.getElementById('chk-ntfy')?.checked || false,
      ntfyTopic: document.getElementById('ntfy-topic')?.value.trim() || '',
      ntfyCooldown: parseInt(document.querySelector('input[name=ntfyCooldown]:checked')?.value) || 30,
      trendSameAsPrice: document.getElementById('chk-trend-same-sound')?.checked ?? true,
      trendSound: document.getElementById('trend-sound-select')?.value || 'ding3'
    };
    // [2026-09-04] ⚠️ 예전엔 `settings = s` 로 통째 교체였다. 그러면 이 설정 화면의 폼에 없는
    // 키(trendLastExtend·trendLastScale·trendLastRepeat·priceLastRepeat·priceLastRepeatTf —
    // "마지막으로 고른 연장방향/가격축/반복방식"을 기억해두는 값들)가 저장 한 번에 통째로 사라져서,
    // 다음에 알람을 새로 만들 때 그 기억이 공장 기본값으로 되돌아갔다.
    // ⚠️ 병합 순서 주의: s 가 뒤에 와야 이 화면에서 방금 바꾼 값이 이긴다. 순서를 뒤집으면
    //    설정 화면이 아무것도 못 바꾸는 정반대 버그가 된다.
    settings = { ...settings, ...s };
    saveSettings(settings);
    showView('view-main');
  });

  document.getElementById('chk-ntfy')?.addEventListener('change', function () {
    document.getElementById('ntfy-config').style.display = this.checked ? 'flex' : 'none';
  });

  document.getElementById('btn-ntfy-test')?.addEventListener('click', () => {
    const topic = document.getElementById('ntfy-topic').value.trim();
    if (!topic) { alert('토픽명을 먼저 입력하세요.'); return; }
    chrome.runtime.sendMessage({ action: 'ntfyTest', topic }, res => {
      if (res && res.ok) alert(`테스트 푸시 전송 완료! (${res.status})`);
      else alert(`전송 실패: ${res?.error || '알 수 없는 오류'}`);
    });
  });

  document.getElementById('btn-export').addEventListener('click', () => {
    const alarms = getAlarms();
    const blob = new Blob([JSON.stringify(alarms, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentExchange}_alarms_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });
  document.getElementById('import-file').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const imported = JSON.parse(e.target.result);
        if (!Array.isArray(imported)) { alert('올바른 알람 JSON 파일이 아니에요'); return; }
        // Auto-detect exchange from file content: upbit uses 'KRW-xxx' codes
        const isUpbitFile = imported.some(a => typeof a.code === 'string' && a.code.startsWith('KRW-'));
        const targetAlarms = isUpbitFile ? upbitAlarms : bithumbAlarms;
        const targetKey = isUpbitFile ? UPBIT_STORAGE_KEY : BITHUMB_STORAGE_KEY;
        const merged = [...targetAlarms];
        imported.forEach(a => {
          const idx = merged.findIndex(x => x.id === a.id);
          if (idx >= 0) Object.assign(merged[idx], a);
          else merged.push(a);
        });
        if (isUpbitFile) upbitAlarms = merged; else bithumbAlarms = merged;
        chrome.storage.local.set({ [targetKey]: merged });
        const exchName = isUpbitFile ? '업비트' : '빗썸';
        showView('view-main');
        render();
        alert(`${exchName} 알람 ${imported.length}개 가져오기 완료`);
      } catch { alert('파일 파싱 오류'); }
    };
    reader.readAsText(file);
    this.value = '';
  });

  document.getElementById('chk-all').addEventListener('change', function () {
    document.querySelectorAll('.alarm-chk').forEach(c => c.checked = this.checked);
  });
  document.getElementById('btn-delete-sel').addEventListener('click', () => {
    const ids = new Set([...document.querySelectorAll('.alarm-chk:checked')].map(c => +c.dataset.id));
    if (!ids.size) return;
    setAlarms(getAlarms().filter(a => !ids.has(a.id)));
    saveAlarms();
    if (!getAlarms().length) {
      manageMode = false;
      document.getElementById('btn-manage').textContent = '관리';
      document.getElementById('btn-new').style.display = '';
      document.getElementById('btn-theme').style.display = '';
      document.getElementById('btn-history').style.display = '';
      document.getElementById('btn-settings').style.display = '';
    }
    render();
  });

  const coinInput = document.getElementById('coin-input');
  const priceInput = document.getElementById('price-input');
  const dirSelect = document.getElementById('dir-select');
  const memoInput = document.getElementById('memo-input');

  coinInput.addEventListener('input', () => showAC(coinInput.value.trim()));
  coinInput.addEventListener('blur', () => setTimeout(hideAC, 150));
  coinInput.addEventListener('keydown', e => {
    const ac = document.getElementById('ac-list');
    const open = ac && ac.style.display !== 'none';
    if (e.key === 'ArrowDown') { e.preventDefault(); if (open) moveAC(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (open) moveAC(-1); }
    else if (e.key === 'Enter') {
      if (open && acIdx >= 0) { e.preventDefault(); const act = ac.querySelector('.ac-item.active'); if (act) selectAC(act.dataset.sym); }
      else document.getElementById('btn-confirm').click();
    } else if (e.key === 'Escape') hideAC();
  });
  priceInput.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('btn-confirm').click(); });
  priceInput.addEventListener('input', async () => {
    const targetPrice = parseFloat(priceInput.value);
    if (!targetPrice || targetPrice <= 0) return;
    const sym = coinInput.value.trim().toUpperCase().replace(/^KRW-/, '');
    if (!sym) return;
    const key = currentExchange === 'upbit' ? `KRW-${sym}` : sym;
    let curPrice = getPrices()[key];
    if (!curPrice) {
      await prefetchCoinPrice(sym);
      curPrice = getPrices()[key];
    }
    if (!curPrice) return;
    dirSelect.value = targetPrice >= curPrice ? 'above' : 'below';
  });

  document.getElementById('btn-confirm').addEventListener('click', () => {
    const coinRaw = coinInput.value.trim();
    const dir = dirSelect.value;
    const memo = memoInput.value.trim();
    const atype = document.querySelector('input[name=atype]:checked')?.value || 'price';
    // 추세선 알람은 이 버튼으로 안 만듦 — btn-draw로 차트에서 좌표를 찍는 흐름만 사용.
    if (atype === 'trend') return;

    if (!coinRaw) { alert('코인을 입력해줘 (예: BTC)'); return; }
    const sym = coinRaw.toUpperCase().replace(/^KRW-/, '');

    const priceVal = parseFloat(priceInput.value);
    if (!priceVal || priceVal <= 0) { alert('목표 가격을 입력해줘'); return; }
    if (currentExchange === 'upbit') {
      const market = upbitMarkets.find(m => m.sym === sym);
      const kor = market ? market.kor : '';
      const label = market ? `${sym}(${kor})` : sym;
      // [2026-08-25] 반복방식은 마지막으로 고른 값을 이어받음(추세선 관례와 동일). 설정이 비어있으면
      // 'interval' = 예전 기본 동작 그대로. 빗썸(아래)은 발동부에 repeat 처리가 없어서 안 넣는다.
      const repeat = PRICE_REPEAT_MODES.includes(settings.priceLastRepeat) ? settings.priceLastRepeat : 'interval';
      const repeatTf = PRICE_REPEAT_TFS.includes(settings.priceLastRepeatTf) ? settings.priceLastRepeatTf : '15';
      upbitAlarms.push({ id: Date.now(), code: 'KRW-' + sym, sym, kor, label, price: priceVal, dir, memo, repeat, repeatTf, fired: false, disabled: false });
    } else {
      // [2026-09-04] 두 가지를 같이 고쳤다.
      //  ① code 를 'KRW-BTC' 꼴로 저장한다 — 예전엔 `code: sym`('BTC')이라 시세/캔들 조회에 그대로
      //     못 쓰는 값이었다(content.js 의 marketOf 가 옛 알람까지 보정해주지만, 새로 만드는 건 바르게).
      //  ② 반복방식(repeat/repeatTf)을 업비트와 똑같이 넣는다 — 이제 빗썸도 같은 발동부를 쓴다.
      const btRepeat = PRICE_REPEAT_MODES.includes(settings.priceLastRepeat) ? settings.priceLastRepeat : 'interval';
      const btRepeatTf = PRICE_REPEAT_TFS.includes(settings.priceLastRepeatTf) ? settings.priceLastRepeatTf : '15';
      bithumbAlarms.push({ id: Date.now(), code: 'KRW-' + sym, sym, kor: '', label: sym, price: priceVal, dir, memo, repeat: btRepeat, repeatTf: btRepeatTf, fired: false, disabled: false });
    }
    saveAlarms();
    coinInput.value = ''; priceInput.value = ''; dirSelect.value = 'above'; memoInput.value = '';
    hideAC();
    showView('view-main');
    render();
    if (Notification.permission === 'default') Notification.requestPermission();
  });

  chrome.storage.onChanged.addListener(changes => {
    let changed = false;
    if (changes[UPBIT_STORAGE_KEY]) { upbitAlarms = changes[UPBIT_STORAGE_KEY].newValue || []; changed = true; }
    if (changes[BITHUMB_STORAGE_KEY]) { bithumbAlarms = changes[BITHUMB_STORAGE_KEY].newValue || []; changed = true; }
    if (changed) fetchPrices().then(render);
  });
});

// ── [2026-09-02] 오류 자동 신고 토글 + "지금 상태 신고" 버튼 ──
// 알람 설정(upbit_alarm_settings_v1)과 별개의 전역 키(kt_report_enabled, 기본 false)로 즉시 저장 — 설정 스키마를 건드리지 않는다.
(function initErrorReportUI() {
  function wire() {
    const chk  = document.getElementById('chk-report');
    const last = document.getElementById('report-last');
    const btn  = document.getElementById('btn-report-now');
    if (!chk || !btn) return;
    function renderLast(v) {
      if (!last) return;
      if (!v || !v.ts) { last.textContent = '마지막 신고: 없음'; return; }
      const d = new Date(v.ts);
      const when = `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      last.textContent = `마지막 신고: ${when} ${v.ok ? '전송됨' : '전송 실패'}${v.id ? ' (' + v.id + ')' : ''}${v.code ? ' · ' + v.code : ''}`;
    }
    try {
      chrome.storage.local.get(['kt_report_enabled', 'kt_report_last_v1'], d => {
        chk.checked = d.kt_report_enabled === true;
        renderLast(d.kt_report_last_v1);
      });
      chk.addEventListener('change', () => chrome.storage.local.set({ kt_report_enabled: chk.checked === true }));
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === 'local' && ch.kt_report_last_v1) renderLast(ch.kt_report_last_v1.newValue);
      });
      btn.addEventListener('click', () => {
        const orig = btn.innerHTML;
        const done = txt => { btn.textContent = txt; setTimeout(() => { btn.innerHTML = orig; }, 2000); };
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          const t = tabs && tabs[0];
          if (!t || !t.id) { done('탭 없음'); return; }
          chrome.tabs.sendMessage(t.id, { action: 'ktaReportNow' }, () => {
            if (chrome.runtime.lastError) { done('거래소 탭에서 눌러주세요'); return; }
            done('보냈어요 ✓');
          });
        });
      });
    } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();

/* [2026-09-05] 헤더 버전 표시 — manifest.json 의 version 을 그대로 읽어서 채운다.
   예전엔 popup.html 에 'v3.2.5.2' 라고 **글자로 박아둬서**, manifest 를 3.2.5.3 → .4 로
   올려 테스트빌드를 보내도 형 화면엔 계속 v3.2.5.2 로 보였다. 형이 "지금 깐 게 최신인지"
   확인할 방법이 없었다(형 실기 지적, 2026-09-04 K-TraderKey 에서 같은 버그를 먼저 고침).
   ⚠️ 다시 손으로 적지 마라 — 버전은 manifest 한 곳에서만 관리한다. */
(function showVersion() {
  const el = document.getElementById('hdr-ver');
  if (!el) return;
  try { el.textContent = 'v' + chrome.runtime.getManifest().version; }
  catch (e) { el.textContent = 'v?'; }
})();

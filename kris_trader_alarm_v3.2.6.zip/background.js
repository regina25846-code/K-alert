// [2026-09-03] 오류신고 식별자는 소스에 박지 않고 별도 파일(kta_report_secret.js, git 추적 제외)에서 읽는다.
// 이 importScripts 는 파일이 없으면 service worker 등록 자체가 실패한다 — 패키징에서 파일이 빠졌을 때
// "신고만 조용히 403" 이 되는 대신 확장이 즉시 눈에 띄게 죽으라는 의도된 설계(2026-09-03 형 승인).
// ⚠️ 최상단 동기 호출이어야 한다(MV3 service worker 제약).
importScripts('kta_report_secret.js');

// [2026-09-05] 버전을 **manifest 에서 읽는다. 여기에 숫자를 손으로 적지 마라.**
//   여기는 업데이트 확인 기능이 "지금 깔린 버전"으로 쓰는 값이다. 예전엔 문자열로 박아둬서
//   manifest 만 올리면 이 값이 그대로 남아 **최신판인데도 업데이트 알림이 뜨거나, 반대로
//   구버전인데 안 뜨는** 어긋남이 생겼다. 2026-08-23 에도 같은 이유로 한 번 정정했는데
//   (무효 문자열 3.2.0-1 → 3.2.0) 또 어긋났다 — 손으로 맞추는 방식 자체가 원인이라 없앤다.
//   popup.js 의 헤더 버전 표시도 같은 방식으로 고쳐뒀다(getManifest().version).
//   ⚠️ getManifest() 는 MV3 서비스워커에서 동기로 쓸 수 있다(실제 확장을 띄워 확인함).
//   못 읽는 예외 상황에서는 빈 값이 되고, 아래 비교를 건너뛴다 — 엉뚱한 업데이트 배너를
//   띄우느니 조용히 넘어가는 쪽이 낫다(빈 값을 '0' 으로 두면 항상 새 버전이 있다고 오판한다).
const CURRENT_VERSION = (() => {
  try { return chrome.runtime.getManifest().version || ''; }
  catch (e) { return ''; }
})();
const HISTORY_KEY = 'kta_alarm_history_v1';
const SETTINGS_KEY = 'upbit_alarm_settings_v1';
const PUSH_COOLDOWN_KEY = 'kta_push_cooldown_v1';
// [2026-09-04] 알람 → 코인 이동 결과 집계(팝업 설정 화면에서 볼 수 있다).
const NAV_STATS_KEY = 'kta_nav_stats_v1';
// [2026-08-27] 업데이트 체크 URL을 커스텀 도메인 직결로 교체.
// 예전 주소(regina25846-code.github.io/K-alert/*)는 2026-08-26 도메인 통일 이후
// 301 리다이렉트만 내려주는데, 그 301 응답엔 Access-Control-Allow-Origin 헤더가 없어서
// 확장 서비스워커의 CORS fetch가 리다이렉트 단계에서 통째로 실패했음(= 업데이트 감지 완전 먹통).
// 최종 도착지(alert.krisb-infra.com)는 ACAO:* 를 내려주므로 직결하면 정상 동작.
const VERSION_CHECK_URL = 'https://alert.krisb-infra.com/version.json';
const UPDATE_PAGE_URL   = 'https://alert.krisb-infra.com/';
const UPDATE_CHECKED_AT_KEY = 'kta_update_checked_at_v1';
// 팝업 열 때마다 체크하되, 이 간격 안에 이미 확인했으면 네트워크 요청은 생략(형이 하루에도 여러 번 여는 걸 감안).
const UPDATE_MIN_INTERVAL_MS = 60 * 1000;

function updateBadge() {
  chrome.storage.local.get([HISTORY_KEY, 'pendingUpdate'], data => {
    const unread = (data[HISTORY_KEY] || []).filter(h => h.unread).length;
    if (unread > 0) {
      chrome.action.setBadgeText({ text: String(unread) });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else if (data.pendingUpdate) {
      chrome.action.setBadgeText({ text: 'UP' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  });
}

// 문자열 비교(latest > CURRENT_VERSION)는 자릿수가 다른 순간 깨진다.
// 예: '3.2.10' > '3.2.9' → false, '3.10.0' > '3.2.4' → false.
// 점으로 끊어서 숫자로 비교하고, 마디 개수가 달라도(3.2.4 vs 3.2.3.3) 정확히 판정.
function isNewerVersion(latest, current) {
  const a = String(latest).split('.').map(n => parseInt(n, 10) || 0);
  const b = String(current).split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x > y) return true;
    if (x < y) return false;
  }
  return false;
}

// 동시에 여러 번 불려도(팝업 열기 + onStartup 등) 실제 네트워크 요청은 하나로 합친다.
let _updateCheckInFlight = null;

function checkForUpdate(opts) {
  const o = opts || {};
  const minInterval = o.force ? 0 : (typeof o.minInterval === 'number' ? o.minInterval : UPDATE_MIN_INTERVAL_MS);
  if (_updateCheckInFlight) return _updateCheckInFlight;

  const run = (async () => {
    if (minInterval > 0) {
      let last = 0;
      try {
        const st = await chrome.storage.local.get(UPDATE_CHECKED_AT_KEY);
        last = st[UPDATE_CHECKED_AT_KEY] || 0;
      } catch (e) {}
      if (last && (Date.now() - last) < minInterval) return { ok: true, skipped: true };
    }
    try {
      const r = await fetch(VERSION_CHECK_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) throw new Error('http_' + r.status);
      const data = await r.json();
      const latest = data.version || '0';
      await chrome.storage.local.set({ [UPDATE_CHECKED_AT_KEY]: Date.now() });
      if (CURRENT_VERSION && isNewerVersion(latest, CURRENT_VERSION)) {
        await chrome.storage.local.set({ pendingUpdate: { version: latest, page: data.page || UPDATE_PAGE_URL, changelog: data.changelog || '' } });
      } else {
        await chrome.storage.local.remove('pendingUpdate');
      }
      updateBadge();
      return { ok: true, latest, current: CURRENT_VERSION };
    } catch (e) {
      // 오프라인/일시적 장애는 조용히 무시 — 기존 동작 유지(배너 상태는 직전 값 그대로 둔다).
      return { ok: false, error: String((e && e.message) || e) };
    }
  })();

  _updateCheckInFlight = run;
  run.then(() => { _updateCheckInFlight = null; }, () => { _updateCheckInFlight = null; });
  return run;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[HISTORY_KEY] || changes['pendingUpdate']) updateBadge();
});

const UPBIT_URLS = [{ urlPrefix: 'https://upbit.com/' }, { urlPrefix: 'https://www.upbit.com/' }];
const BITHUMB_URLS = [{ urlPrefix: 'https://www.bithumb.com/' }];

// [2026-09-02] 오류 자동신고 클라이언트/프로브 파일을 content script 보다 먼저 주입한다(둘 다 재주입에 안전한 멱등 파일).
// manifest 의 content_scripts 순서와 같은 순서 — 이 재주입 경로에서만 빠지면 window.__ktReport 가 없어 신고가 조용히 꺼진다.
const REPORT_HELPER_FILES = ['kta_dom_probes.js', 'kta_report_client.js'];

// [2026-09-04] 예전엔 이 함수가 불릴 때마다 무조건 주입했다. 그런데 아래 tabs.onActivated 가
// **업비트 탭으로 전환할 때마다** 이걸 부르기 때문에, 형이 탭을 왔다갔다 할 때마다 87KB 짜리
// 스크립트 3개(dom_probes + report_client + content)가 같은 페이지에 다시 얹혔다.
// content.js 는 세대 가드(__ktaGen)로 낡은 인스턴스의 '동작'은 무력화하지만
// **리스너 자체는 제거하지 못한다**(content.js 상단 주석도 "제거할 방법이 없으니"라고 인정).
// 그래서 전환할 때마다 storage.onChanged / runtime.onMessage / window 이벤트가 하나씩 쌓이고,
// 저장소가 바뀔 때마다 쌓인 만큼 전부 호출됐다가 isLive() 로 되돌아온다.
//
// 그래서 주입 전에 "이미 그 스크립트가 살아서 응답하나"를 한 번 물어보고, 응답하면 건너뛴다.
//
// ⚠️ 최우선 안전규칙: **주입이 안 되는 것이 중복 주입보다 훨씬 나쁘다**(알람이 아예 안 돈다).
//    그래서 건너뛰는 것은 **핑이 명확히 성공했을 때 단 하나의 경우뿐**이고,
//    응답 없음 · 오류(lastError) · 다른 스크립트 이름 · 지연(타임아웃) · 예외는 전부
//    "예전처럼 주입"으로 떨어진다. 이 함수에 '아무것도 안 하고 끝나는' 경로를 만들지 말 것.
const PING_TIMEOUT_MS = 500;

function injectTab(tabId, file) {
  let settled = false;
  const doInject = () => {
    if (settled) return;
    settled = true;
    chrome.scripting.executeScript({
      target: { tabId },
      files: REPORT_HELPER_FILES.concat([file])
    }).catch(() => {});
  };
  // 핑이 어떤 이유로든 늦으면(페이지가 아주 바쁠 때 등) 기다리지 않고 그냥 주입한다.
  setTimeout(doInject, PING_TIMEOUT_MS);
  try {
    chrome.tabs.sendMessage(tabId, { action: 'ktaPing', script: file }, res => {
      // lastError 를 읽지 않으면 "수신자 없음"이 콘솔 오류로 새어나온다 — 정상 경로이므로 삼킨다.
      const err = chrome.runtime.lastError;
      if (!err && res && res.ok === true && res.script === file) { settled = true; return; } // 살아있음 → 주입 생략
      doInject();
    });
  } catch (e) {
    doInject();
  }
}

// ── [2026-09-02] 오류 자동신고 전송 — content script 페이로드를 인증서버 POST /report 로 중계 ──
// 서버는 텔레그램을 보내지 않고 파일로만 쌓는다(형 확정) — 08:55 일일 헬스리포트가 폴더를 읽어 보고.
// 이 시크릿은 스팸 오발송 방지용 식별자일 뿐 인증이 아니다(압축해제 설치라 소스가 공개된 것과 같음).
// [2026-09-03] 값은 최상단 importScripts('kta_report_secret.js') 가 self.KTA_REPORT_SECRET 로 주입한다.
const REPORT_URL = 'https://auth.krisb-infra.com/report';
const REPORT_SECRET = self.KTA_REPORT_SECRET;
async function sendErrorReport(payload) {
  const res = await fetch(REPORT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-kmemo-secret': REPORT_SECRET },
    body: JSON.stringify(payload),
  });
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  const ok = res.ok && !!(data && data.ok);
  chrome.storage.local.set({ kt_report_last_v1: { ts: Date.now(), ok, id: (data && data.id) || '', code: (payload && payload.code) || '' } });
  return { ok, id: data && data.id };
}

function injectAllTabs() {
  chrome.tabs.query({ url: ['https://upbit.com/*', 'https://www.upbit.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'content.js'));
  });
  chrome.tabs.query({ url: ['https://www.bithumb.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'content.js'));
  });
}

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'content.js');
}, { url: UPBIT_URLS });

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'content.js');
}, { url: BITHUMB_URLS });

// 기존 트리거는 중복 방어용으로 그대로 유지(브라우저 재시작 / 설치·업데이트 시점).
// 다만 이 둘만으로는 chrome://extensions 리로드(⟳) 경로를 못 잡아서,
// 아래 onMessage의 'checkForUpdate'(팝업 열 때마다 호출)가 실질적인 주 경로다.
chrome.runtime.onStartup.addListener(() => { injectAllTabs(); checkForUpdate({ force: true }); });
chrome.runtime.onInstalled.addListener(() => { injectAllTabs(); checkForUpdate({ force: true }); });

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (!tab.url) return;
    if (tab.url.startsWith('https://upbit.com/') || tab.url.startsWith('https://www.upbit.com/')) {
      injectTab(tabId, 'content.js');
    } else if (tab.url.startsWith('https://www.bithumb.com/')) {
      // [2026-09-04] 빗썸도 업비트와 **같은** content.js 를 쓴다(옛 bithumb_content.js 는 은퇴).
      // 그래야 반복 3모드 · 봉 워터마크 · 추세선 · 온차트 알람선이 두 거래소에서 똑같이 돈다.
      injectTab(tabId, 'content.js');
    }
  });
});

// ── [2026-08-23] 캔들 트리거엔진 1단계: 공용 캐시 + in-flight 병합 + 캔들전용 토큰버킷 ──────────
// 목적: 탭을 여러 개 열어놔도(각 탭이 독립적으로 폴링) 실제 네트워크 호출이 배수로 안 늘어나게
// 이 서비스워커를 유일한 관문으로 만든다. background.js는 모든 탭이 공유하는 단일 인스턴스라
// 별도 리더선출 없이 이 파일 안의 in-memory 상태만으로 충분함(SW 재기동에도 캐시는
// chrome.storage.session에 저장돼서 살아남음 — 'storage' 권한 안에 이미 포함돼있어 매니페스트 변경 불필요).

const _inFlight = new Map(); // key → 진행중인 Promise, 동시요청 병합용

function cacheGet(key) {
  return new Promise(resolve => {
    try { chrome.storage.session.get(key, data => resolve(data[key] || null)); }
    catch (e) { resolve(null); }
  });
}
function cacheSet(key, value) {
  try { chrome.storage.session.set({ [key]: value }); } catch (e) {}
}

// key로 in-flight 요청을 병합하면서, maxAgeMs 안에 캐시가 있으면 그걸 그대로 씀.
async function cachedFetch(key, maxAgeMs, fetcher) {
  const cached = await cacheGet(key);
  if (cached && (Date.now() - cached.ts) < maxAgeMs) return cached.data;
  if (_inFlight.has(key)) return _inFlight.get(key);
  const p = (async () => {
    // 병합 대기 중 다른 호출이 이미 채워놨을 수 있으니 한 번 더 확인.
    const cached2 = await cacheGet(key);
    if (cached2 && (Date.now() - cached2.ts) < maxAgeMs) return cached2.data;
    const data = await fetcher();
    cacheSet(key, { ts: Date.now(), data });
    return data;
  })();
  _inFlight.set(key, p);
  try { return await p; } finally { _inFlight.delete(key); }
}

// 캔들 API 전용 토큰버킷(4req/s, 버스트8) — 업비트 실측 상한(초당10) 대비 안전마진.
// ticker는 group=candles와 버킷이 분리돼있어서 이 제한을 안 받음(기존 동작 그대로).
const CANDLE_BUCKET = { tokens: 8, max: 8, refillPerSec: 4, lastRefill: Date.now() };
let candleBackoffUntil = 0;
let candleBackoffMs = 0;
let candleSuccessStreak = 0;

function refillCandleBucket() {
  const now = Date.now();
  CANDLE_BUCKET.tokens = Math.min(CANDLE_BUCKET.max, CANDLE_BUCKET.tokens + ((now - CANDLE_BUCKET.lastRefill) / 1000) * CANDLE_BUCKET.refillPerSec);
  CANDLE_BUCKET.lastRefill = now;
}
function takeCandleToken() {
  refillCandleBucket();
  if (CANDLE_BUCKET.tokens >= 1) { CANDLE_BUCKET.tokens -= 1; return true; }
  return false;
}
function onCandleSuccess() {
  candleSuccessStreak++;
  if (candleBackoffMs > 0 && candleSuccessStreak >= 2) { candleBackoffMs = 0; candleBackoffUntil = 0; }
}
function onCandle429() {
  candleSuccessStreak = 0;
  candleBackoffMs = candleBackoffMs ? Math.min(candleBackoffMs * 2, 120000) : 5000;
  candleBackoffUntil = Date.now() + candleBackoffMs;
}

function rateLimitedError(retryAfter) {
  return Object.assign(new Error('rate_limited'), { rateLimited: true, retryAfter });
}

// [2026-09-04] 거래소별 REST 주소. **빗썸 v1 API 는 업비트와 응답 형식이 글자까지 같다**
// (market / candle_date_time_utc / opening_price / high_price / low_price / trade_price / unit —
// 2026-09-04 실측 확인). 그래서 아래 파싱 코드는 한 줄도 갈라지지 않고 주소만 바뀐다.
// 다만 빗썸엔 seconds(1초봉)·years(연봉)가 없고(404), to= 파라미터에 Z 나 +09:00 을 붙이면 400 이다.
function apiHost(exchange) {
  return exchange === 'bithumb' ? 'https://api.bithumb.com' : 'https://api.upbit.com';
}

// tf(차트 resolution 문자열) → 업비트 캔들 REST 경로. 1S/1M/12M 포함 전 구간 지원(실측 확인됨).
function candlePath(tf) {
  if (tf === '1D') return 'days';
  if (tf === '1W') return 'weeks';
  if (tf === '1M') return 'months';
  if (tf === '12M') return 'years';
  if (tf === '1S') return 'seconds';
  return `minutes/${tf}`; // '1','3','5','10','15','30','60','240'
}

async function fetchCandlesInternal(market, tf, count, to, exchange) {
  // 백오프 중이면 토큰 소비도 안 하고 즉시 실패 반환 — 호출측(콘텐츠스크립트)이 폴링간격을 늦추는 신호로 씀.
  if (Date.now() < candleBackoffUntil) throw rateLimitedError(candleBackoffUntil);
  if (!takeCandleToken()) throw rateLimitedError(Date.now() + 250);
  let url = `${apiHost(exchange)}/v1/candles/${candlePath(tf)}?market=${market}&count=${count}`;
  if (to) url += `&to=${encodeURIComponent(to)}`;
  const r = await fetch(url);
  if (r.status === 429) { onCandle429(); throw rateLimitedError(candleBackoffUntil); }
  if (!r.ok) throw new Error('http_' + r.status);
  const data = await r.json();
  onCandleSuccess();
  return data;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === 'ktaReport') {
    sendErrorReport(msg.payload || {})
      .then(sendResponse)
      .catch(e => {
        chrome.storage.local.set({ kt_report_last_v1: { ts: Date.now(), ok: false, id: '', code: (msg.payload && msg.payload.code) || '' } });
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      });
    return true;
  }
  // [2026-09-04] 알람 → 코인 이동 결과 집계(PND-0104 후속). 세는 자리가 **백그라운드**인 이유:
  // 통째 새로고침으로 떨어지는 순간 그 페이지의 자바스크립트가 죽어서, 페이지에서 저장하면
  // 정작 제일 알고 싶은 "실패했다"는 기록이 저장되기 전에 날아간다.
  // 동작은 아무것도 바꾸지 않는다 — 얼마나 자주 새로고침으로 떨어지는지를 숫자로 보려는 것뿐.
  if (msg && msg.action === 'ktaNavStat') {
    const ex = msg.exchange === 'bithumb' ? 'bithumb' : 'upbit';
    const r = String(msg.result || 'unknown').slice(0, 32);
    chrome.storage.local.get(NAV_STATS_KEY, data => {
      const st = data[NAV_STATS_KEY] || { since: Date.now(), upbit: {}, bithumb: {} };
      if (!st.upbit) st.upbit = {};
      if (!st.bithumb) st.bithumb = {};
      if (!st.since) st.since = Date.now();
      st[ex][r] = (st[ex][r] || 0) + 1;
      chrome.storage.local.set({ [NAV_STATS_KEY]: st });
    });
    return; // 응답 필요 없음
  }
  // 팝업이 열릴 때마다 호출된다. MV3 서비스워커가 잠들어 있어도 이 메시지가 깨우므로
  // "확장 리로드만 한" 사용자도 팝업 한 번 열면 곧바로 최신 버전을 확인하게 된다.
  if (msg.action === 'checkForUpdate') {
    checkForUpdate({ force: !!msg.force, minInterval: msg.minInterval })
      .then(res => sendResponse(res || { ok: false }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.action === 'fetchCandles' && msg.market && msg.tf) {
    const count = Math.min(200, Math.max(1, parseInt(msg.count) || 2));
    const to = msg.to || '';
    const maxAgeMs = Math.max(1000, msg.maxAgeMs || 15000);
    // 캐시 키에 거래소를 넣지 않으면 같은 'KRW-BTC' 라도 업비트/빗썸 값이 서로 섞인다.
    const ex = msg.exchange === 'bithumb' ? 'bithumb' : 'upbit';
    const key = `kta_cache_candle:${ex}:${msg.market}:${msg.tf}:${count}:${to}`;
    cachedFetch(key, maxAgeMs, () => fetchCandlesInternal(msg.market, msg.tf, count, to, ex))
      .then(candles => sendResponse({ ok: true, candles }))
      .catch(e => sendResponse({ ok: false, error: e.message, rateLimited: !!e.rateLimited, retryAfter: e.retryAfter || 0 }));
    return true;
  }
  if (msg.action === 'fetchPrices' && msg.codes && msg.codes.length) {
    fetch(`${apiHost(msg.exchange)}/v1/ticker?markets=${msg.codes.join(',')}`)
      .then(r => r.json())
      .then(data => {
        const prices = {};
        data.forEach(d => { prices[d.market] = d.trade_price; });
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchMarkets') {
    fetch('https://api.upbit.com/v1/market/all?isDetails=false')
      .then(r => r.json())
      .then(data => {
        const markets = data
          .filter(m => m.market.startsWith('KRW-'))
          .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
        sendResponse({ ok: true, markets });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'quickAdd') {
    chrome.storage.local.set({ quickAddSym: msg.sym }, () => {
      chrome.action.openPopup().catch(() => {});
    });
    return;
  }
  if (msg.action === 'sendPush') {
    chrome.storage.local.get([SETTINGS_KEY, PUSH_COOLDOWN_KEY], data => {
      const s = data[SETTINGS_KEY] || {};
      if (!s.ntfyEnabled || !s.ntfyTopic) { sendResponse({ ok: false }); return; }
      const cooldownMin = s.ntfyCooldown ?? 30;
      const cooldowns = data[PUSH_COOLDOWN_KEY] || {};
      const alarm = msg.alarm;
      if (cooldownMin > 0 && (Date.now() - (cooldowns[alarm.id] || 0)) < cooldownMin * 60 * 1000) { sendResponse({ ok: false }); return; }
      cooldowns[alarm.id] = Date.now();
      chrome.storage.local.set({ [PUSH_COOLDOWN_KEY]: cooldowns });
      const exName = msg.exchange === 'bithumb' ? '빗썸' : '업비트';
      const dirText = alarm.dir === 'above' ? '이상' : '이하';
      const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(msg.currentPrice).toLocaleString()}원${alarm.memo ? '\n메모: ' + alarm.memo : ''}`;
      fetch('https://ntfy.sh/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: s.ntfyTopic, title: `🔔 ${exName} 가격 알람`, message: body, priority: 4, tags: ['bell'] })
      }).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message }));
    });
    return true;
  }
  if (msg.action === 'ntfyTest') {
    fetch('https://ntfy.sh/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: msg.topic, title: '🔔 Kris Trader Alarm 테스트', message: 'Push 알림이 정상 수신되었어요!', priority: 4, tags: ['bell'] })
    }).then(r => sendResponse({ ok: true, status: r.status })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchBithumbPrices') {
    fetch('https://api.bithumb.com/public/ticker/ALL_KRW')
      .then(r => r.json())
      .then(data => {
        const prices = {};
        if (data.status === '0000') {
          Object.entries(data.data).forEach(([sym, info]) => {
            if (sym !== 'date') prices[sym] = parseFloat(info.closing_price);
          });
        }
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
